﻿NORCOM - friends install
========================
1) Double-click Install NORCOM.exe
2) Click Install NORCOM, wait, then Play NORCOM
3) Join Multiplayer: shrimp-cub.tun.ply.gg

Need official Minecraft Java Launcher (logged in once):
https://www.minecraft.net/en-us/download

SmartScreen: More info -> Run anyway.
The launcher self-updates from GitHub when Jeffrey publishes a new build.
