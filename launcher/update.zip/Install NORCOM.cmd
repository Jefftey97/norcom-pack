@echo off
setlocal EnableExtensions
title NORCOM Install
cd /d "%~dp0"

if not exist "%~dp0NORCOM-Launcher.ps1" goto NEED_EXTRACT
if not exist "%~dp0tools\NorcomExtras.ps1" goto NEED_EXTRACT

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -File | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1

set "DEST=%LOCALAPPDATA%\NORCOM\Launcher"
mkdir "%DEST%" >nul 2>&1
mkdir "%DEST%\assets" >nul 2>&1
mkdir "%DEST%\tools" >nul 2>&1

copy /Y "%~dp0NORCOM-Launcher.ps1" "%DEST%\NORCOM-Launcher.ps1" >nul
copy /Y "%~dp0Launcher.ps1" "%DEST%\Launcher.ps1" >nul
copy /Y "%~dp0NORCOM-Launcher.vbs" "%DEST%\NORCOM-Launcher.vbs" >nul
copy /Y "%~dp0NORCOM-Installer.bat" "%DEST%\NORCOM-Installer.bat" >nul
copy /Y "%~dp0Play-NORCOM.bat" "%DEST%\Play-NORCOM.bat" >nul
copy /Y "%~dp0pack-url.txt" "%DEST%\pack-url.txt" >nul
copy /Y "%~dp0installer-version.txt" "%DEST%\installer-version.txt" >nul
copy /Y "%~dp0news.md" "%DEST%\news.md" >nul
copy /Y "%~dp0rules.md" "%DEST%\rules.md" >nul
copy /Y "%~dp0discord-link.txt" "%DEST%\discord-link.txt" >nul
copy /Y "%~dp0FRIENDS-README.txt" "%DEST%\FRIENDS-README.txt" >nul
if exist "%~dp0START HERE.txt" copy /Y "%~dp0START HERE.txt" "%DEST%\START HERE.txt" >nul
if exist "%~dp0Install NORCOM.cmd" copy /Y "%~dp0Install NORCOM.cmd" "%DEST%\Install NORCOM.cmd" >nul
xcopy /Y /Q /I "%~dp0assets\*" "%DEST%\assets\" >nul
xcopy /Y /Q /I "%~dp0tools\*" "%DEST%\tools\" >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%DEST%' -Recurse -File | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Check-MinecraftLauncher.ps1"
if errorlevel 2 exit /b 1

if /I "%NORCOM_TEST%"=="1" (
  echo INSTALL_OK dest=%DEST%
  exit /b 0
)
start "" wscript "%DEST%\NORCOM-Launcher.vbs"
exit /b 0

:NEED_EXTRACT
if /I "%NORCOM_TEST%"=="1" (
  echo NEED_EXTRACT
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show(\"You opened a file from INSIDE the zip.`r`n`r`n1) Close this.`r`n2) Right-click NORCOM-Installer.zip`r`n3) Click Extract All...`r`n4) Open the extracted folder`r`n5) Double-click  Install NORCOM.cmd\",\"NORCOM - Extract the zip first\",'OK','Warning') | Out-Null"
exit /b 1