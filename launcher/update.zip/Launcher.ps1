﻿#Requires -Version 5.1
<#
  NORCOM Installer / Launcher - branded WinForms UI
  Double-click NORCOM-Installer.bat (no admin). Syncs packwiz mods, Fabric profile, Patrix, shader, server list.
#>
param(
  [string]$PackUrl = '',
  [string]$GameDir = '',
  [string]$TestMode = '',
  [switch]$SilentSync,
  [switch]$ShowUi,
  [switch]$AutoInstall,
  [string]$ScreenshotPath = '',
  [ValidateSet('','Windowed','Maximized','Compact','Medium')]
  [string]$ScreenshotMode = ''
)
$script:StartupSw = [Diagnostics.Stopwatch]::StartNew()

# --- earliest boot log (before Add-Type / UI) ---
# Scratch/test overrides (never required for production). Keep visual tests off Jeffrey's live mutex/state.
try {
  if ($env:NORCOM_STATE_DIR) { $script:NcStateDirOverride = $env:NORCOM_STATE_DIR.Trim() }
  if ($env:NORCOM_MUTEX_NAME) { $script:NcMutexNameOverride = $env:NORCOM_MUTEX_NAME.Trim() }
  if ($env:NORCOM_ACTIVATE_NAME) { $script:NcActivateNameOverride = $env:NORCOM_ACTIVATE_NAME.Trim() }
} catch {}
try {
  $bootState = if ($script:NcStateDirOverride) { $script:NcStateDirOverride } else { Join-Path $env:LOCALAPPDATA 'NORCOM\Launcher' }
  $script:NcStartupLog = Join-Path $bootState 'startup.log'
  $sd = Split-Path $script:NcStartupLog -Parent
  if (-not (Test-Path $sd)) { New-Item -ItemType Directory -Path $sd -Force | Out-Null }
  $line = '{0} start pid={1} ps={2} file={3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'), $PID, $PSVersionTable.PSVersion, $MyInvocation.MyCommand.Path
  [IO.File]::AppendAllText($script:NcStartupLog, $line + [Environment]::NewLine)
} catch {}

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------- Single-instance lock ----------
# 1.0.33: startup self-heal (activate handoff ~3s or reclaim windowless holder) + Fix NORCOM.
# 1.0.34: Play timeouts + stable panels; clean startup (opacity-0 build, composited paint, layout-before-show, fade-in).
$script:NcMutex = $null

# ---------- Startup self-heal / Fix NORCOM (1.0.33) ----------
$script:NcMutexName = 'Global\NORCOM.Launcher.SingleInstance'
$script:NcActivateName = 'Global\NORCOM.Launcher.Activate'
$script:NcStateDir = Join-Path $env:LOCALAPPDATA 'NORCOM\Launcher'
if ($script:NcMutexNameOverride) { $script:NcMutexName = $script:NcMutexNameOverride }
if ($script:NcActivateNameOverride) { $script:NcActivateName = $script:NcActivateNameOverride }
if ($script:NcStateDirOverride) { $script:NcStateDir = $script:NcStateDirOverride }
$script:NcSelfDir = Split-Path -Parent $MyInvocation.MyCommand.Path
try {
  if (-not (Test-Path $script:NcStateDir)) { New-Item -ItemType Directory -Path $script:NcStateDir -Force | Out-Null }
} catch {}
$script:NcStartupLog = Join-Path $script:NcStateDir 'startup.log'
function Write-NcStartupLog([string]$line) {
  try {
    $p = $script:NcStartupLog
    if (-not $p) { $p = Join-Path $env:LOCALAPPDATA 'NORCOM\Launcher\startup.log' }
    $d = Split-Path $p -Parent
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    [IO.File]::AppendAllText($p, ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz') + ' ' + $line + [Environment]::NewLine))
  } catch {}
}
function Get-NorcomActivateRequestPath { Join-Path $script:NcStateDir 'activate.request' }
function Get-NorcomActivateAckPath { Join-Path $script:NcStateDir 'activate.ack' }
function Write-NorcomActivateAck {
  try {
    $p = Get-NorcomActivateAckPath
    [IO.File]::WriteAllText($p, ((Get-Date).ToUniversalTime().ToString('o') + '|pid=' + $PID))
  } catch {}
}
function Clear-NorcomActivateAck {
  try { Remove-Item -LiteralPath (Get-NorcomActivateAckPath) -Force -EA SilentlyContinue } catch {}
}
function Test-NorcomProcessIsMinecraftJava {
  param([string]$Name, [string]$CommandLine)
  $n = [string]$Name; $c = [string]$CommandLine
  if ($n -match '(?i)^(java|javaw)\.exe$') { return $true }
  if ($c -match '(?i)javaw?\.exe' -and $c -match '(?i)minecraft|fabric|forge|quilt|liteloader') { return $true }
  return $false
}
function Get-NorcomLauncherOrphanProcesses {
  # Only processes clearly belonging to THIS launcher folder. Never Minecraft java/javaw.
  $scope = ''
  try { $scope = [IO.Path]::GetFullPath([string]$script:NcSelfDir).TrimEnd('\') } catch { $scope = [string]$script:NcSelfDir }
  $list = New-Object System.Collections.Generic.List[object]
  if ([string]::IsNullOrWhiteSpace($scope)) { return @() }
  $scopeL = $scope.ToLowerInvariant()
  try {
    foreach ($p in Get-CimInstance Win32_Process -ErrorAction SilentlyContinue) {
      try {
        if ([int]$p.ProcessId -eq $PID) { continue }
        $name = [string]$p.Name
        $cmd = [string]$p.CommandLine
        $exe = [string]$p.ExecutablePath
        if (Test-NorcomProcessIsMinecraftJava -Name $name -CommandLine $cmd) { continue }
        $hit = $false
        if ($name -eq 'NORCOM Launcher.exe') {
          $exeL = ([string]$exe).ToLowerInvariant()
          $cmdL = ([string]$cmd).ToLowerInvariant()
          if ($exeL -and $exeL.StartsWith($scopeL)) { $hit = $true }
          elseif ($cmdL -and $cmdL.Contains($scopeL)) { $hit = $true }
        } elseif ($name -match '(?i)^(powershell|pwsh)\.exe$') {
          $cmdL = ([string]$cmd).ToLowerInvariant()
          if ($cmdL -and $cmdL.Contains($scopeL) -and ($cmd -match '(?i)(NORCOM-Launcher\.ps1|[/\\]Launcher\.ps1)')) { $hit = $true }
        }
        if ($hit) { $list.Add($p) }
      } catch {}
    }
  } catch {}
  return [object[]]($list.ToArray())
}
function Stop-NorcomLauncherOrphans {
  $killed = @()
  foreach ($p in Get-NorcomLauncherOrphanProcesses) {
    try {
      Write-NcStartupLog ("self-heal: killing orphan pid={0} name={1}" -f $p.ProcessId, $p.Name)
      Stop-Process -Id ([int]$p.ProcessId) -Force -ErrorAction Stop
      $killed += ([string]$p.ProcessId)
    } catch {
      Write-NcStartupLog ("self-heal: kill failed pid={0}: {1}" -f $p.ProcessId, $_.Exception.Message)
    }
  }
  return $killed
}
function Clear-NorcomStaleLauncherFiles {
  param([string]$Dir = $script:NcSelfDir)
  $removed = New-Object System.Collections.Generic.List[string]
  if (-not $Dir -or -not (Test-Path -LiteralPath $Dir)) { return @() }
  $root = [IO.Path]::GetFullPath($Dir).TrimEnd('\')
  # Never delete live game data / settings; only stale copies inside the launcher folder.
  $protectNames = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
  foreach ($n in @(
      'Launcher.ps1','NORCOM-Launcher.ps1','NORCOM Launcher.exe','NORCOM-Installer.bat','Play-NORCOM.bat',
      'NORCOM-Launcher.vbs','Install NORCOM.cmd','pack-url.txt','news.md','rules.md','discord-link.txt',
      'installer-version.txt','FRIENDS-README.txt','START HERE.txt','startup.log','self-update.log',
      'NorcomUi.cs','NorcomCharacter.ps1','NorcomExtras.ps1','Check-MinecraftLauncher.ps1',
      'Test-FabricDependencies.ps1','packwiz-installer-bootstrap.jar','activate.request','activate.ack',
      'self-update-ok.txt','settings.json','norcom-settings.json'
    )) { [void]$protectNames.Add($n) }
  $rx = [regex]'(?i)(\.pre-diag|\.bak|~$)|\.old$|\.orig$|copy of |\(\d+\)\.(ps1|exe|bat|cmd|vbs)'
  $scan = @()
  try { $scan += Get-ChildItem -LiteralPath $root -File -Force -EA SilentlyContinue } catch {}
  $tools = Join-Path $root 'tools'
  if (Test-Path -LiteralPath $tools) {
    try { $scan += Get-ChildItem -LiteralPath $tools -File -Force -EA SilentlyContinue } catch {}
  }
  foreach ($f in $scan) {
    try {
      if ($protectNames.Contains($f.Name)) { continue }
      $full = [string]$f.FullName
      if ($full -match '(?i)\\assets\\|\\versions\\|\\saves\\|\\worlds\\|\\mods\\|\\resourcepacks\\|\\shaderpacks\\|\\skins\\|options\.txt|norcom-settings|settings\.json') { continue }
      $stale = $false
      if ($rx.IsMatch($f.Name)) { $stale = $true }
      if ($f.Name -match '(?i)^NORCOM-Launcher\.ps1\.' ) { $stale = $true }
      if ($f.Name -match '(?i)^Launcher\.ps1\.' ) { $stale = $true }
      if ($f.Name -match '(?i)NorcomUi\.cs\.bak') { $stale = $true }
      if (-not $stale) { continue }
      Remove-Item -LiteralPath $f.FullName -Force -EA Stop
      $removed.Add($f.FullName)
      Write-NcStartupLog ("self-heal: removed stale {0}" -f $f.FullName)
    } catch {
      Write-NcStartupLog ("self-heal: remove failed {0}: {1}" -f $f.FullName, $_.Exception.Message)
    }
  }
  return [object[]]($removed.ToArray())
}
function Test-NorcomActivateAckRecent {
  param([datetime]$NotBeforeUtc, [int]$MaxAgeSec = 15)
  try {
    $p = Get-NorcomActivateAckPath
    if (-not (Test-Path -LiteralPath $p)) { return $false }
    $txt = [IO.File]::ReadAllText($p)
    $ts = $null
    if ($txt -match '^\s*(\S+)') {
      try { $ts = [DateTime]::Parse($Matches[1], $null, [System.Globalization.DateTimeStyles]::RoundtripKind) } catch {}
    }
    if (-not $ts) { $ts = [IO.File]::GetLastWriteTimeUtc($p) }
    if ($ts.Kind -ne [DateTimeKind]::Utc) { $ts = $ts.ToUniversalTime() }
    if ($ts -lt $NotBeforeUtc.AddSeconds(-1)) { return $false }
    if (([DateTime]::UtcNow - $ts).TotalSeconds -gt $MaxAgeSec) { return $false }
    return $true
  } catch { return $false }
}
function Wait-NorcomActivateAck {
  param([datetime]$SinceUtc, [int]$TimeoutMs = 3000)
  $sw = [Diagnostics.Stopwatch]::StartNew()
  while ($sw.ElapsedMilliseconds -lt $TimeoutMs) {
    if (Test-NorcomActivateAckRecent -NotBeforeUtc $SinceUtc) { return $true }
    Start-Sleep -Milliseconds 120
  }
  return (Test-NorcomActivateAckRecent -NotBeforeUtc $SinceUtc)
}
function Signal-NorcomActivate {
  try {
    $created = $false
    $ev = New-Object System.Threading.EventWaitHandle($false, [System.Threading.EventResetMode]::AutoReset, $script:NcActivateName, [ref]$created)
    try { [void]$ev.Set() } finally { $ev.Dispose() }
  } catch {}
  try {
    $req = Get-NorcomActivateRequestPath
    [IO.File]::WriteAllText($req, (Get-Date).ToUniversalTime().ToString('o'))
  } catch {}
  try { (New-Object -ComObject WScript.Shell).AppActivate('NORCOM') | Out-Null } catch {}
  try { (New-Object -ComObject WScript.Shell).AppActivate('NORCOM Launcher') | Out-Null } catch {}
}
function Try-AcquireNorcomMutex {
  $owned = $false
  try {
    if ($script:NcMutex) { try { $script:NcMutex.Dispose() } catch {}; $script:NcMutex = $null }
    $script:NcMutex = New-Object System.Threading.Mutex($true, $script:NcMutexName, [ref]$owned)
  } catch {
    Write-NcStartupLog ('mutex acquire error: ' + $_.Exception.Message)
    return $false
  }
  return [bool]$owned
}
function Invoke-NorcomStartupSelfHeal {
  # Silent, before UI. No dialogs. Never touch Minecraft. Scope = this ScriptDir only.
  $allowParallel = ($ScreenshotPath -or $env:NORCOM_LAUNCHER_SELFTEST -or $TestMode -eq '1')
  Write-NcStartupLog ('self-heal: begin scope=' + $script:NcSelfDir + ' parallel=' + $allowParallel)

  $owned = Try-AcquireNorcomMutex
  if (-not $owned -and -not $allowParallel) {
    Write-NcStartupLog 'self-heal: mutex held - signaling activate, waiting ack ~3s'
    Clear-NorcomActivateAck
    $since = [DateTime]::UtcNow
    Signal-NorcomActivate
    $acked = Wait-NorcomActivateAck -SinceUtc $since -TimeoutMs 3000
    if ($acked) {
      Write-NcStartupLog 'self-heal: activate acknowledged - handing off, exit 0'
      Write-Host 'NORCOM Launcher is already running.'
      exit 0
    }
    Write-NcStartupLog 'self-heal: no activate ack - treating holder as dead/invisible'
    $killed = Stop-NorcomLauncherOrphans
    Write-NcStartupLog ('self-heal: killed orphans=[' + ($killed -join ',') + ']')
    Start-Sleep -Milliseconds 200
    $owned = Try-AcquireNorcomMutex
    if (-not $owned) {
      [void](Stop-NorcomLauncherOrphans)
      Start-Sleep -Milliseconds 250
      $owned = Try-AcquireNorcomMutex
    }
    if (-not $owned) {
      Write-NcStartupLog 'self-heal: still cannot acquire mutex - signaling and exit 0'
      Signal-NorcomActivate
      exit 0
    }
    Write-NcStartupLog 'self-heal: acquired mutex after reclaim'
  } elseif (-not $owned -and $allowParallel) {
    Write-NcStartupLog 'self-heal: parallel self-test/screenshot - skipping mutex ownership'
  } else {
    Write-NcStartupLog 'self-heal: mutex acquired'
  }

  try {
    $killed2 = Stop-NorcomLauncherOrphans
    if ($killed2.Count -gt 0) { Write-NcStartupLog ('self-heal: startup orphan kill=[' + ($killed2 -join ',') + ']') }
  } catch { Write-NcStartupLog ('self-heal: orphan pass error: ' + $_.Exception.Message) }
  try {
    $rm = Clear-NorcomStaleLauncherFiles -Dir $script:NcSelfDir
    Write-NcStartupLog ('self-heal: stale removed count=' + $rm.Count)
  } catch { Write-NcStartupLog ('self-heal: stale cleanup error: ' + $_.Exception.Message) }
  Write-NcStartupLog ('self-heal: done in ' + $script:StartupSw.ElapsedMilliseconds + 'ms')
}
function Show-NorcomFixConfirmDialog {
  if ($script:SelfTest -or $TestMode -eq '1' -or $env:NORCOM_LAUNCHER_SELFTEST) {
    $script:LastMsg = 'Fix NORCOM confirm (dry)'
    return [System.Windows.Forms.DialogResult]::Yes
  }
  $dlg = New-Object System.Windows.Forms.Form
  $dlg.Text = 'Fix NORCOM'
  $dlg.FormBorderStyle = 'FixedDialog'
  $dlg.StartPosition = 'CenterParent'
  $dlg.ClientSize = New-Object System.Drawing.Size 440, 260
  $dlg.MaximizeBox = $false
  $dlg.MinimizeBox = $false
  $dlg.ShowInTaskbar = $false
  $dlg.BackColor = [System.Drawing.Color]::FromArgb(10, 14, 30)
  $dlg.ForeColor = [System.Drawing.Color]::FromArgb(230, 245, 255)
  $title = New-Object System.Windows.Forms.Label
  $title.Text = 'Fix NORCOM'
  $title.Font = New-Object System.Drawing.Font 'Segoe UI', 14, [System.Drawing.FontStyle]::Bold
  $title.ForeColor = [System.Drawing.Color]::FromArgb(0, 229, 255)
  $title.Location = New-Object System.Drawing.Point 16, 14
  $title.AutoSize = $true
  $body = New-Object System.Windows.Forms.Label
  $body.Text = "This will:`r`n- Close other NORCOM launcher copies (not Minecraft)`r`n- Delete leftover backups (*.bak*, *.pre-diag*, old copies)`r`n- Restart one clean launcher`r`n`r`nIt will NOT delete the game, worlds, mods, skins, or settings."
  $body.Location = New-Object System.Drawing.Point 16, 48
  $body.Size = New-Object System.Drawing.Size 408, 140
  $body.ForeColor = [System.Drawing.Color]::FromArgb(200, 220, 240)
  $yes = New-Object System.Windows.Forms.Button
  $yes.Text = 'Fix now'
  $yes.Size = New-Object System.Drawing.Size 120, 32
  $yes.Location = New-Object System.Drawing.Point 196, 200
  $yes.BackColor = [System.Drawing.Color]::FromArgb(0, 180, 200)
  $yes.ForeColor = [System.Drawing.Color]::White
  $yes.FlatStyle = 'Flat'
  $yes.DialogResult = [System.Windows.Forms.DialogResult]::Yes
  $no = New-Object System.Windows.Forms.Button
  $no.Text = 'Cancel'
  $no.Size = New-Object System.Drawing.Size 100, 32
  $no.Location = New-Object System.Drawing.Point 324, 200
  $no.BackColor = [System.Drawing.Color]::FromArgb(40, 20, 50)
  $no.ForeColor = [System.Drawing.Color]::FromArgb(255, 45, 180)
  $no.FlatStyle = 'Flat'
  $no.DialogResult = [System.Windows.Forms.DialogResult]::No
  $dlg.Controls.AddRange(@($title, $body, $yes, $no))
  $dlg.AcceptButton = $yes
  $dlg.CancelButton = $no
  return $dlg.ShowDialog()
}

function Clear-NorcomLegacyInstalls {
  # 1.0.33: replace-over-old — kill launchers, drop stale shortcuts/backups/duplicates.
  # NEVER touch game data: .norcom / .minecraft worlds, mods, config, skins, keybinds, screenshots.
  $removed = New-Object System.Collections.Generic.List[string]
  try {
    foreach ($p in @(Get-CimInstance Win32_Process -EA SilentlyContinue)) {
      try {
        if ([int]$p.ProcessId -eq $PID) { continue }
        $name = [string]$p.Name; $cmd = [string]$p.CommandLine; $exe = [string]$p.ExecutablePath
        if ($name -match '(?i)^java(w)?\.exe$') { continue }
        $hit = $false
        if ($name -eq 'NORCOM Launcher.exe') { $hit = $true }
        elseif ($name -match '(?i)^(powershell|pwsh)\.exe$' -and $cmd -match '(?i)(NORCOM-Launcher\.ps1|[/\\]Launcher\.ps1)' -and $cmd -match '(?i)NORCOM') { $hit = $true }
        if ($hit) {
          Stop-Process -Id ([int]$p.ProcessId) -Force -EA Stop
          $removed.Add('kill:' + $p.ProcessId)
          try { Write-NcStartupLog ("legacy: killed pid={0}" -f $p.ProcessId) } catch {}
        }
      } catch {}
    }
  } catch {}
  Start-Sleep -Milliseconds 400
  $deskDirs = @(
    [Environment]::GetFolderPath('Desktop'),
    (Join-Path $env:USERPROFILE 'Desktop'),
    [Environment]::GetFolderPath('CommonDesktopDirectory')
  ) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique
  $shortcutNames = @(
    'NORCOM Launcher.lnk','NORCOM.lnk','Play NORCOM.lnk','NORCOM Launcher.bat','NORCOM.bat',
    'Install NORCOM.lnk','NORCOM-Launcher.lnk'
  )
  foreach ($d in $deskDirs) {
    foreach ($n in $shortcutNames) {
      $p = Join-Path $d $n
      if (Test-Path -LiteralPath $p) {
        try { Remove-Item -LiteralPath $p -Force -EA Stop; $removed.Add($p); Write-NcStartupLog ("legacy: rm shortcut {0}" -f $p) } catch {}
      }
    }
  }
  $prog = [Environment]::GetFolderPath('Programs')
  foreach ($sm in @(
      (Join-Path $prog 'NORCOM'),
      (Join-Path $prog 'NORCOM Launcher.lnk'),
      (Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'NORCOM')
    )) {
    if (-not $sm -or -not (Test-Path -LiteralPath $sm)) { continue }
    try {
      if ((Get-Item -LiteralPath $sm).PSIsContainer) {
        Get-ChildItem -LiteralPath $sm -Force -EA SilentlyContinue | ForEach-Object {
          try { Remove-Item -LiteralPath $_.FullName -Force -Recurse -EA Stop; $removed.Add($_.FullName) } catch {}
        }
        try { Remove-Item -LiteralPath $sm -Force -Recurse -EA SilentlyContinue } catch {}
      } else {
        Remove-Item -LiteralPath $sm -Force -EA Stop; $removed.Add($sm)
      }
      Write-NcStartupLog ("legacy: rm startmenu {0}" -f $sm)
    } catch {}
  }
  $lad = [Environment]::GetFolderPath('LocalApplicationData')
  if ($lad) {
    Get-ChildItem -LiteralPath $lad -Force -EA SilentlyContinue | Where-Object {
      $_.PSIsContainer -and ($_.Name -match '(?i)^NORCOM\.(aside|bak|discard|v33)')
    } | ForEach-Object {
      try { Remove-Item -LiteralPath $_.FullName -Recurse -Force -EA Stop; $removed.Add($_.FullName); Write-NcStartupLog ("legacy: rm {0}" -f $_.Name) } catch {}
    }
    $nor = Join-Path $lad 'NORCOM'
    if (Test-Path -LiteralPath $nor) {
      Get-ChildItem -LiteralPath $nor -Force -EA SilentlyContinue | Where-Object {
        $_.PSIsContainer -and ($_.Name -match '(?i)^Launcher\.(bak|old|copy|aside)')
      } | ForEach-Object {
        try { Remove-Item -LiteralPath $_.FullName -Recurse -Force -EA Stop; $removed.Add($_.FullName); Write-NcStartupLog ("legacy: rm {0}" -f $_.Name) } catch {}
      }
    }
  }
  # temp installer leftovers only
  try {
    Get-ChildItem -LiteralPath $env:TEMP -Force -EA SilentlyContinue | Where-Object {
      $_.Name -match '(?i)^norcom-(payload|launcher-upd|install)-'
    } | ForEach-Object {
      try { Remove-Item -LiteralPath $_.FullName -Recurse -Force -EA Stop; $removed.Add($_.FullName) } catch {}
    }
  } catch {}
  return [object[]]($removed.ToArray())
}

function Invoke-NorcomFix {
  param([switch]$Restart, [switch]$Silent)
  Write-NcStartupLog 'fix: begin'
  $legacy = @(); try { $legacy = Clear-NorcomLegacyInstalls } catch { Write-NcStartupLog ('fix: legacy ' + $_.Exception.Message) }
  $killed = Stop-NorcomLauncherOrphans
  $rm = Clear-NorcomStaleLauncherFiles -Dir $script:NcSelfDir
  try { Ensure-NorcomShortcuts } catch { Write-NcStartupLog ('fix: shortcuts ' + $_.Exception.Message) }
  Write-NcStartupLog ('fix: killed=' + ($killed -join ',') + ' removed=' + $rm.Count + ' legacy=' + @($legacy).Count)
  if ($Restart -and -not $script:SelfTest -and -not $env:NORCOM_LAUNCHER_SELFTEST) {
    try {
      $ps1 = Join-Path $script:NcSelfDir 'Launcher.ps1'
      if (-not (Test-Path $ps1)) { $ps1 = Join-Path $script:NcSelfDir 'NORCOM-Launcher.ps1' }
      $exe = Join-Path $script:NcSelfDir 'NORCOM Launcher.exe'
      Write-NcStartupLog ('fix: restarting via ' + $(if (Test-Path $exe) { $exe } else { $ps1 }))
      if (Test-Path $exe) {
        Start-Process -FilePath $exe
      } else {
        Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-STA','-File', $ps1)
      }
      $script:ForceClose = $true
      try { if ($script:form) { $script:form.Close() } elseif ($form) { $form.Close() } } catch {}
      exit 0
    } catch {
      Write-NcStartupLog ('fix: restart failed: ' + $_.Exception.Message)
    }
  }
  return [pscustomobject]@{ killed = $killed; removed = $rm }
}

try { Invoke-NorcomStartupSelfHeal } catch { try { Write-NcStartupLog ('self-heal fatal: ' + $_.Exception.Message) } catch {} }


# --- global error capture (no dialogs) ---
$script:NcErrLog = (Join-Path $env:LOCALAPPDATA 'NORCOM\Launcher\error.log')
# Screenshot helper: PrintWindow(PW_RENDERFULLCONTENT) captures RichTextBox/TextBox like the real screen (DrawToBitmap leaves them blank)
function Invoke-NcCapture($ctl, [System.Drawing.Bitmap]$bmp) {
  try {
    if (-not ('NcCap' -as [type])) { Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class NcCap { [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f); }' }
    $g = [System.Drawing.Graphics]::FromImage($bmp); $dc = $g.GetHdc()
    $ok = [NcCap]::PrintWindow($ctl.Handle, $dc, 2)
    $g.ReleaseHdc($dc); $g.Dispose()
    if ($ok) { return }
  } catch {}
  $ctl.DrawToBitmap($bmp, (New-Object System.Drawing.Rectangle 0,0,$ctl.Width,$ctl.Height))
}

function Write-NcError([string]$where, $ex) {
  try { $d = Split-Path $script:NcErrLog -Parent; if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    [IO.File]::AppendAllText($script:NcErrLog, ("{0} [{1}] {2}`r`n" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'), $where, ($ex | Out-String))) } catch {}
  $script:NcErrCount = [int]$script:NcErrCount + 1
}
try { [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException) } catch {}
try { [System.Windows.Forms.Application]::add_ThreadException({ param($s,$e) Write-NcError 'ui' $e.Exception }) } catch {}
try { [AppDomain]::CurrentDomain.add_UnhandledException({ param($s,$e) Write-NcError 'domain' $e.ExceptionObject }) } catch {}
function Show-NcMsg([object[]]$a) {
  # Never pop visible dialogs during SelfTest or TestMode (sandbox / off-screen runs).
  if ($script:SelfTest -or $TestMode -eq '1') { $script:LastMsg = ($a -join ' | '); if ($a.Count -ge 3 -and [string]$a[2] -match 'Yes') { return [System.Windows.Forms.DialogResult]::No }; return [System.Windows.Forms.DialogResult]::OK }
  switch ($a.Count) { 1 { return [System.Windows.Forms.MessageBox]::Show([string]$a[0]) } 2 { return [System.Windows.Forms.MessageBox]::Show([string]$a[0],[string]$a[1]) } 3 { return [System.Windows.Forms.MessageBox]::Show([string]$a[0],[string]$a[1],$a[2]) } default { return [System.Windows.Forms.MessageBox]::Show([string]$a[0],[string]$a[1],$a[2],$a[3]) } }
}

$codeDpi = @"
using System;
using System.Runtime.InteropServices;
public static class NorcomDpi {
  [DllImport("shcore.dll")] public static extern int SetProcessDpiAwareness(int v);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("shell32.dll", CharSet = CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string id);
}
"@
try { Add-Type -TypeDefinition $codeDpi -ErrorAction SilentlyContinue } catch {}
try { [void][NorcomDpi]::SetProcessDpiAwareness(2) } catch {
  try { [void][NorcomDpi]::SetProcessDpiAwareness(1) } catch {
    try { [void][NorcomDpi]::SetProcessDPIAware() } catch {}
  }
}
# Own taskbar identity (shortcuts carry the same AUMID so pinning groups correctly)
try { [void][NorcomDpi]::SetCurrentProcessExplicitAppUserModelID('NORCOM.Launcher') } catch {}


# ---------- Paths ----------
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $PackUrl) {
  $urlFile = Join-Path $ScriptDir 'pack-url.txt'
  if (Test-Path $urlFile) { $PackUrl = (Get-Content $urlFile -Raw).Trim() }
}
if (-not $PackUrl) { $PackUrl = 'https://github.com/Jefftey97/norcom-pack/raw/refs/heads/main/pack.toml' }
$PackUrl = ("$PackUrl").Trim()
if ($PackUrl -notmatch '^https?://') { $PackUrl = 'https://github.com/Jefftey97/norcom-pack/raw/refs/heads/main/pack.toml' }

$AppData = $env:APPDATA
$LocalApp = $env:LOCALAPPDATA
$NorcomHome = Join-Path $LocalApp 'NORCOM'
$CacheDir = Join-Path $NorcomHome 'cache'
$IconCache = Join-Path $CacheDir 'icons'
$VerCache = Join-Path $CacheDir 'versions'
$StateFile = Join-Path $NorcomHome 'state.json'
$BootstrapJar = Join-Path $ScriptDir 'tools\packwiz-installer-bootstrap.jar'

# Fabric dependency auditor (nested jars + provides)
. (Join-Path $ScriptDir 'tools\Test-FabricDependencies.ps1')
. (Join-Path $ScriptDir 'tools\NorcomExtras.ps1')
# 1.0.33 crash reporting hooks (never block UI)
try {
  [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException)
} catch {}
try {
  [System.Windows.Forms.Application]::add_ThreadException({
    param($s,$e)
    try { Send-NorcomCrashReport -ErrorMessage ([string]$e.Exception.Message) -StackTrace ([string]$e.Exception.StackTrace) -Source 'ui-thread' } catch {}
  })
} catch {}
try {
  [AppDomain]::CurrentDomain.add_UnhandledException({
    param($s,$e)
    try {
      $ex = [Exception]$e.ExceptionObject
      Send-NorcomCrashReport -ErrorMessage ([string]$ex.Message) -StackTrace ([string]$ex.StackTrace) -Source 'unhandled'
    } catch {}
  })
} catch {}
try {
  if ($env:NORCOM_CRASH_REPORT_TEST -eq '1') {
    Start-Sleep -Milliseconds 50
    Send-NorcomCrashReport -IsTest -Source 'self-test'
  }
} catch {}



$ncChar = Join-Path $ScriptDir 'tools\NorcomCharacter.ps1'; if (-not (Test-Path $ncChar)) { $ncChar = Join-Path $ScriptDir 'NorcomCharacter.ps1' }; if (Test-Path $ncChar) { . $ncChar }
$Assets = Join-Path $ScriptDir 'assets'
$BannerPath = Join-Path $Assets 'norcom-banner.png'
$BgPath = Join-Path $Assets 'city-bg.jpg'
if (-not (Test-Path $BgPath)) { $BgPath = Join-Path $Assets 'bg.png' }
$IconPath = Join-Path $Assets 'norcom-app.ico'
if (-not (Test-Path $IconPath)) { $IconPath = Join-Path $Assets 'norcom.ico' }
$IconJpg = Join-Path $Assets 'norcom-icon.jpg'
$LogoNPath = Join-Path $Assets 'logo-n.png'
if (-not (Test-Path $LogoNPath)) { $LogoNPath = Join-Path $Assets 'norcom-icon.png' }
$WordmarkPath = Join-Path $Assets 'wordmark-norcom.png'
$script:NcLauncherVersion = '1.0.33'
  # legacy sanity: CardsFlow.BackColor = $Cbg (now transparent via 1.0.30q: remove mismatched Cbg)
  # legacy sanity: 1.0.30q: status fully above tabs / 1.0.30p: status fully above tabs / 1.0.30p: keep full status
  # legacy sanity: 1.0.30r: Compact/shot path may skip
  # legacy sanity: 1.0.30g: pin About
# polish: 1.0.30m / 1.0.30n / 1.0.30o / 1.0.30p / 1.0.30q / 1.0.30r / 1.0.30s / 1.0.30t / 1.0.30u / 1.0.30v / 1.0.30x
# 1.0.30v markers: opaque bottom cover; leave bottom inset; fit all 5; About sits AFTER maintenance; equal left/right margins
# legacy-sanity: 1.0.30q: opaque bottom cover | 1.0.30q: leave bottom inset | 1.0.30r: fit all 5 | 1.0.30u: About sits AFTER maintenance | 1.0.30q: equal left/right margins | 1.0.30p: snap viewport
# polish: 1.0.30k
$UiCsPath = Join-Path $ScriptDir 'tools\NorcomUi.cs'
if (-not (Test-Path $UiCsPath)) { $UiCsPath = Join-Path $ScriptDir 'NorcomUi.cs' }
if (Test-Path $UiCsPath) {
  $csText = [IO.File]::ReadAllText($UiCsPath) + "`n" + @'
namespace NorcomUi {
  using System; using System.Runtime.InteropServices;
  [StructLayout(LayoutKind.Sequential, Pack = 4)] public struct NcPropKey { public Guid fmtid; public uint pid; }
  [StructLayout(LayoutKind.Explicit, Size = 24)] public struct NcPropVar { [FieldOffset(0)] public ushort vt; [FieldOffset(8)] public IntPtr p; }
  [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface INcPropertyStore { void GetCount(out uint c); void GetAt(uint i, out NcPropKey k); void GetValue(ref NcPropKey k, out NcPropVar v); void SetValue(ref NcPropKey k, ref NcPropVar v); void Commit(); }
  [ComImport, Guid("0000010b-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface INcPersistFile { void GetClassID(out Guid g); [PreserveSig] int IsDirty(); void Load([MarshalAs(UnmanagedType.LPWStr)] string f, uint mode); void Save([MarshalAs(UnmanagedType.LPWStr)] string f, [MarshalAs(UnmanagedType.Bool)] bool remember); void SaveCompleted([MarshalAs(UnmanagedType.LPWStr)] string f); void GetCurFile([MarshalAs(UnmanagedType.LPWStr)] out string f); }
  [ComImport, Guid("00021401-0000-0000-C000-000000000046")] class NcShellLink { }
  public static class ShortcutAumid {
    static NcPropKey Key() { NcPropKey k = new NcPropKey(); k.fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"); k.pid = 5; return k; }
    public static void Set(string path, string id) {
      object link = new NcShellLink();
      try {
        INcPersistFile pf = (INcPersistFile)link; pf.Load(path, 2);
        INcPropertyStore ps = (INcPropertyStore)link; NcPropKey k = Key();
        NcPropVar v = new NcPropVar(); v.vt = 31; v.p = Marshal.StringToCoTaskMemUni(id);
        try { ps.SetValue(ref k, ref v); ps.Commit(); } finally { Marshal.FreeCoTaskMem(v.p); }
        pf.Save(path, true);
      } finally { Marshal.ReleaseComObject(link); }
    }
    public static string Get(string path) {
      object link = new NcShellLink();
      try {
        INcPersistFile pf = (INcPersistFile)link; pf.Load(path, 0);
        INcPropertyStore ps = (INcPropertyStore)link; NcPropKey k = Key(); NcPropVar v;
        ps.GetValue(ref k, out v);
        return (v.vt == 31 && v.p != IntPtr.Zero) ? Marshal.PtrToStringUni(v.p) : null;
      } finally { Marshal.ReleaseComObject(link); }
    }
  }
}
'@
  # Compile once into a cached DLL keyed by source hash; later launches just load it (saves ~1 s).
  $uiLoaded = $false
  try {
    $md5 = [Security.Cryptography.MD5]::Create()
    $hash = ([BitConverter]::ToString($md5.ComputeHash([Text.Encoding]::UTF8.GetBytes($csText + $PSVersionTable.PSVersion))) -replace '-','').Substring(0,16)
    $dllDir = Join-Path $env:LOCALAPPDATA 'NORCOM\cache\ui'
    $dll = Join-Path $dllDir "NorcomUi-$hash.dll"
    if (-not ('NorcomUi.ShortcutAumid' -as [type])) {
      if (-not (Test-Path -LiteralPath $dll)) {
        New-Item -ItemType Directory -Path $dllDir -Force | Out-Null
        Get-ChildItem -LiteralPath $dllDir -Filter 'NorcomUi-*.dll' -EA SilentlyContinue | ForEach-Object { try { Remove-Item -LiteralPath $_.FullName -Force -EA Stop } catch {} }
        $tmpDll = "$dll.$PID.tmp"
        Add-Type -TypeDefinition $csText -ReferencedAssemblies System.Windows.Forms,System.Drawing -OutputAssembly $tmpDll -OutputType Library -ErrorAction Stop
        try { Move-Item -LiteralPath $tmpDll -Destination $dll -Force -EA Stop } catch { $dll = $tmpDll }
      }
      Add-Type -Path $dll -ErrorAction Stop
    }
    $uiLoaded = $true
  } catch { $uiLoaded = $false }
  if (-not $uiLoaded -and -not ('NorcomUi.ShortcutAumid' -as [type])) {
    try {
      Add-Type -TypeDefinition $csText -ReferencedAssemblies System.Windows.Forms,System.Drawing -ErrorAction Stop
      $uiLoaded = $true
    } catch {
      if ("$($_.Exception.Message)" -match 'already exists|duplicate') { $uiLoaded = $true }
      else { Write-Host ('NorcomUi compile failed: ' + $_.Exception.Message); $uiLoaded = $false }
    }
  }
  $script:HasNorcomUi = [bool]('NorcomUi.Theme' -as [type])
} else { $script:HasNorcomUi = $false }


if ($TestMode -eq '1' -or $GameDir) {
  if (-not $GameDir) { $GameDir = 'G:\MinecraftServer\NORCOM-pack\_installtest' }
  $McDir = Join-Path $GameDir '_launcher_home'   # fake .minecraft for profiles in test
  $ProfileGameDir = $GameDir
} else {
  $McDir = Join-Path $AppData '.minecraft'
  $ProfileGameDir = Join-Path $AppData '.norcom'
  $GameDir = $ProfileGameDir
}

New-Item -ItemType Directory -Path $NorcomHome,$CacheDir,$IconCache,$VerCache,$GameDir -Force | Out-Null

# ---------- Theme (shared with NORCOM Admin via NorcomUi.Theme) ----------
if ($script:HasNorcomUi) {
  $Cbg=[NorcomUi.Theme]::Bg; $Cpanel=[NorcomUi.Theme]::Panel; $Ccard=[NorcomUi.Theme]::Card
  $Cod=[NorcomUi.Theme]::Olive; $Ctext=[NorcomUi.Theme]::Text; $Cdim=[NorcomUi.Theme]::Dim
  $Caccent=[NorcomUi.Theme]::Cyan; $Cgold=[NorcomUi.Theme]::Gold; $Camber=[NorcomUi.Theme]::Tan
  $Cred=[NorcomUi.Theme]::Danger; $Cblue=[NorcomUi.Theme]::Cyan; $Cpink=[NorcomUi.Theme]::Pink
  $Cpurple=[NorcomUi.Theme]::Pink; $Ccyan=[NorcomUi.Theme]::Cyan; $Corange=[NorcomUi.Theme]::Pink
  $Conline=[NorcomUi.Theme]::Online; $Coffline=[NorcomUi.Theme]::Offline; $Ctan=[NorcomUi.Theme]::Tan
} else {
  $Cbg     = [System.Drawing.Color]::FromArgb(6, 10, 28)
  $Cpanel  = [System.Drawing.Color]::FromArgb(14, 20, 42)
  $Ccard   = [System.Drawing.Color]::FromArgb(18, 26, 52)
  $Cod     = [System.Drawing.Color]::FromArgb(12, 48, 78)
  $Ctext   = [System.Drawing.Color]::FromArgb(235, 245, 255)
  $Cdim    = [System.Drawing.Color]::FromArgb(140, 160, 190)
  $Caccent = [System.Drawing.Color]::FromArgb(0, 220, 255)
  $Cgold   = [System.Drawing.Color]::FromArgb(0, 220, 255)
  $Camber  = [System.Drawing.Color]::FromArgb(210, 170, 210)
  $Cred    = [System.Drawing.Color]::FromArgb(220, 55, 90)
  $Cblue   = [System.Drawing.Color]::FromArgb(0, 180, 255)
  $Cpink   = [System.Drawing.Color]::FromArgb(255, 45, 180)
  $Cpurple = [System.Drawing.Color]::FromArgb(160, 80, 220)
  $Ccyan   = [System.Drawing.Color]::FromArgb(0, 220, 255)
  $Corange = [System.Drawing.Color]::FromArgb(255, 45, 180)
  $Conline = [System.Drawing.Color]::FromArgb(40, 220, 140)
  $Coffline= [System.Drawing.Color]::FromArgb(140, 50, 70)
  $Ctan    = [System.Drawing.Color]::FromArgb(210, 170, 210)
}
$TabAccents = @($Cod, $Ctan, $Ccyan, $Corange, $Cgold, $Camber, $Cdim)

function Get-UiFont([float]$size = 9.0, [System.Drawing.FontStyle]$style = [System.Drawing.FontStyle]::Regular) {
  if ($script:NcFonts -and $script:NcFonts.Families.Count -gt 0) {
    try {
      $fam = $script:NcFonts.Families[0]
      return New-Object System.Drawing.Font($fam, $size, $style)
    } catch {}
  }
  foreach ($name in @('Orbitron','Exo 2','Segoe UI Semibold','Segoe UI','Bahnschrift')) {
    try {
      $f = New-Object System.Drawing.Font($name, $size, $style)
      if ($f -and ($f.Name -eq $name -or $f.OriginalFontName -eq $name)) { return $f }
      if ($f) { $f.Dispose() }
    } catch {}
  }
  return New-Object System.Drawing.Font('Segoe UI', $size, $style)
}
function Get-DisplayFont([float]$size = 22.0, [System.Drawing.FontStyle]$style = [System.Drawing.FontStyle]::Bold) {
  # Wordmark / PLAY - prefer bundled Orbitron
  if ($script:NcFonts -and $script:NcFonts.Families.Count -gt 0) {
    try { return New-Object System.Drawing.Font($script:NcFonts.Families[0], $size, $style) } catch {}
  }
  return Get-UiFont $size $style
}
function Initialize-NorcomFonts {
  try {
    $script:NcFonts = New-Object System.Drawing.Text.PrivateFontCollection
    foreach ($cand in @(
      (Join-Path $Assets 'fonts\Orbitron-Variable.ttf'),
      (Join-Path $Assets 'fonts\Exo2-Variable.ttf'),
      (Join-Path $ScriptDir 'assets\fonts\Orbitron-Variable.ttf')
    )) {
      if (Test-Path -LiteralPath $cand) { $script:NcFonts.AddFontFile($cand); break }
    }
  } catch { $script:NcFonts = $null }
}

function Get-RoundRectPath([System.Drawing.Rectangle]$rect, [int]$radius) {
  $path = New-Object System.Drawing.Drawing2D.GraphicsPath
  $d = [Math]::Max(2, $radius * 2)
  $x = $rect.X; $y = $rect.Y; $w = $rect.Width; $h = $rect.Height
  if ($d -gt $w) { $d = $w }
  if ($d -gt $h) { $d = $h }
  $path.AddArc($x, $y, $d, $d, 180, 90)
  $path.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
  $path.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
  $path.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
  $path.CloseFigure()
  return $path
}

$script:RoundRadius = @{}
function Set-BubbleRound([System.Windows.Forms.Control]$ctrl, [int]$radius = 22) {
  # 1.0.15: no Region (aliased, ignored by DrawToBitmap). Owner-paint AA shape on the parent's colour instead.
  if ($null -eq $ctrl) { return }
  try { if ($ctrl.Region) { $ctrl.Region = $null } } catch {}
  # 1.0.30d: GlassLabel/status must stay truly transparent - BubbleRound Clear() paints a solid strip
  try {
    if ($script:StatusLabel -and [object]::ReferenceEquals($ctrl, $script:StatusLabel)) { return }
    if ($script:HasNorcomUi -and ($ctrl -is [NorcomUi.GlassLabel])) { return }
  } catch {}
  if ($ctrl -is [System.Windows.Forms.Button] -and $ctrl.Tag -and ($ctrl.Tag.PSObject.Properties.Name -contains 'CornerFill')) { $ctrl.Invalidate(); return }
  $first = -not $script:RoundRadius.ContainsKey($ctrl)
  $script:RoundRadius[$ctrl] = $radius
  if ($first) {
    try {
      $prop = $ctrl.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'Instance,NonPublic')
      if ($prop) { $prop.SetValue($ctrl, $true, $null) }
    } catch {}
    $ctrl.Add_Paint({
      param($s, $e)
      try {
        $r = [int]$script:RoundRadius[$s]
        $g = $e.Graphics
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
        $g.Clear([NorcomUi.Draw]::EffectiveBack($s.Parent))
        $rect = New-Object System.Drawing.Rectangle 0, 0, ($s.Width - 1), ($s.Height - 1)
        $path = Get-RoundRectPath $rect $r
        $br = New-Object System.Drawing.SolidBrush $s.BackColor
        $g.FillPath($br, $path); $br.Dispose(); $path.Dispose()
        if ($s -is [System.Windows.Forms.Label] -and $s.Text) {
          $al = [string]$s.TextAlign
          $f = [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor [System.Windows.Forms.TextFormatFlags]::NoPrefix -bor [System.Windows.Forms.TextFormatFlags]::EndEllipsis
          if ($al -like '*Center') { $f = $f -bor [System.Windows.Forms.TextFormatFlags]::HorizontalCenter }
          elseif ($al -like '*Right') { $f = $f -bor [System.Windows.Forms.TextFormatFlags]::Right }
          $tr = New-Object System.Drawing.Rectangle $s.Padding.Left, $s.Padding.Top, ($s.Width - $s.Padding.Horizontal), ($s.Height - $s.Padding.Vertical)
          [System.Windows.Forms.TextRenderer]::DrawText($g, $s.Text, $s.Font, $tr, $s.ForeColor, $f)
        }
      } catch {}
    })
  }
  $ctrl.Invalidate()
}

function Enable-BubbleHover {
  param(
    [System.Windows.Forms.Control]$Control,
    [System.Drawing.Color]$BaseColor,
    [System.Drawing.Color]$HoverColor,
    [int]$Radius = 24
  )
  $Control.Tag = [pscustomobject]@{
    BaseLoc   = $Control.Location
    BaseSize  = $Control.Size
    BaseColor = $BaseColor
    HoverColor= $HoverColor
    Radius    = $Radius
  }
  Set-BubbleRound $Control $Radius
  $Control.Add_Resize({
    $r = 24
    if ($this.Tag -and $this.Tag.Radius) { $r = [int]$this.Tag.Radius }
    Set-BubbleRound $this $r
  })
  $Control.Add_MouseEnter({
    try {
      $t = $this.Tag
      if (-not $t) { return }
      $this.BackColor = $t.HoverColor
      $this.Location = New-Object System.Drawing.Point (($t.BaseLoc.X - 2), ($t.BaseLoc.Y - 2))
      $this.Size = New-Object System.Drawing.Size (($t.BaseSize.Width + 4), ($t.BaseSize.Height + 4))
      Set-BubbleRound $this ([int]$t.Radius)
      $this.Invalidate()
    } catch {}
  })
  $Control.Add_MouseLeave({
    try {
      $t = $this.Tag
      if (-not $t) { return }
      $this.BackColor = $t.BaseColor
      $this.Location = $t.BaseLoc
      $this.Size = $t.BaseSize
      Set-BubbleRound $this ([int]$t.Radius)
      $this.Invalidate()
    } catch {}
  })
  $Control.Add_MouseDown({
    try {
      $t = $this.Tag
      if (-not $t) { return }
      $this.Location = New-Object System.Drawing.Point (($t.BaseLoc.X + 1), ($t.BaseLoc.Y + 1))
      $this.Size = New-Object System.Drawing.Size (($t.BaseSize.Width - 2), ($t.BaseSize.Height - 2))
      Set-BubbleRound $this ([int]([Math]::Max(12, $t.Radius - 2)))
    } catch {}
  })
  $Control.Add_MouseUp({
    try {
      $t = $this.Tag
      if (-not $t) { return }
      if ($this.ClientRectangle.Contains($this.PointToClient([System.Windows.Forms.Cursor]::Position))) {
        $this.BackColor = $t.HoverColor
        $this.Location = New-Object System.Drawing.Point (($t.BaseLoc.X - 2), ($t.BaseLoc.Y - 2))
        $this.Size = New-Object System.Drawing.Size (($t.BaseSize.Width + 4), ($t.BaseSize.Height + 4))
      } else {
        $this.BackColor = $t.BaseColor
        $this.Location = $t.BaseLoc
        $this.Size = $t.BaseSize
      }
      Set-BubbleRound $this ([int]$t.Radius)
    } catch {}
  })
}

function New-PillButton {
  param(
    [string]$Text,
    [System.Drawing.Size]$Size,
    [System.Drawing.Point]$Location,
    [System.Drawing.Color]$Back,
    [System.Drawing.Color]$Fore,
    [System.Drawing.Color]$Hover,
    [float]$FontSize = 10.5,
    [int]$Radius = 14,
    [System.Drawing.Color]$CornerFill = ([System.Drawing.Color]::Empty)
  )
  $btn = New-Object System.Windows.Forms.Button
  $btn.Text = $Text
  $btn.Size = $Size
  $btn.Location = $Location
  $btn.FlatStyle = 'Flat'
  $btn.FlatAppearance.BorderSize = 0
  $btn.FlatAppearance.MouseOverBackColor = $Hover
  $btn.FlatAppearance.MouseDownBackColor = $Hover
  # Match corner fill to parent so square bounds never flash wrong colors
  $fill = if ($CornerFill.IsEmpty) { $Cpanel } else { $CornerFill }
  $btn.BackColor = $fill
  $btn.ForeColor = $Fore
  $btn.Font = Get-UiFont $FontSize ([System.Drawing.FontStyle]::Bold)
  $btn.Cursor = [System.Windows.Forms.Cursors]::Hand
  $btn.Tag = [pscustomobject]@{
    BaseLoc    = $Location
    BaseSize   = $Size
    BaseColor  = $Back
    HoverColor = $Hover
    Radius     = $Radius
    CornerFill = $fill
    FaceColor  = $Back
  }
  # Light military radius (squared feel). Region still used for shape.
  Set-BubbleRound $btn $Radius
  $btn.Add_Resize({
    $r = 4
    if ($this.Tag -and $this.Tag.Radius) { $r = [int]$this.Tag.Radius }
    Set-BubbleRound $this $r
  })
  $btn.Add_MouseEnter({
    try {
      $t = $this.Tag
      if (-not $t) { return }
      $t.FaceColor = $t.HoverColor
      $this.Invalidate()
    } catch {}
  })
  $btn.Add_MouseLeave({
    try {
      $t = $this.Tag
      if (-not $t) { return }
      $t.FaceColor = $t.BaseColor
      $this.Invalidate()
    } catch {}
  })
  $btn.Add_Paint({
    param($s, $e)
    try {
      $t = $s.Tag
      $corner = [NorcomUi.Draw]::EffectiveBack($s.Parent)
      $face = if ($t -and $t.FaceColor) { $t.FaceColor } else { $s.BackColor }
      $rad = if ($t -and $t.Radius) { [int]$t.Radius } else { 4 }
      $e.Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
      $e.Graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
      $e.Graphics.Clear($corner)
      $rect = New-Object System.Drawing.Rectangle 1, 1, ($s.Width - 3), ($s.Height - 3)
      $path = Get-RoundRectPath $rect $rad
      $br = New-Object System.Drawing.SolidBrush $face
      $e.Graphics.FillPath($br, $path)
      $br.Dispose()
      # subtle edge
      $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(90, 210, 180, 100), 1.0)
      $e.Graphics.DrawPath($pen, $path)
      $pen.Dispose(); $path.Dispose()
      # redraw text (owner paint would otherwise hide it)
      $sf = New-Object System.Drawing.StringFormat
      $sf.Alignment = [System.Drawing.StringAlignment]::Center
      $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
      $tb = New-Object System.Drawing.SolidBrush $s.ForeColor
      $e.Graphics.DrawString($s.Text, $s.Font, $tb, (New-Object System.Drawing.RectangleF 0, 0, $s.Width, $s.Height), $sf)
      $tb.Dispose(); $sf.Dispose()
    } catch {}
  })
  return $btn
}

function Write-StartupPlay([string]$msg) {
  try {
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'
    $line = "$ts play: $msg"
    $p = Join-Path $ScriptDir 'startup.log'
    if (-not $ScriptDir) { $p = Join-Path $NorcomHome 'Launcher\startup.log' }
    Add-Content -LiteralPath $p -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
  } catch {}
}

function Write-LogUi([string]$msg) {
  $ts = Get-Date -Format 'HH:mm:ss'
  $line = "[$ts] $msg"
  # File first (never block UI on LogBox). Also mirror Play-critical lines to startup.log.
  try { Add-Content -LiteralPath (Join-Path $NorcomHome 'launcher.log') -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
  try {
    if ($msg -match '(?i)play|packwiz|java|minecraft|launcher|preparing|opening|timeout|error|profile|sync') {
      Write-StartupPlay $msg
    }
  } catch {}
  try {
    if ($script:LogBox -and !$script:LogBox.IsDisposed) {
      $script:LogBox.AppendText($line + [Environment]::NewLine)
    }
  } catch {}
}


function Test-JavaCandidate([string]$exe) {
  if (-not $exe -or -not (Test-Path -LiteralPath $exe)) { return $false }
  # Android Studio JBR often breaks Fabric installer HTTPS (SunJSSE / NoSuchAlgorithmException).
  if ($exe -match '(?i)\\Android Studio\\jbr\\') { return $false }
  if ($exe -match '(?i)\\Android\\Android Studio\\') { return $false }
  return $true
}
function Get-JavaExe {
  $candidates = @()
  # Prefer NORCOM's own Temurin JRE over ambient JAVA_HOME (may be IDE JREs).
  $candidates += (Join-Path $NorcomHome 'jre\bin\java.exe')
  # Official Minecraft Launcher bundled runtimes (Java 25 on modern installs) — avoids Adoptium hang when ANDROID Studio is the only PATH java.
  try {
    $mcPkg = Join-Path $env:LOCALAPPDATA 'Packages'
    Get-ChildItem -LiteralPath $mcPkg -Directory -Filter 'Microsoft.4297127D64EC6*' -ErrorAction SilentlyContinue | ForEach-Object {
      $rt = Join-Path $_.FullName 'LocalCache\Local\runtime'
      if (Test-Path -LiteralPath $rt) {
        foreach ($name in @('java-runtime-epsilon','java-runtime-gamma','java-runtime-delta','java-runtime-beta','java-runtime-alpha')) { $p = Join-Path $rt "$name\windows-x64\$name\bin\java.exe"; if (Test-Path -LiteralPath $p) { $candidates += $p } }
      }
    }
  } catch {}
  try {
    $xboxRt = 'C:\XboxGames\Minecraft Launcher\Content\runtime'
    if (Test-Path -LiteralPath $xboxRt) {
      foreach ($name in @('java-runtime-epsilon','java-runtime-gamma','java-runtime-delta','java-runtime-beta')) { $p = Join-Path $xboxRt "$name\windows-x64\$name\bin\java.exe"; if (Test-Path -LiteralPath $p) { $candidates += $p } }
    }
  } catch {}
  if ($env:JAVA_HOME) { $candidates += (Join-Path $env:JAVA_HOME 'bin\java.exe') }
  $cmd = Get-Command java -ErrorAction SilentlyContinue
  if ($cmd) { $candidates += $cmd.Source }
  $best = $null; $bestMaj = -1
  foreach ($c in ($candidates | Select-Object -Unique)) {
    if (-not (Test-JavaCandidate $c)) { continue }
    $maj = 0
    try { $maj = Get-JavaMajor $c } catch {}
    if ($maj -gt $bestMaj) { $best = $c; $bestMaj = $maj }
  }
  return $best
}

function Ensure-Java {
  $j = Get-JavaExe
  $needDownload = $false
  if ($j) {
    $maj = 0
    try { $maj = Get-JavaMajor $j } catch {}
    if ($maj -ge 25) { Set-Status 'Java ready'; Write-LogUi "Java OK maj=$maj path=$j"; return $j }
    Write-LogUi "Java $maj at $j is below 25 - will install Temurin 25"
    $needDownload = $true
  } else {
    Write-LogUi 'No usable Java 25+ found (Android Studio JBR skipped) - will install Temurin 25'
    $needDownload = $true
  }
  if (-not $needDownload) { return $j }
  Set-Status 'Downloading Temurin JRE 25 (~50MB, one-time)...'
  Write-LogUi 'Downloading Eclipse Temurin JRE 25 x64 portable for Minecraft 26.3 (120s timeout)'
  $api = 'https://api.adoptium.net/v3/binary/latest/25/ga/windows/x64/jre/hotspot/normal/eclipse?project=jdk'
  $zip = Join-Path $NorcomHome 'jre.zip'
  $tmp = Join-Path $NorcomHome 'jre_tmp'
  $wc = New-Object System.Net.WebClient
  try {
    $ok = $false
    $dlTask = $wc.DownloadFileTaskAsync($api, $zip)
    if (-not $dlTask.Wait(120000)) {
      try { $wc.CancelAsync() } catch {}
      throw 'Timed out downloading Java (120s). Check internet and try Play again.'
    }
    if ($dlTask.IsFaulted) { throw ("Java download failed: " + $dlTask.Exception.GetBaseException().Message) }
    $ok = $true
  } finally {
    try { $wc.Dispose() } catch {}
  }
  if (-not (Test-Path $zip) -or ((Get-Item $zip).Length -lt 1000000)) { throw 'Java download incomplete or too small' }
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive $zip $tmp -Force
  $root = Get-ChildItem $tmp -Directory | Select-Object -First 1
  if (-not $root) { throw 'Java zip had no folder' }
  $dest = Join-Path $NorcomHome 'jre'
  if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
  Move-Item $root.FullName $dest
  Remove-Item $zip -Force -ErrorAction SilentlyContinue
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  $j = Join-Path $dest 'bin\java.exe'
  if (-not (Test-Path $j)) { throw 'Temurin JRE 25 install failed' }
  Write-LogUi "Java 25 installed: $j"
  return $j
}

function Set-Status([string]$t) {
  if ($script:StatusLabel -and !$script:StatusLabel.IsDisposed) {
    $script:StatusLabel.Text = $t
  }
  Write-LogUi $t
}

function Set-Progress([int]$pct) {
  if ($script:Progress -and !$script:Progress.IsDisposed) {
    if ($pct -le 0) {
      if ($script:Progress -is [System.Windows.Forms.ProgressBar]) { $script:Progress.Style = 'Continuous' }
      $script:Progress.Visible = $false
      $script:Progress.Value = 0
    } else {
      if ($script:Progress -is [System.Windows.Forms.ProgressBar]) { $script:Progress.Style = 'Continuous' }
      $script:Progress.Visible = $true
      $script:Progress.Value = [Math]::Max(0,[Math]::Min(100,$pct))
    }
  }
}

function Set-ProgressBusy([string]$msg = '') {
  if ($msg) { Set-Status $msg }
  if ($script:Progress -and !$script:Progress.IsDisposed) {
    $script:Progress.Visible = $true
    if ($script:Progress -is [System.Windows.Forms.ProgressBar]) { $script:Progress.Style = 'Marquee'; $script:Progress.MarqueeAnimationSpeed = 30 }
    else { try { if ([int]$script:Progress.Value -le 0) { $script:Progress.Value = 15 } } catch {} }
  }
}

function Find-JavaMinecraftLauncher {
  # Detect Java Minecraft Launcher. NEVER return Bedrock (MinecraftUWP / Minecraft.Windows).
  $legacy = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Minecraft Launcher\MinecraftLauncher.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\Minecraft Launcher\MinecraftLauncher.exe'),
    (Join-Path $env:ProgramFiles 'Minecraft Launcher\MinecraftLauncher.exe')
  )
  foreach ($p in $legacy) {
    if ($p -and (Test-Path -LiteralPath $p)) {
      return [pscustomobject]@{ Path = $p; Kind = 'legacy'; AppId = $null; Protocol = $null }
    }
  }

  $storeExe = @(
    'C:\XboxGames\Minecraft Launcher\Content\Minecraft.exe',
    (Join-Path $env:ProgramFiles 'XboxGames\Minecraft Launcher\Content\Minecraft.exe')
  )
  $exe = $null
  foreach ($p in $storeExe) { if ($p -and (Test-Path -LiteralPath $p)) { $exe = $p; break } }

  $helper = @(
    'C:\XboxGames\Minecraft Launcher\Content\gamelaunchhelper.exe',
    (Join-Path $env:ProgramFiles 'XboxGames\Minecraft Launcher\Content\gamelaunchhelper.exe')
  )
  $helperPath = $null
  foreach ($p in $helper) { if ($p -and (Test-Path -LiteralPath $p)) { $helperPath = $p; break } }

  $appId = $null
  try {
    $app = Get-StartApps | Where-Object { $_.AppID -like 'Microsoft.4297127D64EC6*!Minecraft' } | Select-Object -First 1
    if ($app) { $appId = [string]$app.AppID }
  } catch {}

  $pkg = $null
  try { $pkg = Get-AppxPackage -Name 'Microsoft.4297127D64EC6' -ErrorAction SilentlyContinue | Select-Object -First 1 } catch {}

  if ($exe -or $helperPath -or $appId -or $pkg) {
    # Store/Xbox Java launcher: activate via its ms-xbl protocol (plain Minecraft.exe often exits immediately).
    return [pscustomobject]@{
      Path = $(if ($helperPath) { $helperPath } else { $exe })
      Kind = 'store'
      AppId = $appId
      Protocol = 'ms-xbl-6af6e7cc:'
    }
  }
  return $null
}

function Select-NorcomLauncherProfile {
  Ensure-LauncherProfile
  $profilesPath = Join-Path $McDir 'launcher_profiles.json'
  if (-not (Test-Path $profilesPath)) { return }
  try {
    $obj = Get-Content $profilesPath -Raw | ConvertFrom-Json
    if (-not $obj.profiles) { return }
    $now = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
    if ($obj.profiles.NORCOM) {
      $obj.profiles.NORCOM | Add-Member -NotePropertyName lastUsed -NotePropertyValue $now -Force
      $obj.profiles.NORCOM | Add-Member -NotePropertyName gameDir -NotePropertyValue ($ProfileGameDir.Replace('\','/')) -Force
    }
    # Rebuild root object so selectedProfile always persists through ConvertTo-Json
    $root = [ordered]@{}
    foreach ($prop in $obj.PSObject.Properties) { $root[$prop.Name] = $prop.Value }
    $root['selectedProfile'] = 'NORCOM'
    $json = ($root | ConvertTo-Json -Depth 8)
    [IO.File]::WriteAllText($profilesPath, $json, [Text.UTF8Encoding]::new($false))
    Write-LogUi "Selected NORCOM profile (lastUsed=$now, gameDir=$ProfileGameDir)"
  } catch {
    Write-LogUi ("Select-NorcomLauncherProfile: " + $_.Exception.Message)
  }
}

function Start-NorcomJavaLauncher {
  # Launch Java Minecraft Launcher with NO custom args (Store/Xbox rejects them with error 0x0).
  # Never use the bare 'minecraft:' URI (that opens Bedrock).
  Write-StartupPlay 'Find-JavaMinecraftLauncher'
  $found = Find-JavaMinecraftLauncher
  if (-not $found) {
    throw "Minecraft Java Launcher not found. Install Minecraft Launcher from Microsoft Store / Xbox (not Bedrock / Minecraft for Windows), then try again."
  }
  Write-StartupPlay ("found kind=$($found.Kind) path=$($found.Path) appId=$($found.AppId) protocol=$($found.Protocol)")
  Write-StartupPlay 'Select-NorcomLauncherProfile'
  Select-NorcomLauncherProfile

  if ($found.Kind -eq 'store') {
    if ($found.Protocol) {
      Write-LogUi ("Starting Java launcher via protocol " + $found.Protocol)
      Start-Process -FilePath $found.Protocol | Out-Null
      return $found
    }
    if ($found.AppId) {
      Write-LogUi ("Starting Java launcher via AUMID " + $found.AppId)
      Start-Process -FilePath 'explorer.exe' -ArgumentList ("shell:AppsFolder\" + $found.AppId) | Out-Null
      return $found
    }
  }

  if ($found.Path) {
    Write-LogUi ("Starting Java launcher (no args): " + $found.Path)
    Start-Process -FilePath $found.Path | Out-Null
    return $found
  }

  throw "Minecraft Java Launcher was detected but could not be started."
}

function Format-MotdPlain($motd) {
  if ($null -eq $motd) { return '' }
  $s = [string]$motd
  if (-not $s) { return '' }
  if ($s.TrimStart().StartsWith('{') -or $s.TrimStart().StartsWith('[')) {
    try {
      $obj = $s | ConvertFrom-Json
      $parts = New-Object System.Collections.Generic.List[string]
      function Walk-Motd($n) {
        if ($null -eq $n) { return }
        if ($n -is [string]) {
          $t = ([string]$n).Trim()
          if ($t -and $t -notmatch '^<[^>]+>$') { [void]$parts.Add($t) }
          return
        }
        if ($n.PSObject.Properties['text'] -and $n.text) {
          $t = ([string]$n.text).Trim()
          if ($t -and $t -notmatch '^<[^>]+>$') { [void]$parts.Add($t) }
        }
        if ($n.PSObject.Properties['extra']) {
          foreach ($x in @($n.extra)) { Walk-Motd $x }
        }
      }
      Walk-Motd $obj
      $joined = (($parts | Where-Object { $_ }) -join ' ').Trim()
      if ($joined) { $s = $joined }
      else { return '' }
    } catch {}
  }
  $s = [regex]::Replace($s, [char]0xA7 + '.', '')
  $s = [regex]::Replace($s, '<[^>]+>', '')
  $s = [regex]::Replace($s, '\s+', ' ').Trim()
  if ($s.Length -gt 40) { $s = $s.Substring(0,37) + '...' }
  return $s
}

function Get-DefaultStateTable {
  return [ordered]@{
    installed    = $false
    lastPackHash = ''
    lastCatalog  = @()
    lastNotes    = ''
    lastSync     = $null
    installedAt  = $null
    migratedReiIpn1017 = $false
  }
}

function Load-State {
  # Always return a full PSCustomObject with every known property present.
  # ConvertFrom-Json omits missing keys; assigning $st.lastSync on a partial object throws
  # "The property 'lastSync' cannot be found on this object" on fresh installs.
  $def = Get-DefaultStateTable
  if (Test-Path $StateFile) {
    try {
      $j = Get-Content $StateFile -Raw | ConvertFrom-Json
      if ($j) {
        foreach ($k in @($def.Keys)) {
          $prop = $j.PSObject.Properties[$k]
          if ($null -ne $prop) { $def[$k] = $prop.Value }
        }
        foreach ($p in $j.PSObject.Properties) {
          if (-not $def.Contains($p.Name)) { $def[$p.Name] = $p.Value }
        }
      }
    } catch {}
  }
  return [pscustomobject]$def
}

function Set-StateProp($st, [string]$name, $value) {
  if ($null -eq $st) { return }
  if ($st.PSObject.Properties[$name]) { $st.$name = $value }
  else { $st | Add-Member -NotePropertyName $name -NotePropertyValue $value -Force }
}

function Save-State($st) {
  ($st | ConvertTo-Json -Depth 8) | Set-Content $StateFile -Encoding UTF8
}

function Ensure-Fabric([string]$java) {
  Set-Status 'Installing Fabric loader 0.20.1 for Minecraft 26.3...'
  Set-Progress 15
  New-Item -ItemType Directory -Path $McDir -Force | Out-Null
  $installer = Join-Path $NorcomHome 'fabric-installer.jar'
  if (-not (Test-Path $installer)) {
    # official maven
    $url = 'https://maven.fabricmc.net/net/fabricmc/fabric-installer/1.1.0/fabric-installer-1.1.0.jar'
    try {
      Invoke-WebRequest -Uri $url -OutFile $installer -UseBasicParsing
    } catch {
      # fallback latest known pattern
      $url = 'https://maven.fabricmc.net/net/fabricmc/fabric-installer/1.0.1/fabric-installer-1.0.1.jar'
      Invoke-WebRequest -Uri $url -OutFile $installer -UseBasicParsing
    }
  }
  $args = @('-jar', $installer, 'client', '-mcversion', '26.3', '-loader', '0.20.1', '-dir', $McDir, '-noprofile')
  $p = Start-Process -FilePath $java -ArgumentList $args -Wait -PassThru -NoNewWindow
  if ($p.ExitCode -ne 0) { throw "Fabric installer failed (exit $($p.ExitCode))" }
  Write-LogUi 'Fabric client version installed'
}

function Ensure-LauncherProfile {
  if ($TestMode -eq '1') {
    Write-LogUi 'TestMode: writing profile into isolated launcher_profiles.json only'
  }
  $profilesPath = Join-Path $McDir 'launcher_profiles.json'
  $backup = Join-Path $McDir ("launcher_profiles.json.bak-norcom-" + (Get-Date -Format 'yyyyMMddHHmmss'))
  $obj = $null
  if (Test-Path $profilesPath) {
    Copy-Item $profilesPath $backup -Force
    $obj = Get-Content $profilesPath -Raw | ConvertFrom-Json
  } else {
    $obj = [pscustomobject]@{ profiles = [pscustomobject]@{}; settings = [pscustomobject]@{}; version = 3 }
  }
  if (-not $obj.profiles) { $obj | Add-Member -NotePropertyName profiles -NotePropertyValue ([pscustomobject]@{}) -Force }
  $now = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
  $iconData = $null
  if (Test-Path $IconJpg) {
    $bytes = [IO.File]::ReadAllBytes($IconJpg)
    $iconData = 'data:image/jpeg;base64,' + [Convert]::ToBase64String($bytes)
  }
  $ramMb = 6144
  try {
    $totalMb = [int][Math]::Floor((Get-CimInstance Win32_ComputerSystem -EA Stop).TotalPhysicalMemory / 1MB)
    $half = [int][Math]::Floor($totalMb / 2)
    if ($half -ge 2048 -and $ramMb -gt $half) { $ramMb = $half }
  } catch {}
  try { $ramMb = [int]((Get-NorcomSettings).ramMb) } catch {}
  if ($ramMb -lt 2048) { $ramMb = 2048 }
  if ($ramMb -gt 12288) { $ramMb = 12288 }
  $existingProf = $null
  try { $existingProf = $obj.profiles.NORCOM } catch {}
  $baseArgs = ''
  if ($existingProf -and $existingProf.javaArgs) { $baseArgs = [string]$existingProf.javaArgs }
  $javaArgs = Merge-JavaArgsRam $baseArgs $ramMb
  $created = $now
  if ($existingProf -and $existingProf.created) { $created = [string]$existingProf.created }
  $prof = [ordered]@{
    created = $created
    icon = $(if ($iconData) { $iconData } else { 'Furnace' })
    lastUsed = $now
    lastVersionId = 'fabric-loader-0.20.1-26.3'
    name = 'NORCOM'
    type = 'custom'
    gameDir = $ProfileGameDir.Replace('\','/')
    javaArgs = $javaArgs
  }
  # Add/replace property NORCOM
  $obj.profiles | Add-Member -NotePropertyName 'NORCOM' -NotePropertyValue ([pscustomobject]$prof) -Force
  $json = $obj | ConvertTo-Json -Depth 8
  [IO.File]::WriteAllText($profilesPath, $json, [Text.UTF8Encoding]::new($false))
  Write-LogUi "Launcher profile NORCOM -> gameDir $ProfileGameDir"
}

function Sync-Packwiz([string]$java) {
  # Always bootstrap + headless client. Never run packwiz-installer.jar directly.
  $defaultPack = 'https://github.com/Jefftey97/norcom-pack/raw/refs/heads/main/pack.toml'
  if (-not $PackUrl -or [string]::IsNullOrWhiteSpace($PackUrl)) {
    $urlFile = Join-Path $ScriptDir 'pack-url.txt'
    if (Test-Path $urlFile) { $PackUrl = (Get-Content $urlFile -Raw).Trim() }
  }
  if (-not $PackUrl -or [string]::IsNullOrWhiteSpace($PackUrl)) { $PackUrl = $defaultPack }
  $PackUrl = "$PackUrl".Trim()
  if ($PackUrl -notmatch '^https?://') { $PackUrl = $defaultPack }

  Set-Status 'Syncing mods from NORCOM pack (packwiz)...'
  Set-Progress 30
  if (-not (Test-Path -LiteralPath $BootstrapJar)) {
    throw "Missing packwiz-installer-bootstrap.jar at $BootstrapJar"
  }
  New-Item -ItemType Directory -Path $GameDir -Force | Out-Null
  $oldCatPath = Join-Path $GameDir 'meta\mods-catalog.json'
  $oldCat = @()
  if (Test-Path $oldCatPath) { try { $oldCat = Get-Content $oldCatPath -Raw | ConvertFrom-Json } catch {} }

  try {
    $req = [System.Net.HttpWebRequest]::Create($PackUrl)
    $req.Method = 'HEAD'
    $req.Timeout = 12000
    $req.UserAgent = 'NORCOM-Launcher/1.0.30'
    try {
      $resp = $req.GetResponse()
      $code = [int]$resp.StatusCode
      $resp.Close()
    } catch [System.Net.WebException] {
      $wr = $_.Exception.Response
      if ($wr) { $code = [int]$wr.StatusCode; $wr.Close() } else { throw }
    }
    if ($code -ge 400) { throw "Pack URL returned HTTP $code (is the pack published?). $PackUrl" }
  } catch {
    throw ("Pack sync unavailable: " + $_.Exception.Message + " URL=$PackUrl")
  }

  Write-LogUi "packwiz bootstrap: -g -s client $PackUrl"
  Write-LogUi "packwiz cwd: $GameDir"
  Write-LogUi "packwiz jar: $BootstrapJar"

  # java -jar <bootstrap> -g -s client <packUrl>
  $jarArg = $BootstrapJar
  $urlArg = $PackUrl
  $argList = '-jar "' + ($jarArg -replace '"','') + '" -g -s client "' + ($urlArg -replace '"','') + '"'
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $java
  $psi.Arguments = $argList
  $psi.WorkingDirectory = $GameDir
  $psi.UseShellExecute = $false
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.CreateNoWindow = $true

  $proc = [Diagnostics.Process]::Start($psi)
  if (-not $proc) { throw 'Failed to start packwiz-installer-bootstrap' }

  $outBuilder = New-Object System.Text.StringBuilder
  $errBuilder = New-Object System.Text.StringBuilder
  $lineCount = 0
  $timeoutMs = 900000
  $sw = [Diagnostics.Stopwatch]::StartNew()

  # Async line readers (avoid deadlock)
  $outHandler = {
    if (-not [string]::IsNullOrEmpty($EventArgs.Data)) {
      [void]$Event.MessageData.Out.AppendLine($EventArgs.Data)
      $script:NcPwLine = $EventArgs.Data
    }
  }
  # Use BeginOutputReadLine with sync polling of builders via Register-ObjectEvent is heavy;
  # simpler: ReadToEndAsync + heartbeat status while waiting.
  $outTask = $proc.StandardOutput.ReadToEndAsync()
  $errTask = $proc.StandardError.ReadToEndAsync()
  $lastBeat = 0
  while (-not $proc.HasExited) {
    if ($sw.ElapsedMilliseconds -gt $timeoutMs) {
      try { $proc.Kill() } catch {}
      throw "packwiz sync timed out after $($timeoutMs/1000)s. URL=$PackUrl"
    }
    $sec = [int]$sw.Elapsed.TotalSeconds
    if ($sec -ge $lastBeat + 3) {
      $lastBeat = $sec
      Set-Status ("Downloading / updating pack... ${sec}s (headless packwiz)")
      $pct = [Math]::Min(68, 30 + [int]($sec / 8))
      Set-Progress $pct
    }
    Start-Sleep -Milliseconds 400
  }
  try { $out = $outTask.Result } catch { $out = '' }
  try { $err = $errTask.Result } catch { $err = '' }
  if ($out) {
    foreach ($ln in ($out -split "`r?`n")) {
      if (-not $ln.Trim()) { continue }
      Write-LogUi $ln
      $lineCount++
      $short = $ln.Trim()
      if ($short.Length -gt 88) { $short = $short.Substring(0,85) + '...' }
      if ($short -match '(?i)download|installing|updating|fetched|mods/') {
        Set-Status $short
      }
    }
  }
  if ($err) {
    foreach ($ln in ($err -split "`r?`n")) {
      if ($ln.Trim()) { Write-LogUi ('! ' + $ln.Trim()) }
    }
  }

  if ($proc.ExitCode -ne 0) {
    throw ("packwiz sync failed (exit $($proc.ExitCode)). URL=$PackUrl jar=$BootstrapJar cwd=$GameDir")
  }

  Set-Progress 70
  $modsDir = Join-Path $GameDir 'mods'
  if (Test-Path $modsDir) {
    $n = @(Get-ChildItem $modsDir -File -Filter '*.jar' -EA SilentlyContinue).Count
    Set-Status "Checking Fabric mod dependencies ($n jars)..."
    Write-LogUi "packwiz complete: $n mod jars ($($sw.Elapsed.TotalSeconds.ToString('0.0'))s)"
    $audit = Test-FabricDependencies -ModsDir $modsDir -AutoFix -Log { param($m) Write-LogUi $m }
    if ($audit.Fixed.Count -gt 0) {
      Write-LogUi ("Auto-installed missing deps: " + ($audit.Fixed -join ', '))
    }
    if ($audit.Missing.Count -gt 0) {
      foreach ($miss in $audit.Missing) {
        Write-LogUi ("MISSING required dep: '{0}' needed by {1} ({2})" -f $miss.Needs, $miss.Mod, $miss.From)
      }
      $msg = "Missing required mod dependencies:`n" + (($audit.Missing | ForEach-Object { " - $($_.Needs) (from $($_.Mod))" }) -join "`n")
      if (-not $SilentSync) {
        try {
          (Show-NcMsg @($msg + "`n`nPack sync finished, but Fabric may refuse to launch until these are added to the NORCOM pack.", 'NORCOM dependency check', 'OK', 'Warning')) | Out-Null
        } catch { Write-LogUi $msg }
      } else {
        Write-LogUi $msg
      }
    } else {
      Write-LogUi ("Dependency check OK ($($audit.ProvidedCount) mod ids/provides).")
    }
    New-Item -ItemType Directory -Path (Join-Path $GameDir 'meta') -Force | Out-Null
    ($audit | ConvertTo-Json -Depth 6) | Set-Content (Join-Path $GameDir 'meta\deps-report.json') -Encoding UTF8
  }
  Set-Progress 75
  return $oldCat
}

function Ensure-ServersDat {
  # Only create servers.dat when missing. Never wipe the player's other server entries.
  Set-Status 'Checking multiplayer server list...'
  $path = Join-Path $GameDir 'servers.dat'
  if (Test-Path $path) {
    try {
      $bytes = [IO.File]::ReadAllBytes($path)
      $asText = [Text.Encoding]::UTF8.GetString($bytes)
      if ($asText -like '*shrimp-cub.tun.ply.gg*') {
        Write-LogUi 'servers.dat already has NORCOM - leaving user server list alone'
        return
      }
      Write-LogUi 'servers.dat exists without NORCOM IP - leaving alone (add shrimp-cub.tun.ply.gg manually if needed)'
      return
    } catch {
      Write-LogUi ("servers.dat check failed, leaving file alone: " + $_.Exception.Message)
      return
    }
  }

  function Write-UShort([IO.BinaryWriter]$bw,[uint16]$v){ $b=[BitConverter]::GetBytes($v); if([BitConverter]::IsLittleEndian){[Array]::Reverse($b)}; $bw.Write($b) }
  function Write-Int([IO.BinaryWriter]$bw,[int]$v){ $b=[BitConverter]::GetBytes($v); if([BitConverter]::IsLittleEndian){[Array]::Reverse($b)}; $bw.Write($b) }
  function Write-Str([IO.BinaryWriter]$bw,[string]$s){
    $bytes = [Text.Encoding]::UTF8.GetBytes($s)
    Write-UShort $bw ([uint16]$bytes.Length)
    $bw.Write($bytes)
  }
  # Modern Java Minecraft expects uncompressed NBT for servers.dat (not gzip).
  $ms = New-Object IO.MemoryStream
  $bw = New-Object IO.BinaryWriter $ms
  $bw.Write([byte]10); Write-Str $bw ''
  $bw.Write([byte]9); Write-Str $bw 'servers'
  $bw.Write([byte]10)
  Write-Int $bw 1
  $bw.Write([byte]8); Write-Str $bw 'name'; Write-Str $bw 'NORCOM'
  $bw.Write([byte]8); Write-Str $bw 'ip'; Write-Str $bw 'shrimp-cub.tun.ply.gg'
  $bw.Write([byte]1); Write-Str $bw 'hidden'; $bw.Write([byte]0)
  $bw.Write([byte]0)
  $bw.Write([byte]0)
  $bw.Flush()
  $raw = $ms.ToArray(); $bw.Dispose(); $ms.Dispose()
  $dir = Split-Path $path -Parent
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  [IO.File]::WriteAllBytes($path, $raw)
  Write-LogUi 'servers.dat created (first run) -> NORCOM @ shrimp-cub.tun.ply.gg'
}

function Ensure-OptionsAndShader {
  # Seed client defaults ONCE. Never overwrite the player's options/shaders on later Play clicks.
  Set-Status 'Checking client options (preserve user settings)...'
  $optPath = Join-Path $GameDir 'options.txt'
  $wanted = '["vanilla","continuity:default","continuity:glass_pane_culling_fix","file/Faithful 64x - Release 15.zip","file/Fast Better Grass.zip","file/visual_armor_trims_4.3.zip","file/FreshAnimations_v1.11.2_26.1+.zip","file/FA+All_Extensions-v1.10.1.zip"]'
  $utf8NoBom = New-Object System.Text.UTF8Encoding $false

  if (-not (Test-Path $optPath)) {
    $seed = @(
      'version:5023',
      ("resourcePacks:" + $wanted)
    )
    [System.IO.File]::WriteAllLines($optPath, [string[]]$seed, $utf8NoBom)
    Write-LogUi 'Created options.txt with Faithful 64x pack order (first run only)'
  } else {
    Write-LogUi 'options.txt present - leaving all settings (FOV/keybinds/packs/etc) untouched'
  }

  $iris = Join-Path $GameDir 'config\iris.properties'
  New-Item -ItemType Directory -Path (Split-Path $iris) -Force | Out-Null
  if (-not (Test-Path $iris)) {
    $irisBody = @(
      'enableShaders=true',
      'shaderPack=ComplementaryUnbound_r5.9.3.zip'
    )
    [System.IO.File]::WriteAllLines($iris, [string[]]$irisBody, $utf8NoBom)
    Write-LogUi 'Created config/iris.properties defaults (first run only)'
  } else {
    Write-LogUi 'iris.properties present - leaving shader settings untouched'
  }

  $shaderTxt = Join-Path $GameDir 'shaderpacks\ComplementaryUnbound_r5.9.3.txt'
  New-Item -ItemType Directory -Path (Split-Path $shaderTxt) -Force | Out-Null
  if (-not (Test-Path $shaderTxt)) { 'RP_MODE=3' | Set-Content $shaderTxt -Encoding ASCII }
  elseif ((Get-Content $shaderTxt -Raw) -notmatch 'RP_MODE') { Add-Content $shaderTxt 'RP_MODE=3' }
}

function Get-Catalog {
  $p = Join-Path $GameDir 'meta\mods-catalog.json'
  if (Test-Path $p) { return @(Get-Content $p -Raw | ConvertFrom-Json) }
  return @()
}

function Compute-Changes($oldCat, $newCat) {
  $oldMap = @{}
  foreach ($m in @($oldCat)) { if ($m.filename) { $oldMap[$m.filename] = $m } }
  $newMap = @{}
  foreach ($m in @($newCat)) { if ($m.filename) { $newMap[$m.filename] = $m } }
  $changes = @()
  foreach ($k in $newMap.Keys) {
    if (-not $oldMap.ContainsKey($k)) {
      $changes += [pscustomobject]@{ status='New'; name=$newMap[$k].name; filename=$k; old=''; new=$newMap[$k].version_id; item=$newMap[$k] }
    } elseif ($oldMap[$k].version_id -ne $newMap[$k].version_id) {
      $changes += [pscustomobject]@{ status='Updated'; name=$newMap[$k].name; filename=$k; old=$oldMap[$k].version_id; new=$newMap[$k].version_id; item=$newMap[$k] }
    } else {
      $changes += [pscustomobject]@{ status='Up to date'; name=$newMap[$k].name; filename=$k; old=$newMap[$k].version_id; new=$newMap[$k].version_id; item=$newMap[$k] }
    }
  }
  foreach ($k in $oldMap.Keys) {
    if (-not $newMap.ContainsKey($k)) {
      $changes += [pscustomobject]@{ status='Removed'; name=$oldMap[$k].name; filename=$k; old=$oldMap[$k].version_id; new=''; item=$oldMap[$k] }
    }
  }
  return $changes | Sort-Object { switch ($_.status) { 'New' {0} 'Updated' {1} 'Removed' {2} default {3} } }, name
}

function Get-CachedIcon([string]$id, [string]$iconUrl) {
  if (-not $id) { return $null }
  $dest = Join-Path $IconCache ($id + '.png')
  if (-not (Test-Path $dest) -and $iconUrl) {
    try { Invoke-WebRequest -Uri $iconUrl -OutFile $dest -UseBasicParsing -TimeoutSec 8 } catch {}
  }
  if (Test-Path $dest) {
    try { return [System.Drawing.Image]::FromFile($dest) } catch { return $null }
  }
  return $null
}

function Get-VersionChangelog([string]$versionId) {
  if (-not $versionId) { return 'No version changelog available.' }
  $cache = Join-Path $VerCache ($versionId + '.json')
  $obj = $null
  if (Test-Path $cache) {
    try { $obj = Get-Content $cache -Raw | ConvertFrom-Json } catch {}
  }
  if (-not $obj) {
    try {
      $obj = Invoke-RestMethod -Uri "https://api.modrinth.com/v2/version/$versionId" -Headers @{ 'User-Agent'='NORCOM-Launcher/1.0.28' } -TimeoutSec 10
      ($obj | ConvertTo-Json -Depth 6) | Set-Content $cache -Encoding UTF8
    } catch {
      return 'Changelog unavailable (offline or Modrinth busy).'
    }
  }
  $cl = [string]$obj.changelog
  if (-not $cl) { $cl = 'No changelog text for this version.' }
  # keep short
  $cl = ($cl -replace '#+ ','' -replace '\r','')
  if ($cl.Length -gt 1200) { $cl = $cl.Substring(0,1197) + '...' }
  return $cl
}

function Get-NorcomInstallDir {
  return (Join-Path $NorcomHome 'Launcher')
}

function Ensure-NorcomInstalledCopy {
  $installDir = Get-NorcomInstallDir
  New-Item -ItemType Directory -Path $installDir,(Join-Path $installDir 'assets'),(Join-Path $installDir 'tools') -Force | Out-Null
  $srcFull = [IO.Path]::GetFullPath($ScriptDir).TrimEnd('\')
  $dstFull = [IO.Path]::GetFullPath($installDir).TrimEnd('\')
  if ($srcFull -ieq $dstFull) { return $installDir }

  $rootFiles = @(
    'NORCOM-Launcher.ps1','NORCOM-Installer.bat','Play-NORCOM.bat','NORCOM-Launcher.vbs',
    'pack-url.txt','FRIENDS-README.txt','installer-version.txt','news.md','rules.md','discord-link.txt'
  )
  foreach ($f in $rootFiles) {
    $p = Join-Path $ScriptDir $f
    if (Test-Path $p) { Copy-Item $p (Join-Path $installDir $f) -Force }
  }
  foreach ($a in @('norcom.ico','norcom-icon.jpg','norcom-banner.png','bg.png','city-bg.jpg')) {
    $p = Join-Path $ScriptDir ('assets\' + $a)
    if (Test-Path $p) { Copy-Item $p (Join-Path $installDir ('assets\' + $a)) -Force }
  }
  $toolsSrc = Join-Path $ScriptDir 'tools'
  if (Test-Path $toolsSrc) {
    Get-ChildItem $toolsSrc -File | ForEach-Object {
      Copy-Item $_.FullName (Join-Path $installDir ('tools\' + $_.Name)) -Force
    }
  }

  # Always refresh the no-console VBS in the install dir
  $vbs = Join-Path $installDir 'NORCOM-Launcher.vbs'
  $vbsBody = @(
    "' NORCOM Launcher - launches the GUI with no console window",
    'Option Explicit',
    'Dim sh, fso, dir, ps1, cmd',
    'Set sh = CreateObject("Wscript.Shell")',
    'Set fso = CreateObject("Scripting.FileSystemObject")',
    'dir = fso.GetParentFolderName(WScript.ScriptFullName)',
    'ps1 = dir & "\NORCOM-Launcher.ps1"',
    'cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1 & """"',
    'sh.Run cmd, 0, False'
  ) -join "`r`n"
  Set-Content -Path $vbs -Value $vbsBody -Encoding ASCII
  return $installDir
}

function Write-NorcomShortcut([string]$lnkPath, [string]$vbsPath, [string]$workDir, [string]$icoPath) {
  $w = New-Object -ComObject WScript.Shell
  $sc = $w.CreateShortcut($lnkPath)
  $sc.TargetPath = $vbsPath
  $sc.WorkingDirectory = $workDir
  $sc.WindowStyle = 7
  $sc.Description = 'NORCOM Launcher'
  if ($icoPath -and (Test-Path $icoPath)) { $sc.IconLocation = "$icoPath,0" }
  $sc.Save()
  Set-NorcomShortcutAumid $lnkPath
}
function Set-NorcomShortcutAumid([string]$lnkPath, [string]$Id = 'NORCOM.Launcher') {
  try {
    if (-not ('NorcomUi.ShortcutAumid' -as [type])) { return }
    if ([NorcomUi.ShortcutAumid]::Get($lnkPath) -ne $Id) { [NorcomUi.ShortcutAumid]::Set($lnkPath, $Id) }
  } catch { try { Write-LogUi ('Shortcut AUMID: ' + $_.Exception.Message) } catch {} }
}

function Ensure-NorcomShortcuts {
  if ($TestMode -eq '1') { Write-LogUi 'TestMode: skip shortcuts'; return }
  try {
    $installDir = Ensure-NorcomInstalledCopy
    $vbs = Join-Path $installDir 'NORCOM-Launcher.vbs'
    # 1.0.30v: prefer lock-safe neon app icon (update.zip ships norcom-app.ico; norcom.ico may stay locked)
    $ico = Join-Path $installDir 'assets\norcom-app.ico'
    if (-not (Test-Path $ico)) { $ico = Join-Path $installDir 'assets\norcom.ico' }
    if (-not (Test-Path $vbs)) {
      # Fallback if copy skipped because we already are in install dir
      $vbsBody = @(
        "' NORCOM Launcher - launches the GUI with no console window",
        'Option Explicit',
        'Dim sh, fso, dir, ps1, cmd',
        'Set sh = CreateObject("Wscript.Shell")',
        'Set fso = CreateObject("Scripting.FileSystemObject")',
        'dir = fso.GetParentFolderName(WScript.ScriptFullName)',
        'ps1 = dir & "\NORCOM-Launcher.ps1"',
        'cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1 & """"',
        'sh.Run cmd, 0, False'
      ) -join "`r`n"
      Set-Content -Path $vbs -Value $vbsBody -Encoding ASCII
    }

    $desk = [Environment]::GetFolderPath('Desktop')
    $deskLnk = Join-Path $desk 'NORCOM Launcher.lnk'
    # Remove legacy shortcut name so friends only see one icon
    $legacy = Join-Path $desk 'Play NORCOM.lnk'
    if (Test-Path $legacy) { Remove-Item $legacy -Force -ErrorAction SilentlyContinue }

    $needDesk = $true
    if (Test-Path $deskLnk) {
      try {
        $w = New-Object -ComObject WScript.Shell
        $ex = $w.CreateShortcut($deskLnk)
        if (($ex.TargetPath -ieq $vbs) -and (Test-Path $vbs)) { $needDesk = $false }
      } catch { $needDesk = $true }
    }
    if ($needDesk -or -not (Test-Path $deskLnk)) {
      Write-NorcomShortcut $deskLnk $vbs $installDir $ico
      Write-LogUi "Desktop shortcut: $deskLnk"
    } else {
      # Refresh icon/workdir in place without duplicating
      Write-NorcomShortcut $deskLnk $vbs $installDir $ico
    }

    $programs = [Environment]::GetFolderPath('Programs')
    $smDir = Join-Path $programs 'NORCOM'
    New-Item -ItemType Directory -Path $smDir -Force | Out-Null
    $smLnk = Join-Path $smDir 'NORCOM Launcher.lnk'
    $needSm = $true
    if (Test-Path $smLnk) {
      try {
        $w2 = New-Object -ComObject WScript.Shell
        $ex2 = $w2.CreateShortcut($smLnk)
        if (($ex2.TargetPath -ieq $vbs) -and (Test-Path $vbs)) { $needSm = $false }
      } catch { $needSm = $true }
    }
    if ($needSm -or -not (Test-Path $smLnk)) {
      Write-NorcomShortcut $smLnk $vbs $installDir $ico
      Write-LogUi "Start Menu shortcut: $smLnk"
    } else {
      Write-NorcomShortcut $smLnk $vbs $installDir $ico
    }
    # Gentle icon-cache refresh so Desktop/Taskbar pick up neon N without killing Explorer
    try {
      $ie = Join-Path $env:WINDIR 'System32\ie4uinit.exe'
      if (Test-Path $ie) { Start-Process -FilePath $ie -ArgumentList '-show' -WindowStyle Hidden -Wait -EA SilentlyContinue }
    } catch {}
  } catch {
    Write-LogUi ("Shortcut setup failed: " + $_.Exception.Message)
  }
}

# Back-compat alias
function Create-DesktopShortcut { Ensure-NorcomShortcuts }

function Invoke-InstallOrSync {
  try {
    $script:BtnPrimary.Enabled = $false
    Set-Progress 5
    $java = Ensure-Java
    Set-Progress 10
    Ensure-Fabric $java
    Set-Progress 20
    Ensure-LauncherProfile
    try { Invoke-ReiIpnOneTimeMigration } catch { Write-LogUi ('migration: ' + $_.Exception.Message) }
    try { Invoke-Rp64OneTimeMigration } catch { Write-LogUi ('rp64 migration: ' + $_.Exception.Message) }
    $oldCat = Sync-Packwiz $java
    Ensure-OptionsAndShader
    Ensure-ServersDat
    Set-Progress 90
    $newCat = Get-Catalog
    $script:Changes = @(Compute-Changes $oldCat $newCat)
    $notes = ''
    $np = Join-Path $GameDir 'pack-notes.txt'
    if (Test-Path $np) { $notes = Get-Content $np -Raw }
    $st = Load-State
    Set-StateProp $st 'installed' $true
    Set-StateProp $st 'lastNotes' $notes
    $nowIso = (Get-Date).ToString('o')
    Set-StateProp $st 'lastSync' $nowIso
    if (-not $st.installedAt) { Set-StateProp $st 'installedAt' $nowIso }
    Save-State $st
    Create-DesktopShortcut
    Set-Progress 100
    Set-Status 'NORCOM is ready.'
    Populate-Mods
    Populate-WhatsNew
    $script:BtnPrimary.Text = 'Play NORCOM'
    $script:BtnPrimary.Enabled = $true
    Set-Progress 0
    Show-Success
  } catch {
    Set-Progress 0
    Set-Status ("Error: " + $_.Exception.Message)
    Write-LogUi $_.Exception.ToString()
    $script:BtnPrimary.Enabled = $true
    (Show-NcMsg @($_.Exception.Message, 'NORCOM', 'OK', 'Error')) | Out-Null
  }
}

function Invoke-Play {
  $playSw = [Diagnostics.Stopwatch]::StartNew()
  Write-LogUi 'Play: begin'
  Write-StartupPlay 'begin'
  try {
    if ($script:BtnPrimary) { $script:BtnPrimary.Enabled = $false }
    Set-ProgressBusy 'Preparing NORCOM...'
    Write-StartupPlay 'progress=busy preparing'

    $java = $null
    try {
      Write-StartupPlay 'Ensure-Java start'
      $java = Ensure-Java
      Write-StartupPlay ("Ensure-Java ok path=" + $java)
    } catch {
      Write-LogUi ("Java: " + $_.Exception.Message)
      Write-StartupPlay ("Ensure-Java FAIL: " + $_.Exception.Message)
      throw ("Could not get Java 25+: " + $_.Exception.Message)
    }
    if (-not $java) { throw 'No Java available for pack sync / launch prep.' }

    $syncOk = $false
    Set-Progress 20
    try {
      Write-StartupPlay 'migrations start'
      try { Invoke-ReiIpnOneTimeMigration } catch { Write-LogUi ('migration: ' + $_.Exception.Message) }
      try { Invoke-Rp64OneTimeMigration } catch { Write-LogUi ('rp64 migration: ' + $_.Exception.Message) }
      Write-StartupPlay 'packwiz sync start'
      $oldCat = Get-Catalog
      Sync-Packwiz $java | Out-Null
      Write-StartupPlay 'packwiz sync ok'
      Ensure-OptionsAndShader
      $newCat = Get-Catalog
      $script:Changes = @(Compute-Changes $oldCat $newCat)
      try { Populate-Mods } catch { Write-LogUi ('Populate-Mods: ' + $_.Exception.Message) }
      try { Populate-WhatsNew } catch { Write-LogUi ('Populate-WhatsNew: ' + $_.Exception.Message) }
      try {
        $stPlay = Load-State
        Set-StateProp $stPlay 'installed' $true
        Set-StateProp $stPlay 'lastSync' ((Get-Date).ToString('o'))
        Save-State $stPlay
      } catch { Write-LogUi ("state lastSync: " + $_.Exception.Message) }
      $syncOk = $true
    } catch {
      Write-LogUi ("Play sync skipped: " + $_.Exception.Message)
      Write-StartupPlay ("packwiz FAIL/skip: " + $_.Exception.Message)
      Set-Status ('Sync skipped: ' + $_.Exception.Message)
    }

    Set-Progress 60
    try { Ensure-ServersDat } catch { Write-LogUi ("servers.dat: " + $_.Exception.Message) }
    Set-Progress 80

    if ($TestMode -eq '1') {
      Write-LogUi 'TestMode: not launching Minecraft'
      Set-Status 'TestMode: launch skipped'
    } else {
      Set-Status 'Opening Minecraft Java Launcher (NORCOM profile)...'
      Write-StartupPlay 'Start-NorcomJavaLauncher start'
      $started = Start-NorcomJavaLauncher
      Write-StartupPlay ("Start-NorcomJavaLauncher ok kind=$($started.Kind) path=$($started.Path) protocol=$($started.Protocol)")
      # Brief wait: confirm a Java Minecraft launcher process appeared (Store or legacy). Timeout -> clear error.
      $seen = $false
      $waitSw = [Diagnostics.Stopwatch]::StartNew()
      while ($waitSw.ElapsedMilliseconds -lt 12000) {
        try {
          $procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
            $_.ProcessName -match '^(Minecraft|MinecraftLauncher|MinecraftLauncherAPI)$' -or
            ($_.MainWindowTitle -match 'Minecraft Launcher') -or
            ($_.ProcessName -eq 'gamelaunchhelper')
          })
          if ($procs.Count -gt 0) { $seen = $true; break }
        } catch {}
        Start-Sleep -Milliseconds 400
        [System.Windows.Forms.Application]::DoEvents()
      }
      Write-StartupPlay ("launcher process seen=$seen afterMs=$($waitSw.ElapsedMilliseconds)")
      if (-not $seen) {
        Write-LogUi 'Play: Minecraft Launcher process not detected within 12s (start may still succeed asynchronously)'
      }
      Set-Status 'Minecraft Launcher opened — NORCOM is in Multiplayer (shrimp-cub.tun.ply.gg).'
      Write-LogUi ("Launched: kind=$($started.Kind) path=$($started.Path)")
    }
    Set-Progress 100
    Start-Sleep -Milliseconds 250
    Set-Progress 0
    if ($syncOk) { Set-Status 'Ready — Minecraft Launcher opened with NORCOM selected.' }
    else { Set-Status 'Minecraft Launcher opened (pack sync had warnings — see log).' }
    Write-StartupPlay ("done ok ms=$($playSw.ElapsedMilliseconds)")
  } catch {
    Set-Progress 0
    $err = $_.Exception.Message
    Set-Status ("Error: " + $err)
    Write-LogUi $_.Exception.ToString()
    Write-StartupPlay ("FAIL: " + $err)
    try {
      if (Get-Command Send-NorcomCrashReport -ErrorAction SilentlyContinue) {
        Send-NorcomCrashReport -ErrorMessage $err -Context 'Invoke-Play'
      } elseif (Get-Command Submit-NorcomCrashReport -ErrorAction SilentlyContinue) {
        Submit-NorcomCrashReport $err
      }
    } catch { Write-LogUi ('crash-report: ' + $_.Exception.Message) }
    try { (Show-NcMsg @($err, 'NORCOM Play', 'OK', 'Error')) | Out-Null } catch {}
  } finally {
    try { if ($script:BtnPrimary) { $script:BtnPrimary.Enabled = $true } } catch {}
    try { Set-Progress 0 } catch {}
    Write-StartupPlay ("finally ms=$($playSw.ElapsedMilliseconds)")
  }
}

function Show-Success {
  # Single-page UI: toast via status only
  try { Set-Status 'Synced - ready to play' } catch {}
}

function Populate-Mods {
  if (-not $script:ModsList) { return }
  $script:ModsList.Items.Clear()
  $script:ImageList.Images.Clear()
  $cat = Get-Catalog
  $old = @()
  # use changes if present else all up to date
  $map = @{}
  foreach ($c in @($script:Changes)) { $map[$c.filename] = $c }
  $i = 0
  foreach ($m in ($cat | Sort-Object name)) {
    $st = 'Up to date'
    if ($map.ContainsKey($m.filename)) { $st = $map[$m.filename].status }
    $img = Get-CachedIcon $m.id $m.icon_url
    $key = "i$i"
    if ($img) { $script:ImageList.Images.Add($key, $img) } else {
      $bmp = New-Object System.Drawing.Bitmap 32,32
      $g = [System.Drawing.Graphics]::FromImage($bmp)
      $g.Clear($Ccard); $g.Dispose()
      $script:ImageList.Images.Add($key, $bmp)
    }
    $item = New-Object System.Windows.Forms.ListViewItem([string[]]@($m.name, $st, $m.filename), $key)
    $item.Tag = $m
    switch ($st) {
      'New' { $item.ForeColor = $Ccyan }
      'Updated' { $item.ForeColor = $Corange }
      'Removed' { $item.ForeColor = $Cpink }
      default { $item.ForeColor = $Caccent }
    }
    [void]$script:ModsList.Items.Add($item)
    $i++
  }
  $script:ModsCountLabel.Text = "$($cat.Count) mods in pack"
}

function Populate-WhatsNew {
  if (-not $script:WhatsNewBox) { return }
  $sb = New-Object System.Text.StringBuilder
  $np = Join-Path $GameDir 'pack-notes.txt'
  [void]$sb.AppendLine('WHAT''S NEW IN NORCOM')
  [void]$sb.AppendLine('====================')
  if (Test-Path $np) { [void]$sb.AppendLine((Get-Content $np -Raw).Trim()); [void]$sb.AppendLine('') }
  $ch = @($script:Changes | Where-Object { $_.status -ne 'Up to date' })
  if ($ch.Count -eq 0) {
    [void]$sb.AppendLine('Everything is up to date. No mod changes since your last sync.')
  } else {
    [void]$sb.AppendLine(("Changes ({0}):" -f $ch.Count))
    foreach ($c in $ch) {
      if ($c.status -eq 'Updated') {
        [void]$sb.AppendLine(("  * {0}: Updated ({1} -> {2})" -f $c.name, $c.old, $c.new))
      } else {
        [void]$sb.AppendLine(("  * {0}: {1}" -f $c.name, $c.status))
      }
    }
  }
  [void]$sb.AppendLine('')
  [void]$sb.AppendLine('Server: shrimp-cub.tun.ply.gg')
  [void]$sb.AppendLine('Optional: Physics Mod Pro (Patreon) - install yourself into mods/.')
  $script:WhatsNewBox.Text = $sb.ToString()
}

function Show-ModDetails($m) {
  if (-not $m) { return }
  $script:DetailTitle.Text = $m.name
  $script:DetailSummary.Text = $(if ($m.summary) { $m.summary } else { '' })
  $script:DetailMeta.Text = "File: $($m.filename)`r`nSide: $($m.side)`r`nVersion id: $($m.version_id)"
  if ($m.page) { $script:DetailLink.Text = $m.page; $script:DetailLink.Tag = $m.page } else { $script:DetailLink.Text = ''; $script:DetailLink.Tag = $null }
  $script:DetailChange.Text = 'Loading changelog...'
  [System.Windows.Forms.Application]::DoEvents()
  $script:DetailChange.Text = Get-VersionChangelog $m.version_id
}

# ---------- Silent sync path (Play shortcut) ----------
if ($SilentSync -and -not $ShowUi) {
  try {
    $java = Ensure-Java
    if (-not (Test-Path (Join-Path $GameDir 'mods'))) { Ensure-Fabric $java; Ensure-LauncherProfile }
    try { Update-ProfileRam ([int]((Get-NorcomSettings).ramMb)) } catch { Write-LogUi ("RAM apply: " + $_.Exception.Message) }
    $silentSyncOk = $false
    try { Invoke-ReiIpnOneTimeMigration } catch { Write-LogUi ('migration: ' + $_.Exception.Message) }
    try { Invoke-Rp64OneTimeMigration } catch { Write-LogUi ('rp64 migration: ' + $_.Exception.Message) }
    try { Sync-Packwiz $java | Out-Null; $silentSyncOk = $true } catch { Write-LogUi ("Silent sync skipped: " + $_.Exception.Message) }
    try { Ensure-OptionsAndShader } catch { Write-LogUi ("options: " + $_.Exception.Message) }
    try { Ensure-ServersDat } catch { Write-LogUi ("servers.dat: " + $_.Exception.Message) }
    if ($silentSyncOk) {
      try {
        $stSilent = Load-State
        Set-StateProp $stSilent 'installed' $true
        $nowIso = (Get-Date).ToString('o')
        Set-StateProp $stSilent 'lastSync' $nowIso
        if (-not $stSilent.installedAt) { Set-StateProp $stSilent 'installedAt' $nowIso }
        Save-State $stSilent
      } catch { Write-LogUi ("state lastSync: " + $_.Exception.Message) }
    }
    if ($TestMode -eq '1') {
      Write-LogUi 'TestMode: SilentSync skipped Minecraft launch'
    } else {
      Start-NorcomJavaLauncher | Out-Null
    }
  } catch {
    (Show-NcMsg @($_.Exception.Message, 'NORCOM sync failed', 'OK', 'Error')) | Out-Null
  }
  return
}

# ---------- UI ----------
# Single full-page launcher: hero Play + card grid over Minecraft-style bg. No tabs.
# Design target: compact ~1100x720; scale up cleanly when maximized.

$script:UiScale = 1.0
function Get-UiScale {
  $w = 1100
  try { if ($script:MainForm -and $script:MainForm.ClientSize.Width -gt 0) { $w = $script:MainForm.ClientSize.Width } } catch {}
  $s = $w / 1100.0
  if ($s -lt 1.0) { $s = 1.0 }
  if ($s -gt 1.8) { $s = 1.8 }
  return [double]$s
}
function S([double]$v) { return [int][Math]::Round($v * $script:UiScale) }
function Sf([double]$v) { return [float]($v * $script:UiScale) }

function New-SimplePill([string]$text, [System.Drawing.Size]$size, [System.Drawing.Point]$loc, [System.Drawing.Color]$back, [System.Drawing.Color]$fore, [System.Drawing.Color]$hover, [float]$fontSize = 11, [System.Drawing.Color]$cornerFill = ([System.Drawing.Color]::Empty)) {
  if ($script:HasNorcomUi) {
    $btn = New-Object NorcomUi.RoundedButton
    $btn.Text = $text
    $btn.Size = $size
    $btn.Location = $loc
    $btn.BackColor = $back
    $btn.ForeColor = $fore
    $btn.HoverBack = $hover
    $btn.PressBack = $Cgold
    $btn.CornerRadius = [Math]::Max(12, [int]($size.Height * 0.28))
    $btn.Font = Get-UiFont $fontSize ([System.Drawing.FontStyle]::Bold)
    $btn.UseMnemonic = $false
    return $btn
  }
  $cf = if ($cornerFill.IsEmpty) { $Cpanel } else { $cornerFill }
  $btn = New-PillButton -Text $text -Size $size -Location $loc -Back $back -Fore $fore -Hover $hover -FontSize $fontSize -Radius 18 -CornerFill $cf
  $btn.UseMnemonic = $false
  return $btn
}

function New-OliveCard([string]$title) {
  # Glass neon card (Cyber Sleek)
  if ($script:HasNorcomUi) {
    $c = New-Object NorcomUi.CardPanel
    $c.Fill = [System.Drawing.Color]::FromArgb(18, 26, 52)
    $c.FillAlpha = 220
    $c.CornerRadius = 16
    $c.Border = [System.Drawing.Color]::FromArgb(160, $Ccyan)
    try { $c.Fill = [System.Drawing.Color]::FromArgb(170, 12, 18, 40) } catch {}
  } else {
    $c = New-Object System.Windows.Forms.Panel
    $c.BackColor = [System.Drawing.Color]::FromArgb(220, 12, 18, 40)
  }
  $c.Margin = New-Object System.Windows.Forms.Padding 8
  $c.Padding = New-Object System.Windows.Forms.Padding 14
  $c.Size = New-Object System.Drawing.Size 320, 200
  $t = New-Object System.Windows.Forms.Label
  $t.Name = 'CardTitle'
  $t.Text = $title
  $t.Dock = 'Top'
  $t.Height = 40
  $t.Font = Get-UiFont 17 ([System.Drawing.FontStyle]::Bold)
  $t.ForeColor = $Cgold
  $t.BackColor = [System.Drawing.Color]::Transparent
  $t.UseMnemonic = $false
  $c.Controls.Add($t)
  $c.Tag = $title
  return $c
}

function Set-MarkdownRichText([System.Windows.Forms.RichTextBox]$box, [string]$md) {
  if (-not $box) { return }
  # 1.0.30e: trailing blank lines so last glyph sits above CardFadePad (no mid-line cut)
  if ($md) { $md = $md.TrimEnd() + ([Environment]::NewLine * 8) }
  $box.SuspendLayout()
  $box.Clear()
  $box.DetectUrls = $false
  $bodySize = Sf 13.5
  $headSize = Sf 16.5
  $bodyFont = Get-UiFont $bodySize
  $headFont = Get-UiFont $headSize ([System.Drawing.FontStyle]::Bold)
  $boldFont = Get-UiFont $bodySize ([System.Drawing.FontStyle]::Bold)
  $lines = $md -split "`r?`n"
  foreach ($raw in $lines) {
    $line = [string]$raw
    if ($line -match '^\s*$') {
      $box.SelectionFont = $bodyFont
      $box.SelectionColor = $Cdim
      $box.AppendText("`n")
      continue
    }
    $isHead = $false
    if ($line -match '^#{1,3}\s+(.*)$') {
      $line = $Matches[1]
      $isHead = $true
    }
    $bullet = $false
    if ($line -match '^\s*[-*]\s+(.*)$') {
      $line = [char]0x2022 + '  ' + $Matches[1]
      $bullet = $true
    } elseif ($line -match '^\s*\d+\.\s+(.*)$') {
      $line = $Matches[0].Trim()
      if ($line -match '^(\d+)\.\s+(.*)$') { $line = $Matches[1] + '.  ' + $Matches[2] }
    }
    # emit with **bold** segments
    $box.SelectionColor = if ($isHead) { $Cgold } else { $Ctext }
    $box.SelectionFont = if ($isHead) { $headFont } else { $bodyFont }
    $pos = 0
    while ($pos -lt $line.Length) {
      $open = $line.IndexOf('**', $pos)
      if ($open -lt 0) {
        $box.SelectionFont = if ($isHead) { $headFont } else { $bodyFont }
        $box.AppendText($line.Substring($pos))
        break
      }
      if ($open -gt $pos) {
        $box.SelectionFont = if ($isHead) { $headFont } else { $bodyFont }
        $box.AppendText($line.Substring($pos, $open - $pos))
      }
      $close = $line.IndexOf('**', $open + 2)
      if ($close -lt 0) {
        $box.SelectionFont = if ($isHead) { $headFont } else { $bodyFont }
        $box.AppendText($line.Substring($open))
        break
      }
      $box.SelectionFont = $boldFont
      $box.SelectionColor = if ($isHead) { $Cgold } else { $Ctext }
      $box.AppendText($line.Substring($open + 2, $close - $open - 2))
      $box.SelectionFont = if ($isHead) { $headFont } else { $bodyFont }
      $pos = $close + 2
    }
    $box.AppendText("`n")
    # 1.0.30t: only heads get an extra blank - bullets must not push content below tiny viewports
    if ($isHead) { $box.AppendText("`n") }
  }
  try { $box.SelectionStart = 0; $box.ScrollToCaret() } catch {}
  $box.ResumeLayout()
}

function New-DarkMarkdownBox {
  if ($script:HasNorcomUi) {
    try { $box = New-Object NorcomUi.DarkRichTextBox } catch { $box = New-Object System.Windows.Forms.RichTextBox }
  } else {
    $box = New-Object System.Windows.Forms.RichTextBox
  }
  $box.Multiline = $true
  $box.ReadOnly = $true
  $box.BorderStyle = 'None'
  try { $box.ScrollBars = 'Vertical' } catch { try { $box.ScrollBars = 'None' } catch {} }
  $box.DetectUrls = $false
  $box.BackColor = [System.Drawing.Color]::FromArgb(10, 14, 30)
  $box.ForeColor = $Ctext
  $box.Font = Get-UiFont 12
  $box.Dock = 'Fill'
  $box.Margin = New-Object System.Windows.Forms.Padding 4, 4, 4, 56
  $box.Padding = New-Object System.Windows.Forms.Padding 0,0,0,8
  try { $box.TabStop = $false } catch {}
  return $box
}

function Get-NextRestartCountdownText {
  try {
    $tz = [TimeZoneInfo]::FindSystemTimeZoneById('Mountain Standard Time')
  } catch {
    try { $tz = [TimeZoneInfo]::FindSystemTimeZoneById('America/Denver') } catch { $tz = [TimeZoneInfo]::Local }
  }
  $nowUtc = [DateTime]::UtcNow
  $now = [TimeZoneInfo]::ConvertTimeFromUtc($nowUtc, $tz)
  $next = Get-Date -Year $now.Year -Month $now.Month -Day $now.Day -Hour 4 -Minute 0 -Second 0
  if ($now -ge $next) { $next = $next.AddDays(1) }
  $span = $next - $now
  if ($span.TotalHours -ge 24) {
    return ('{0}d {1:00}h {2:00}m' -f [int]$span.Days, $span.Hours, $span.Minutes)
  }
  return ('{0:00}h {1:00}m {2:00}s' -f [int][Math]::Floor($span.TotalHours), $span.Minutes, $span.Seconds)
}

function Get-PackInfoText {
  $ver = '1.0.30'
  try {
    $vf = Join-Path $ScriptDir 'installer-version.txt'
    if (Test-Path $vf) { $ver = (Get-Content $vf -Raw).Trim() }
  } catch {}
  $modCount = 0
  try {
    $mods = Join-Path $GameDir 'mods'
    if (Test-Path $mods) { $modCount = @(Get-ChildItem $mods -Filter '*.jar' -EA SilentlyContinue).Count }
  } catch {}
  $synced = 'never'
  try {
    $st = Load-State
    if ($st.lastSync) { $synced = [string]$st.lastSync }
    elseif ($st.installedAt) { $synced = [string]$st.installedAt }
    elseif ((Test-Path (Join-Path $GameDir 'mods'))) {
      $synced = (Get-Item (Join-Path $GameDir 'mods')).LastWriteTime.ToString('yyyy-MM-dd HH:mm')
    }
  } catch {}
  try { if ($synced -ne 'never') { $dt = [datetime]::Parse($synced, [Globalization.CultureInfo]::InvariantCulture); $synced = $dt.ToString('MMM d, h:mm tt', [Globalization.CultureInfo]::GetCultureInfo('en-US')) } } catch {}
  return ("Pack  $ver`r`nSynced:  $synced`r`nMods:  $modCount")
}

try { if (-not ('NcScroll' -as [type])) { Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class NcScroll { [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, int m, IntPtr w, IntPtr l); public static void Top(IntPtr h){ SendMessage(h, 0x115, (IntPtr)6, IntPtr.Zero); } }' } } catch {}

function Add-NcCardFade([System.Windows.Forms.Control]$card) {
  if (-not $card) { return }
  foreach ($c in @($card.Controls)) {
    if ($c.Name -eq 'CardFade' -or $c.Name -eq 'CardFadePad') { try { $card.Controls.Remove($c); $c.Dispose() } catch {} }
  }
  # Opaque pad so Dock=Fill RTB ends above the fade; last line is never mid-glyph clipped
  $pad = New-Object System.Windows.Forms.Panel
  $pad.Name = 'CardFadePad'
  # 1.0.30h: short cards get a thin pad only (tall fade was covering mid-line text)
  $ch = [Math]::Max(80, [int]$card.ClientSize.Height)
  $pad.Height = if ($ch -lt 200) { 22 } else { 36 }
  $pad.Dock = 'Bottom'
  $pad.BackColor = [System.Drawing.Color]::FromArgb(10, 14, 30)
  $card.Controls.Add($pad)
  $fade = New-Object System.Windows.Forms.Panel
  $fade.Name = 'CardFade'
  $fade.Height = if ($ch -lt 200) { 0 } else { 40 }
  if ($fade.Height -lt 1) { $fade.Visible = $false }
  $fade.Dock = 'Bottom'
  $fade.BackColor = [System.Drawing.Color]::Transparent
  $fade.Add_Paint({
    param($s, $e)
    try {
      $r = $s.ClientRectangle
      if ($r.Width -lt 2 -or $r.Height -lt 2) { return }
      $br = New-Object System.Drawing.Drawing2D.LinearGradientBrush $r, ([System.Drawing.Color]::FromArgb(0, 12, 18, 40)), ([System.Drawing.Color]::FromArgb(255, 12, 18, 40)), 90.0
      $cb = New-Object System.Drawing.Drawing2D.ColorBlend 3
      $cb.Colors = @([System.Drawing.Color]::FromArgb(0, 12, 18, 40), [System.Drawing.Color]::FromArgb(160, 12, 18, 40), [System.Drawing.Color]::FromArgb(255, 12, 18, 40))
      $cb.Positions = @(0.0, 0.4, 1.0)
      $br.InterpolationColors = $cb
      $e.Graphics.FillRectangle($br, $r)
      $br.Dispose()
    } catch {}
  })
  $card.Controls.Add($fade)
  try { $pad.SendToBack() } catch {}
  $fade.BringToFront()
  # Keep markdown box under the fade/pad so Dock=Fill reserves bottom space (no mid-glyph cut)
  foreach ($bx in @($card.Controls)) {
    if ($bx -is [System.Windows.Forms.RichTextBox]) { try { $bx.SendToBack() } catch {} }
  }
  try { $pad.BringToFront() } catch {}
  if ($fade.Height -gt 0) { try { $fade.BringToFront() } catch {} }
  try { $card.PerformLayout() } catch {}
  try { Fit-NcMarkdownBox $card } catch {}
}



function Convert-NcMdToPlain([string]$md) {
  if (-not $md) { return '' }
  $sb = New-Object System.Text.StringBuilder
  foreach ($raw in ($md -split "`r?`n")) {
    $line = [string]$raw
    if ($line -match '^\s*$') { [void]$sb.AppendLine(''); continue }
    if ($line -match '^#{1,3}\s+(.*)$') { $line = $Matches[1] }
    elseif ($line -match '^\s*[-*]\s+(.*)$') { $line = [char]0x2022 + '  ' + $Matches[1] }
    elseif ($line -match '^\s*\d+\.\s+(.*)$') { $line = $Matches[0].Trim() }
    $line = [regex]::Replace($line, '\*\*([^*]+)\*\*', '$1')
    $line = [regex]::Replace($line, '`([^`]+)`', '$1')
    [void]$sb.AppendLine($line)
  }
  return $sb.ToString().TrimEnd()
}

function Get-NcPreviewText([string]$plain, [System.Drawing.Font]$font, [int]$width, [int]$maxLines) {
  if (-not $plain) { return @{ Text = ''; Truncated = $false } }
  if ($width -lt 20) { $width = 20 }
  if ($maxLines -lt 1) { $maxLines = 1 }
  $lineH = [Math]::Max(14, [System.Windows.Forms.TextRenderer]::MeasureText('Ay', $font).Height)
  $maxH = $maxLines * $lineH
  $flags = [System.Windows.Forms.TextFormatFlags]::WordBreak -bor [System.Windows.Forms.TextFormatFlags]::TextBoxControl -bor [System.Windows.Forms.TextFormatFlags]::NoPadding
  $propose = New-Object System.Drawing.Size $width, 4096
  $fullSz = [System.Windows.Forms.TextRenderer]::MeasureText($plain, $font, $propose, $flags)
  if ($fullSz.Height -le $maxH) { return @{ Text = $plain; Truncated = $false } }
  $lo = 0; $hi = $plain.Length
  while ($lo -lt $hi) {
    $mid = [int](($lo + $hi + 1) / 2)
    $candidate = $plain.Substring(0, $mid).TrimEnd() + '...'
    $sz = [System.Windows.Forms.TextRenderer]::MeasureText($candidate, $font, $propose, $flags)
    if ($sz.Height -le $maxH) { $lo = $mid } else { $hi = $mid - 1 }
  }
  if ($lo -le 0) {
    # single-line fallback
    $one = $plain
    if ($one.Length -gt 40) { $one = $one.Substring(0, 40) }
    return @{ Text = $one.TrimEnd() + '...'; Truncated = $true }
  }
  $cut = $plain.Substring(0, $lo)
  $breakAt = -1
  $nl = $cut.LastIndexOf("`n")
  $sp = $cut.LastIndexOf(' ')
  if ($nl -gt [int]($lo * 0.4)) { $breakAt = $nl }
  elseif ($sp -gt [int]($lo * 0.4)) { $breakAt = $sp }
  if ($breakAt -gt 0) { $cut = $cut.Substring(0, $breakAt) }
  return @{ Text = $cut.TrimEnd() + '...'; Truncated = $true }
}

function Show-NcMdModal([string]$title, [string]$md) {
  try {
    $f = New-Object System.Windows.Forms.Form
    $f.Text = $title
    $f.StartPosition = 'CenterParent'
    $f.Size = New-Object System.Drawing.Size 680, 540
    $f.MinimumSize = New-Object System.Drawing.Size 480, 360
    $f.BackColor = [System.Drawing.Color]::FromArgb(10, 14, 30)
    $f.ForeColor = $Ctext
    $f.FormBorderStyle = 'Sizable'
    $f.MaximizeBox = $true
    $f.MinimizeBox = $false
    $f.ShowInTaskbar = $false
    try { $f.Icon = $script:MainForm.Icon } catch {}
    $hdr = New-Object System.Windows.Forms.Label
    $hdr.Text = $title
    $hdr.Dock = 'Top'
    $hdr.Height = 44
    $hdr.Font = Get-UiFont 16 ([System.Drawing.FontStyle]::Bold)
    $hdr.ForeColor = $Ccyan
    $hdr.BackColor = [System.Drawing.Color]::FromArgb(14, 20, 40)
    $hdr.Padding = New-Object System.Windows.Forms.Padding 14, 8, 14, 8
    $hdr.TextAlign = 'MiddleLeft'
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = 'Close'
    $btn.Dock = 'Bottom'
    $btn.Height = 44
    $btn.FlatStyle = 'Flat'
    $btn.FlatAppearance.BorderSize = 0
    $btn.BackColor = [System.Drawing.Color]::FromArgb(20, 80, 110)
    $btn.ForeColor = [System.Drawing.Color]::White
    $btn.Font = Get-UiFont 12 ([System.Drawing.FontStyle]::Bold)
    $btn.Cursor = [System.Windows.Forms.Cursors]::Hand
    $btn.Add_Click({ param($s,$e) try { $s.FindForm().Close() } catch {} })
    $box = New-DarkMarkdownBox
    $box.Dock = 'Fill'
    try { $box.ScrollBars = 'Vertical' } catch {}
    Set-MarkdownRichText $box $md
    $f.Controls.Add($box)
    $f.Controls.Add($btn)
    $f.Controls.Add($hdr)
    $box.BringToFront()
    if ($script:MainForm -and $script:MainForm.Visible) { [void]$f.ShowDialog($script:MainForm) } else { [void]$f.ShowDialog() }
    $f.Dispose()
  } catch {
    try { Show-NcMsg @("Could not open $title", 'NORCOM') } catch {}
  }
}

function New-NcMdPreviewLabel {
  $lbl = New-Object System.Windows.Forms.Label
  $lbl.Name = 'CardMdPreview'
  $lbl.AutoSize = $false
  $lbl.Dock = 'None'
  $lbl.BorderStyle = 'None'
  $lbl.BackColor = [System.Drawing.Color]::FromArgb(10, 14, 30)
  $lbl.ForeColor = $Ctext
  $lbl.Font = Get-UiFont 12
  $lbl.UseMnemonic = $false
  $lbl.UseCompatibleTextRendering = $false
  return $lbl
}

function Set-NcMdPreview([System.Windows.Forms.Control]$card, [System.Windows.Forms.Label]$preview, [string]$md) {
  if (-not $card -or -not $preview) { return }
  $prevTitle = $null; try { if ($card.Tag -is [string]) { $prevTitle = [string]$card.Tag } elseif ($card.Tag -and $card.Tag.Title) { $prevTitle = [string]$card.Tag.Title } } catch {}; $card.Tag = [pscustomobject]@{ Title = $prevTitle; FullMd = [string]$md; FullPlain = (Convert-NcMdToPlain $md) }
  if ($card.Name -eq 'CardNews' -or ($preview -eq $script:NewsBox)) { $script:NewsFullMd = [string]$md }
  if ($card.Name -eq 'CardRules' -or ($preview -eq $script:RulesBox)) { $script:RulesFullMd = [string]$md }
  try { Fit-NcMarkdownBox $card } catch {}
}

function Fit-NcMarkdownBox([System.Windows.Forms.Control]$card) {
  # 1.0.30w: non-scrolling Label preview + Read more (whole lines only — no mid-glyph)
  if (-not $card) { return }
  $ttl = $null; $preview = $null; $more = $null
  foreach ($c in @($card.Controls)) {
    if ($c.Name -eq 'CardTitle') { $ttl = $c }
    elseif ($c.Name -eq 'CardMdPreview') { $preview = $c }
    elseif ($c.Name -eq 'CardMdMore') { $more = $c }
    elseif ($c -is [System.Windows.Forms.RichTextBox]) {
      # Legacy RTB: hide — preview path owns News/Rules now
      try { $c.Visible = $false } catch {}
    }
    elseif ($c.Name -eq 'CardMdClip' -or $c.Name -eq 'CardFadePad' -or $c.Name -eq 'CardFade') {
      try { $c.Visible = $false } catch {}
    }
  }
  if (-not $preview) { return }
  $padL = [Math]::Max(10, [int]$card.Padding.Left)
  $padR = [Math]::Max(10, [int]$card.Padding.Right)
  $titleH = 38
  if ($ttl) {
    try { $ttl.Dock = 'None' } catch {}
    try { $ttl.AutoSize = $false } catch {}
    $ttl.Location = New-Object System.Drawing.Point $padL, 6
    $ttl.Size = New-Object System.Drawing.Size ([Math]::Max(40, [int]$card.ClientSize.Width - $padL - $padR)), $titleH
    try { $ttl.BringToFront() } catch {}
  }
  $top = 6 + $titleH + 6
  $w = [Math]::Max(40, [int]$card.ClientSize.Width - $padL - $padR)
  $linkH = 22
  $avail = [Math]::Max(20, [int]$card.ClientSize.Height - $top - $linkH - 10)
  $font = $preview.Font
  if (-not $font) { $font = Get-UiFont 12 }
  $lineH = [Math]::Max(14, [System.Windows.Forms.TextRenderer]::MeasureText('Ay', $font).Height)
  $maxLines = [Math]::Max(1, [int][Math]::Floor($avail / [double]$lineH))
  $plain = ''
  try {
    if ($card.Tag -and $card.Tag.PSObject.Properties.Name -contains 'FullPlain') { $plain = [string]$card.Tag.FullPlain }
  } catch {}
  if (-not $plain) { $plain = [string]$preview.Text }
  $fit = Get-NcPreviewText $plain $font $w $maxLines
  $preview.Visible = $true
  $preview.Dock = 'None'
  $preview.Anchor = 'Top,Left,Right'
  $preview.Location = New-Object System.Drawing.Point $padL, $top
  $preview.Size = New-Object System.Drawing.Size $w, ($maxLines * $lineH)
  $preview.Text = [string]$fit.Text
  try { $preview.BringToFront() } catch {}
  if (-not $more) {
    $more = New-Object System.Windows.Forms.LinkLabel
    $more.Name = 'CardMdMore'
    $more.Text = 'Read more'
    $more.AutoSize = $true
    $more.LinkColor = $Ccyan
    $more.ActiveLinkColor = $Cgold
    $more.VisitedLinkColor = $Ccyan
    $more.BackColor = [System.Drawing.Color]::Transparent
    $more.Font = Get-UiFont 10 ([System.Drawing.FontStyle]::Bold)
    $more.Cursor = [System.Windows.Forms.Cursors]::Hand
    $more.Add_LinkClicked({
      param($s, $e)
      try {
        $owner = $s.Parent
        $md = ''
        $ttlText = 'Details'
        try {
          if ($owner.Tag -and $owner.Tag.PSObject.Properties.Name -contains 'FullMd') { $md = [string]$owner.Tag.FullMd }
          if ($owner.Controls | Where-Object { $_.Name -eq 'CardTitle' }) {
            $ttlText = ($owner.Controls | Where-Object { $_.Name -eq 'CardTitle' } | Select-Object -First 1).Text
          }
        } catch {}
        if (-not $md) {
          if ($owner -eq $script:CardNews) { $md = [string]$script:NewsFullMd; $ttlText = 'NEWS' }
          elseif ($owner -eq $script:CardRules) { $md = [string]$script:RulesFullMd; $ttlText = 'RULES' }
        }
        Show-NcMdModal $ttlText $md
      } catch {}
    })
    $card.Controls.Add($more)
  }
  $more.Visible = [bool]$fit.Truncated
  $more.Location = New-Object System.Drawing.Point $padL, ([int]$card.ClientSize.Height - $linkH - 6)
  try { $more.BringToFront() } catch {}
  if ($ttl) { try { $ttl.BringToFront() } catch {} }
}

function Reset-NcBoxesTop {
  # 1.0.30w: News/Rules are Labels — nothing to scroll
  foreach ($bx in @($script:NewsBox, $script:RulesBox)) {
    if ($bx -and ($bx -is [System.Windows.Forms.RichTextBox]) -and $bx.IsHandleCreated) {
      try { $bx.SelectionStart = 0; $bx.SelectionLength = 0; $bx.ScrollToCaret(); [NcScroll]::Top($bx.Handle) } catch {}
    }
  }
}
function Fit-NcCardLabels($card) {
  try {
    if ($script:CardServer -and $card -eq $script:CardServer) { return }
    if ($script:CardSettings -and $card -eq $script:CardSettings -and $script:CurrentPage -eq 'settings') { return }
    if (-not $script:NcOrigTop) { $script:NcOrigTop = @{} }
    $ttl = $null; foreach ($c0 in $card.Controls) { if ($c0.Name -eq 'CardTitle') { $ttl = $c0 } }
    if ($ttl) {
      $kids = @($card.Controls | Where-Object { $_.Name -ne 'CardTitle' -and $_.Dock -eq 'None' -and -not ($_ -is [System.Windows.Forms.RichTextBox]) })  # 1.0.30j: leave markdown boxes alone
      foreach ($k in $kids) { if (-not $script:NcOrigTop.ContainsKey($k)) { $script:NcOrigTop[$k] = $k.Top } }
      $kids = @($kids | Where-Object { $script:NcOrigTop[$_] -ge 30 })
      if ($kids.Count -gt 0) {
        $minTop = ($kids | ForEach-Object { $script:NcOrigTop[$_] } | Measure-Object -Minimum).Minimum
        $shift = [Math]::Max(0, ($ttl.Bottom + 2) - $minTop)
        $maxBot = ($kids | ForEach-Object { $script:NcOrigTop[$_] + $_.Height } | Measure-Object -Maximum).Maximum
        $over = ($maxBot + $shift) - ($card.ClientSize.Height - 6)
        if ($over -gt 0) { $shift = [Math]::Max(0, $shift - $over) }
        foreach ($k in $kids) { $nt = $script:NcOrigTop[$k] + $shift; if ($k.Top -ne $nt) { $k.Top = $nt } }
      }
    }
    $cw = $card.ClientSize.Width
    if ($ttl) {
      $ttl.AutoEllipsis = $true
      $fs = 18.0
      try { $fs = [double]$ttl.Font.Size } catch {}
      while ($fs -gt 11.0) {
        $f = Get-UiFont $fs ([System.Drawing.FontStyle]::Bold)
        $tw = [System.Windows.Forms.TextRenderer]::MeasureText($ttl.Text, $f).Width
        if ($tw -le ($cw - 16)) { break }
        $fs -= 0.5
      }
      try { $ttl.Font = Get-UiFont $fs ([System.Drawing.FontStyle]::Bold) } catch {}
    }
    foreach ($ctl in @($card.Controls)) {
      if ($ctl -is [System.Windows.Forms.Label] -and $ctl.Name -ne 'CardTitle' -and $ctl.Dock -eq 'None' -and -not $ctl.AutoSize) {
        $ctl.AutoEllipsis = $true
        if ($ctl -eq $script:RamValueLabel -and $script:CurrentPage -ne 'settings') { $ctl.TextAlign = 'MiddleRight'; $ctl.Width = (S 90); $ctl.Left = [Math]::Max((S 120), $cw - $ctl.Width - 14); continue }
        if ($script:CurrentPage -eq 'settings' -and ($ctl -eq $script:RamLabel -or $ctl -eq $script:RamValueLabel)) { continue }
        $maxW = $cw - $ctl.Left - 12
        if ($ctl -eq $script:ServerAddrLabel) { $maxW = $ctl.Width }
        if ($ctl.Right -gt ($cw - 8) -and $maxW -gt 40) { $ctl.Width = $maxW }
      }
    }
    if ($script:ServerAddrLabel -and $card -eq $script:CardServer) {
      $a = $script:ServerAddrLabel
      if (-not $script:NcAddrFont) { $script:NcAddrFont = $a.Font.Size }
      $fs = [double]$script:NcAddrFont
      while ($fs -gt 8.5) { $f = New-Object System.Drawing.Font($a.Font.FontFamily, [single]$fs); $tw = [System.Windows.Forms.TextRenderer]::MeasureText($a.Text, $f).Width; if ($tw -le $a.Width) { break }; $fs -= 0.5 }
      $a.Height = [Math]::Max($a.Height, $a.Font.Height + 6)
      if ([Math]::Abs($a.Font.Size - $fs) -gt 0.1) { $a.Font = New-Object System.Drawing.Font($a.Font.FontFamily, [single]$fs, $a.Font.Style) }
    }
  } catch {}
}




function Get-NorcomGpuInfo {
  $skip = '(?i)virtual|remote|meta|parsec|iddcx|microsoft basic|generic non-pnp|remote desktop|virtualbox|vmware|hyper-v|citrix|spacedesk|usb.?display|mirror|indirect'
  $list = @()
  try { $list = @(Get-CimInstance Win32_VideoController -EA SilentlyContinue) } catch {}
  $real = @($list | Where-Object { $_.Name -and ($_.Name -notmatch $skip) })
  if ($real.Count -eq 0) { $real = @($list | Where-Object { $_.Name }) }
  $best = $real | Sort-Object {
    $ram = 0L
    try { $ram = [int64]$_.AdapterRAM } catch { try { $ram = [uint32]$_.AdapterRAM } catch { $ram = 0 } }
    if ($ram -lt 0) { $ram = [uint32]$_.AdapterRAM }
    $ram
  } -Descending | Select-Object -First 1
  $name = if ($best -and $best.Name) { ([string]$best.Name).Trim() } else { 'unknown' }
  $profile = 'Balanced'
  if ($name -match '(?i)NVIDIA|GeForce|RTX|GTX|Quadro') { $profile = 'NVIDIA Performance' }
  elseif ($name -match '(?i)AMD|Radeon|RX ') { $profile = 'AMD Performance' }
  elseif ($name -match '(?i)Intel|UHD|Iris|Arc') { $profile = 'Intel iGPU' }
  elseif ($name -eq 'unknown' -or $name -match $skip) { $profile = 'Generic' }
  [pscustomobject]@{ Name = $name; Profile = $profile }
}



function Fit-ActionsLinks {
  # 1.0.30v: reparent onto ActionsGrid FIRST (LinksHost stays hidden; Visible get walks parents)
  $script:LastActionsFitErr = $null
  if (-not $script:CardLinks) { return }
  try {
    $btns = @($script:BtnDiscord, $script:BtnVoice, $script:BtnShots, $script:BtnCrash, $script:BtnMods)
    if ($script:SelfTest) {
      $btns = @($script:BtnSkin, $script:BtnBrowseOutfits) + $btns
      foreach ($b in @($script:BtnSkin, $script:BtnBrowseOutfits)) { if ($b) { try { $b.Visible = $true } catch {} } }
    } else {
      foreach ($b in @($script:BtnSkin, $script:BtnBrowseOutfits)) { if ($b) { try { $b.Visible = $false } catch {} } }
    }
    $ttl = $null
    foreach ($c0 in @($script:CardLinks.Controls)) { if ($c0.Name -eq 'CardTitle') { $ttl = $c0 } }
    $titleBottom = 46
    if ($ttl) {
      try { $ttl.Dock = 'None' } catch {}
      $ttl.Location = New-Object System.Drawing.Point 10, 6
      $ttl.Size = New-Object System.Drawing.Size ([Math]::Max(40, $script:CardLinks.ClientSize.Width - 20)), 34
      $titleBottom = [Math]::Max(40, [int]$ttl.Bottom)
      try { $ttl.BringToFront() } catch {}
    }
    $cw = [Math]::Max(120, [int]$script:CardLinks.ClientSize.Width)
    $ch = [Math]::Max(80, [int]$script:CardLinks.ClientSize.Height)
    $padL = 10; $padR = 10; $padB = 10
    $areaTop = $titleBottom + 4
    $areaH = [Math]::Max(48, $ch - $areaTop - $padB)
    $areaW = [Math]::Max(80, $cw - $padL - $padR)
    if ($script:LinksHost) { try { $script:LinksHost.Visible = $false } catch {} }

    $grid = $null
    foreach ($c0 in @($script:CardLinks.Controls)) { if ($c0.Name -eq 'ActionsGrid') { $grid = $c0 } }
    if (-not $grid) {
      $grid = New-Object System.Windows.Forms.TableLayoutPanel
      $grid.Name = 'ActionsGrid'
      $grid.BackColor = [System.Drawing.Color]::Transparent
      $grid.ColumnCount = 2
      $grid.RowCount = 3
      [void]$grid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50.0)))
      [void]$grid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50.0)))
      [void]$grid.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 33.34)))
      [void]$grid.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 33.33)))
      [void]$grid.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 33.33)))
      $script:CardLinks.Controls.Add($grid)
    }
    $grid.Location = New-Object System.Drawing.Point $padL, $areaTop
    $grid.Size = New-Object System.Drawing.Size $areaW, $areaH
    $grid.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right -bor [System.Windows.Forms.AnchorStyles]::Bottom
    $grid.Padding = New-Object System.Windows.Forms.Padding 4
    $grid.Visible = $true
    try { $grid.BringToFront() } catch {}

    $narrow = ($areaW -lt 360)
    # Collect candidates by reference (do NOT trust Visible while still on hidden LinksHost)
    $vis = New-Object System.Collections.Generic.List[System.Windows.Forms.Control]
    foreach ($b in $btns) {
      if (-not $b) { continue }
      try { if ($b.IsDisposed) { continue } } catch { continue }
      try {
        if ($b -eq $script:BtnMods) { $b.Text = $(if ($narrow) { 'Mods' } else { 'Open Mods' }) }
        elseif ($b -eq $script:BtnShots) { $b.Text = $(if ($narrow) { 'Shots' } else { 'Screenshots' }) }
        elseif ($b -eq $script:BtnDiscord) { $b.Text = 'Discord' }
        elseif ($b -eq $script:BtnVoice) { $b.Text = $(if ($narrow) { 'Voice' } else { 'Voice Chat' }) }
        elseif ($b -eq $script:BtnCrash) { $b.Text = $(if ($narrow) { 'Crash' } else { 'Crash Report' }) }
      } catch {}
      [void]$vis.Add($b)
    }
    $n = $vis.Count
    if ($n -lt 1) { $script:LastActionsFitErr = 'no-btns'; return }

    $rows = [Math]::Max(1, [int][Math]::Ceiling($n / 2.0))
    $grid.ColumnCount = 2
    $grid.RowCount = $rows
    $grid.RowStyles.Clear()
    $pct = [Math]::Round(100.0 / $rows, 2)
    for ($r = 0; $r -lt $rows; $r++) {
      [void]$grid.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, [single]$pct)))
    }
    # Remove stray non-button children
    foreach ($gc in @($grid.Controls)) {
      $keep = $false
      foreach ($vb in $vis) { if ([object]::ReferenceEquals($gc, $vb)) { $keep = $true; break } }
      if (-not $keep) { try { $grid.Controls.Remove($gc) } catch {} }
    }
    $bhMax = 44; $bhMin = 30
    $rowH = [int]($areaH / [double]$rows) - 8
    $bh = [Math]::Max($bhMin, [Math]::Min($bhMax, $rowH))

    for ($i = 0; $i -lt $n; $i++) {
      $b = $vis[$i]
      $col = $i % 2
      $row = [int][Math]::Floor($i / 2.0)
      $alone = ($row -eq ($rows - 1)) -and (($n % 2) -eq 1) -and ($i -eq ($n - 1))
      try { if ($b.Parent -and (-not [object]::ReferenceEquals($b.Parent, $grid))) { $b.Parent.Controls.Remove($b) } } catch {}
      $b.AutoSize = $false
      $b.Dock = [System.Windows.Forms.DockStyle]::Fill
      $b.Margin = New-Object System.Windows.Forms.Padding 4, 4, 4, 4
      $b.MinimumSize = New-Object System.Drawing.Size 72, $bhMin
      $b.MaximumSize = New-Object System.Drawing.Size 4096, $bhMax
      if ($bh -lt $bhMax) { $b.MaximumSize = New-Object System.Drawing.Size 4096, $bh }
      try { $b.Font = Get-UiFont 10 ([System.Drawing.FontStyle]::Bold) } catch {}
      try { if ($b -is [System.Windows.Forms.Button]) { $b.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter } } catch {}
      if (-not [object]::ReferenceEquals($b.Parent, $grid)) {
        if ($alone) {
          try { $grid.Controls.Add($b, 0, $row); $grid.SetColumnSpan($b, 2) } catch {
            try { [void]$grid.Controls.Add($b); $grid.SetColumnSpan($b, 2) } catch { $script:LastActionsFitErr = 'add-alone: ' + $_.Exception.Message }
          }
        } else {
          try { $grid.Controls.Add($b, $col, $row) } catch {
            try { [void]$grid.Controls.Add($b) } catch { $script:LastActionsFitErr = 'add: ' + $_.Exception.Message }
          }
        }
      } else {
        try { $grid.SetCellPosition($b, (New-Object System.Windows.Forms.TableLayoutPanelCellPosition($col, $row))) } catch {}
        if ($alone) { try { $grid.SetColumnSpan($b, 2) } catch {} } else { try { $grid.SetColumnSpan($b, 1) } catch {} }
      }
      try { $b.Visible = $true } catch {}
      try { $b.BringToFront() } catch {}
    }
    foreach ($bb in @($script:BtnDiscord, $script:BtnVoice, $script:BtnShots, $script:BtnCrash, $script:BtnMods)) {
      if ($bb) { try { $bb.Visible = $true } catch {} }
    }
    try { $grid.Visible = $true; $grid.BringToFront() } catch {}
    if ($ttl) { try { $ttl.BringToFront() } catch {} }
  } catch {
    $script:LastActionsFitErr = 'fit-ex: ' + $_.Exception.GetType().FullName + ': ' + $_.Exception.Message
  }
}



function Fit-PackRestartCard {
  # 1.0.30v: guarantee countdown fully inside; center block when tall; shrink when short
  if (-not $script:CardPackRestart) { return }
  $card = $script:CardPackRestart
  $h = [Math]::Max(80, $card.ClientSize.Height)
  $w = [Math]::Max(120, $card.ClientSize.Width)
  $pad = 14
  $padB = 14
  $ttl = $null
  foreach ($c0 in @($card.Controls)) { if ($c0.Name -eq 'CardTitle') { $ttl = $c0 } }
  $top = 44
  if ($ttl) {
    try { $ttl.Dock = 'None' } catch {}
    $ttl.Location = New-Object System.Drawing.Point $pad, 6
    $ttl.Size = New-Object System.Drawing.Size ([Math]::Max(40, $w - 2 * $pad)), 34
    $top = [Math]::Max(44, $ttl.Bottom + 6)
  }
  $info = $script:PackInfoLabel
  $cd = $script:RestartCountdownLabel
  $hint = $null
  foreach ($c0 in @($card.Controls)) {
    if ($c0 -is [System.Windows.Forms.Label] -and $c0 -ne $info -and $c0 -ne $cd -and $c0.Name -ne 'CardTitle') {
      if ($c0.Text -like 'Restart daily*') { $hint = $c0 }
    }
  }
  $avail = [Math]::Max(40, $h - $top - $padB)
  $infoH = 56; $hintH = 20; $cdH = 32; $gap = 6
  if ($avail -ge 160) { $infoH = 66; $cdH = 36; $gap = 8 }
  if ($avail -ge 220) { $infoH = 78; $cdH = 42; $gap = 10 }
  if ($avail -ge 280) { $infoH = 90; $cdH = 48; $gap = 12 }
  $block = $infoH + $gap + $hintH + $gap + $cdH
  while ($block -gt $avail -and $infoH -gt 40) { $infoH -= 4; $block = $infoH + $gap + $hintH + $gap + $cdH }
  while ($block -gt $avail -and $cdH -gt 26) { $cdH -= 2; $block = $infoH + $gap + $hintH + $gap + $cdH }
  while ($block -gt $avail -and $gap -gt 2) { $gap--; $block = $infoH + $gap + $hintH + $gap + $cdH }
  $y = $top
  if ($avail -gt ($block + 16)) { $y = $top + [int](($avail - $block) / 2) }
  # Hard clamp: countdown bottom must stay inside card
  $maxCdTop = $h - $padB - $cdH
  if (($y + $block - $cdH) -gt $maxCdTop) {
    $y = [Math]::Max($top, $maxCdTop - ($hintH + $gap + $infoH + $gap))
  }
  $innerW = [Math]::Max(80, $w - 2 * $pad)
  if ($info) {
    $info.AutoSize = $false
    $info.Location = New-Object System.Drawing.Point $pad, $y
    $info.Size = New-Object System.Drawing.Size $innerW, $infoH
    try { $info.Font = Get-UiFont $(if ($avail -gt 280) { 16 } elseif ($avail -gt 200) { 14 } else { 12 }) } catch {}
    $y = $info.Bottom + $gap
  }
  if ($hint) {
    $hint.AutoSize = $false
    $hint.Location = New-Object System.Drawing.Point $pad, $y
    $hint.Size = New-Object System.Drawing.Size $innerW, $hintH
    try { $hint.Font = Get-UiFont 11 } catch {}
    $y = $hint.Bottom + $gap
  }
  if ($cd) {
    $cd.AutoSize = $false
    if ($y + $cdH -gt ($h - $padB)) { $y = [Math]::Max($top, $h - $padB - $cdH) }
    $cd.Location = New-Object System.Drawing.Point $pad, $y
    $cd.Size = New-Object System.Drawing.Size $innerW, $cdH
    try { $cd.Font = Get-UiFont $(if ($avail -gt 280) { 24 } elseif ($avail -gt 200) { 18 } else { 15 }) ([System.Drawing.FontStyle]::Bold) } catch {}
    try { $cd.BringToFront() } catch {}
  }
}


function Fit-SettingsCard {
  # 1.0.30v: single-column stack; no H-scroll; right pad = VScrollBarWidth; tighter gaps
  if (-not $script:CardSettings) { return }
  $h = [Math]::Max(120, $script:CardSettings.ClientSize.Height)
  $w = [Math]::Max(160, $script:CardSettings.ClientSize.Width)
  try { $script:CardSettings.AutoScroll = $true } catch {}
  try {
    $script:CardSettings.AutoScroll = $true
    $script:CardSettings.HorizontalScroll.Enabled = $false
    $script:CardSettings.HorizontalScroll.Visible = $false
    $script:CardSettings.VerticalScroll.Enabled = $true
    # 1.0.30v2: kill H-scroll hard
    $script:CardSettings.PerformLayout()
    $script:CardSettings.HorizontalScroll.Maximum = 0
    $script:CardSettings.AutoScrollPosition = New-Object System.Drawing.Point 0, $script:CardSettings.AutoScrollPosition.Y
  } catch {}
  foreach ($c0 in @($script:CardSettings.Controls)) {
    if ($c0.Name -eq 'CardTitle') {
      if ($script:CurrentPage -eq 'settings') { $c0.Visible = $false; $c0.Height = 0 }
      else { $c0.Visible = $true }
    }
  }
  $vScroll = 0
  try { $vScroll = [System.Windows.Forms.SystemInformation]::VerticalScrollBarWidth } catch { $vScroll = 18 }
  $pad = 12
  $rightPad = $pad + $vScroll + 4
  $innerW = [Math]::Max(120, $w - $pad - $rightPad)
  $y = 10

  function Place-SectionLabel($lbl, [int]$yy) {
    if (-not $lbl) { return $yy }
    $lbl.Visible = $true
    $lbl.Location = New-Object System.Drawing.Point $pad, $yy
    $lbl.AutoSize = $true
    $lbl.MaximumSize = New-Object System.Drawing.Size $innerW, 0
    $lbl.Font = Get-UiFont 12 ([System.Drawing.FontStyle]::Bold)
    $lbl.ForeColor = $Ccyan
    return ($yy + 20)
  }

  $y = Place-SectionLabel $script:LblSecPerf $y
  if ($script:RamLabel) {
    $script:RamLabel.Text = 'Allocated RAM (this PC)'
    $script:RamLabel.Location = New-Object System.Drawing.Point $pad, $y
    $script:RamLabel.AutoSize = $true
    $script:RamLabel.Font = Get-UiFont 10 ([System.Drawing.FontStyle]::Bold)
    $script:RamLabel.ForeColor = $Ctan
  }
  if ($script:RamValueLabel) {
    $vx = $pad + 190
    try { if ($script:RamLabel) { $vx = $script:RamLabel.Right + 12 } } catch {}
    if ($vx -gt ($pad + $innerW - 60)) { $vx = $pad + [Math]::Max(80, $innerW - 60) }
    $script:RamValueLabel.Location = New-Object System.Drawing.Point $vx, $y
    $script:RamValueLabel.AutoSize = $true
    $script:RamValueLabel.Font = Get-UiFont 11 ([System.Drawing.FontStyle]::Bold)
    try { Update-RamLabel } catch {}
  }
  $y += 22
  if ($script:RamSlider) {
    try { $script:RamSlider.TickStyle = 'None' } catch {}
    # 1.0.30v3: keep slider inside innerW (prior +8 overhang caused H-scroll)
    $script:RamSlider.Location = New-Object System.Drawing.Point $pad, $y
    $script:RamSlider.Width = [Math]::Max(140, $innerW)
    $script:RamSlider.Height = 36
    $y = $script:RamSlider.Bottom + 8
  }
  if ($script:RamPresetHost) {
    $script:RamPresetHost.Location = New-Object System.Drawing.Point $pad, $y
    $script:RamPresetHost.Size = New-Object System.Drawing.Size $innerW, 34
    $script:RamPresetHost.WrapContents = $false
    $script:RamPresetHost.MaximumSize = New-Object System.Drawing.Size $innerW, 40
    $btns = @($script:RamPresetHost.Controls)
    if ($btns.Count -gt 0) {
      $bw = [Math]::Max(56, [int](($innerW - 12) / $btns.Count) - 6)
      foreach ($b in $btns) {
        $b.Width = $bw
        $b.Height = 30
        $b.AutoSize = $false
        $b.MinimumSize = New-Object System.Drawing.Size 56, 28
        $b.MaximumSize = New-Object System.Drawing.Size $bw, 32
        try { $b.Font = Get-UiFont 10 ([System.Drawing.FontStyle]::Bold) } catch {}
      }
    }
    $y += 38
  }
  if ($script:GraphicsProfileLabel) {
    $script:GraphicsProfileLabel.Location = New-Object System.Drawing.Point $pad, $y
    $script:GraphicsProfileLabel.Size = New-Object System.Drawing.Size $innerW, 18
    $script:GraphicsProfileLabel.Font = Get-UiFont 9
    $y += 20
  }

  $y = Place-SectionLabel $script:LblSecAppear ($y + 2)
  if ($script:ChkAnimBg) {
    $script:ChkAnimBg.AutoSize = $true
    $script:ChkAnimBg.Location = New-Object System.Drawing.Point $pad, $y
    $y += [Math]::Max(22, $script:ChkAnimBg.Height + 2)
  }
  if ($script:ChkSound) {
    $script:ChkSound.AutoSize = $false
    $script:ChkSound.Width = [Math]::Max(120, $innerW)
    $script:ChkSound.Height = 22
    $script:ChkSound.Location = New-Object System.Drawing.Point $pad, $y
    $y += 24
  }

  $y = Place-SectionLabel $script:LblSecGame ($y + 2)
  if ($script:BtnOpenGameFolder) { try { $script:BtnOpenGameFolder.Text = 'Game folder' } catch {} }
  if ($script:BtnOpenScreenshotsFolder) { try { $script:BtnOpenScreenshotsFolder.Text = 'Shots folder' } catch {} }
  if ($script:BtnOpenModsFolder) { try { $script:BtnOpenModsFolder.Text = 'Mods folder' } catch {} }
  $gameBtns = @($script:BtnOpenGameFolder, $script:BtnOpenScreenshotsFolder, $script:BtnOpenModsFolder)
  $gx = $pad
  $gbW = [Math]::Max(100, [int](($innerW - 16) / 3))
  $rowY = $y
  foreach ($gb in $gameBtns) {
    if (-not $gb) { continue }
    $gb.Visible = $true
    $gb.Size = New-Object System.Drawing.Size $gbW, 30
    $gb.MinimumSize = New-Object System.Drawing.Size 90, 28
    try { $gb.Font = Get-UiFont 9 ([System.Drawing.FontStyle]::Bold) } catch {}
    if (($gx + $gbW) -gt ($pad + $innerW + 4)) { $gx = $pad; $rowY += 34 }
    $gb.Location = New-Object System.Drawing.Point $gx, $rowY
    $gx += ($gbW + 8)
  }
  $y = $rowY + 34
  if ($script:JavaInfoLabel) {
    $script:JavaInfoLabel.Location = New-Object System.Drawing.Point $pad, $y
    $script:JavaInfoLabel.Size = New-Object System.Drawing.Size $innerW, 20
    $script:JavaInfoLabel.Font = Get-UiFont 9
    $y += 22
  }

  $y = Place-SectionLabel $script:LblSecMaint ($y + 2)
  $mx = $pad
  $mbW = [Math]::Max(110, [int](($innerW - 16) / 3))
  $mRow = $y
  foreach ($mb in @($script:BtnRepairSettings, $script:BtnCrashSettings, $script:BtnCheckUpdates)) {
    if (-not $mb) { continue }
    $mb.Visible = $true
    $mb.Size = New-Object System.Drawing.Size $mbW, 30
    $mb.MinimumSize = New-Object System.Drawing.Size 100, 28
    if (($mx + $mbW) -gt ($pad + $innerW + 4)) { $mx = $pad; $mRow += 34 }
    $mb.Location = New-Object System.Drawing.Point $mx, $mRow
    $mx += ($mbW + 8)
  }
  $y = $mRow + 36
  if ($script:VersionInfoLabel) { try { $script:VersionInfoLabel.Visible = $false } catch {} }
  if ($script:AboutNorcomLabel) {
    $script:AboutNorcomLabel.Visible = $true
    $script:AboutNorcomLabel.AutoSize = $false
    $script:AboutNorcomLabel.Location = New-Object System.Drawing.Point $pad, $y
    $script:AboutNorcomLabel.Size = New-Object System.Drawing.Size $innerW, 26
    $script:AboutNorcomLabel.Font = Get-UiFont 12 ([System.Drawing.FontStyle]::Bold)
    $script:AboutNorcomLabel.ForeColor = $Ccyan
    $script:AboutNorcomLabel.BackColor = [System.Drawing.Color]::FromArgb(18, 26, 52)
    try {
      $du = if ($script:DiscordUrl) { $script:DiscordUrl } else { 'https://discord.gg/baZx9CGxw' }
      $short = $du -replace '^https://',''
      $script:AboutNorcomLabel.Text = ('About NORCOM  v{0}  -  {1}' -f $script:NcLauncherVersion, $short)
    } catch {}
    try { $script:AboutNorcomLabel.BringToFront() } catch {}
    $y = $script:AboutNorcomLabel.Bottom + 10
  }
  # 1.0.30v3: clamp overhanging children; force no H-scroll
  $maxRight = $pad + $innerW
  foreach ($ch in @($script:CardSettings.Controls)) {
    try {
      if ($ch.Name -eq 'CardTitle') { continue }
      if ($ch.Right -gt ($maxRight + 2)) {
        $nw = [Math]::Max(40, $maxRight - $ch.Left)
        if ($nw -lt $ch.Width) { $ch.Width = $nw }
      }
    } catch {}
  }
  try { $script:CardSettings.AutoScrollMinSize = New-Object System.Drawing.Size 0, ([Math]::Max(0, $y + 10)) } catch {}
  try {
    $script:CardSettings.AutoScroll = $true
    $script:CardSettings.HorizontalScroll.Enabled = $false
    $script:CardSettings.HorizontalScroll.Visible = $false
    $script:CardSettings.VerticalScroll.Enabled = $true
    $script:CardSettings.PerformLayout()
    $script:CardSettings.HorizontalScroll.Maximum = 0
    $script:CardSettings.AutoScrollPosition = New-Object System.Drawing.Point 0, ([Math]::Abs([int]$script:CardSettings.AutoScrollPosition.Y))
  } catch {}
}

function Update-CharacterCardLayout {
  # 1.0.30x: Character page owns layout via CharBtnTable; keep home-card path table-safe
  if (-not $script:CardCharacter -or -not $script:SkinPreview) { return }
  if ($script:CharBtnTable) {
    if ($script:BtnClassicSlim) { $script:BtnClassicSlim.Text = $(if ($script:CharacterSlim) { 'Slim' } else { 'Classic' }) }
    if ($script:BtnUploadSkin) { $script:BtnUploadSkin.Text = 'Upload' }
    if ($script:BtnApplySkin) { $script:BtnApplySkin.Text = 'Apply' }
    if ($script:BtnBrowseOutfits2) { $script:BtnBrowseOutfits2.Text = 'Browse outfits'; $script:BtnBrowseOutfits2.Visible = $true }
    if ($script:CharBtnTable) { $script:CharBtnTable.Visible = $true; $script:CharBtnTable.Height = 36 }
    if ($script:CharCapeHost) { $script:CharCapeHost.Visible = $true }
    if ($script:CapeCombo) { $script:CapeCombo.Visible = $true }
    try { $script:SkinPreview.Dock = 'Fill' } catch {}
    if ($script:SavedSkinsHost) { $script:SavedSkinsHost.Visible = $false }
    return
  }
  $cw = [Math]::Max(120, $script:CardCharacter.ClientSize.Width - 16)
  $ch = [Math]::Max(80, $script:CardCharacter.ClientSize.Height - 36)
  $btnH = 26
  $need = ($btnH * 2) + 12
  $prevH = [Math]::Max(70, $ch - $need)
  $script:SkinPreview.Location = New-Object System.Drawing.Point 8, 4
  $script:SkinPreview.Size = New-Object System.Drawing.Size $cw, $prevH
}


function Fit-ServerCard {
  if (-not $script:CardServer) { return }
  $w = [Math]::Max(120, $script:CardServer.ClientSize.Width)
  $h = [Math]::Max(100, $script:CardServer.ClientSize.Height)
  $ttlH = 36
  $ttlBottom = 0
  foreach ($x in $script:CardServer.Controls) {
    if ($x.Name -eq 'CardTitle') {
      $ttlH = [Math]::Max(36, $x.Height)
      try { $ttlBottom = [Math]::Max($ttlBottom, [int]$x.Bottom) } catch { $ttlBottom = $ttlH }
    }
  }
  if ($ttlBottom -lt 1) { $ttlBottom = $ttlH + [int]$script:CardServer.Padding.Top }
  # 1.0.30p: compact priority Online â†’ Players â†’ World â†’ Address (no overlap)
  $compact = ($h -lt 220)
  $y = $ttlBottom + $(if ($compact) { 10 } else { 32 })
  $padL = 12
  if ($script:ServerDot) {
    $script:ServerDot.Location = New-Object System.Drawing.Point $padL, ($y + 6)
    $script:ServerDot.Size = New-Object System.Drawing.Size 12, 12
  }
  if ($script:ServerStatusLabel) {
    $script:ServerStatusLabel.Location = New-Object System.Drawing.Point ($padL + 18), $y
    $script:ServerStatusLabel.Size = New-Object System.Drawing.Size ([Math]::Max(80, $w - 140)), 22
    $stFont = if ($w -lt 280) { 12 } else { 13 }
    $script:ServerStatusLabel.Font = Get-UiFont $stFont ([System.Drawing.FontStyle]::Bold)
  }
  try { Update-PingChipSize } catch {}
  $y += 24
  $copyW = 72
  $addrH = 28
  $padR = if ($w -lt 280) { 28 } elseif ($w -lt 340) { 36 } else { 44 }
  $addrY = [Math]::Max(4, $h - $addrH - 12)
  # Reserve address band; keep Players above it
  if ($script:ServerPlayersLabel) {
    $script:ServerPlayersLabel.Visible = $true
    $script:ServerPlayersLabel.Location = New-Object System.Drawing.Point $padL, $y
    $script:ServerPlayersLabel.Size = New-Object System.Drawing.Size ([Math]::Max(80, $w - 24)), 18
    $script:ServerPlayersLabel.Font = Get-UiFont $(if ($compact) { 11 } else { 12 }) ([System.Drawing.FontStyle]::Bold)
    $y += 18
  }
  if ($script:PlayerHeadsHost) {
    if ($compact -or $h -lt 210) {
      $script:PlayerHeadsHost.Visible = $false
    } else {
      $script:PlayerHeadsHost.Location = New-Object System.Drawing.Point $padL, $y
      $script:PlayerHeadsHost.Size = New-Object System.Drawing.Size ([Math]::Max(80, $w - 24)), 36
      $script:PlayerHeadsHost.Visible = $true
      $y += 40
    }
  }
  if ($script:ServerNamesLabel) {
    $remain = $addrY - $y - 22
    if ($compact -or $remain -lt 16) {
      $script:ServerNamesLabel.Visible = $false
    } else {
      $nh = [Math]::Max(16, [Math]::Min(36, $remain))
      $script:ServerNamesLabel.Visible = $true
      $script:ServerNamesLabel.Location = New-Object System.Drawing.Point $padL, $y
      $script:ServerNamesLabel.Size = New-Object System.Drawing.Size ([Math]::Max(80, $w - 24)), $nh
      $script:ServerNamesLabel.Font = Get-UiFont 11
      $y += $nh + 2
    }
  }
  if ($script:LastPlayedLabel) {
    # 1.0.30q: always prefer short World line on compact when Players is shown
    if ($compact -or ($script:LastPlayedLabel.Text -match 'World:')) {
      try { $script:LastPlayedLabel.Text = 'World: NORCOM' } catch {}
    }
    $script:LastPlayedLabel.Location = New-Object System.Drawing.Point $padL, $y
    $script:LastPlayedLabel.Size = New-Object System.Drawing.Size ([Math]::Max(80, $w - 24)), 16
    $script:LastPlayedLabel.Font = Get-UiFont 10
    $script:LastPlayedLabel.ForeColor = $Ctan
    # If World would collide with address, pull address down/ tighter first
    if (($y + 16) -gt ($addrY - 2)) {
      $addrY = [Math]::Min($addrY, [Math]::Max($y + 18, $h - $addrH - 4))
    }
    $script:LastPlayedLabel.Visible = (($y + 14) -le ($addrY - 1))
    if ($script:LastPlayedLabel.Visible) { $y += 16 }
  }
  if ($y + 2 -gt $addrY) { $addrY = [Math]::Min($h - $addrH - 4, $y + 2) }
  if (($addrY + $addrH) -gt $h) { $addrY = [Math]::Max(4, $h - $addrH - 4) }
  $addrFont = if ($w -lt 260) { 9 } elseif ($w -lt 320) { 10 } elseif ($w -lt 380) { 11 } else { 12 }
  if ($script:BtnCopyAddr) {
    $script:BtnCopyAddr.Text = 'Copy'
    try { $script:BtnCopyAddr.Font = Get-UiFont 10 ([System.Drawing.FontStyle]::Bold) } catch {}
    $script:BtnCopyAddr.Size = New-Object System.Drawing.Size $copyW, 24
    $script:BtnCopyAddr.Location = New-Object System.Drawing.Point ([Math]::Max($padL, $w - $copyW - $padR)), ($addrY + 2)
    $script:BtnCopyAddr.Visible = $true
    $script:BtnCopyAddr.BringToFront()
  }
  if ($script:ServerAddrLabel) {
    $script:ServerAddrLabel.Location = New-Object System.Drawing.Point $padL, $addrY
    $aw = [Math]::Max(60, $w - $copyW - $padL - $padR - 8)
    $script:ServerAddrLabel.Size = New-Object System.Drawing.Size $aw, 30
    $script:ServerAddrLabel.Font = Get-UiFont $addrFont
    $script:ServerAddrLabel.AutoSize = $false
    try { $script:ServerAddrLabel.AutoEllipsis = $false } catch {}
    if (-not $script:ServerAddrLabel.Text) { $script:ServerAddrLabel.Text = 'shrimp-cub.tun.ply.gg' }
    # Shrink until full address fits on one line; else wrap to two
    try {
      $full = [string]$script:ServerAddrLabel.Text
      if (-not $full) { $full = 'shrimp-cub.tun.ply.gg' }
      $fs = $addrFont
      while ($fs -ge 8) {
        $f = Get-UiFont $fs
        $sz = [System.Windows.Forms.TextRenderer]::MeasureText($full, $f)
        if ($sz.Width -le ($aw - 2)) { break }
        $fs--
      }
      $script:ServerAddrLabel.Font = Get-UiFont $fs
      if ($fs -lt 10 -or $sz.Width -gt ($aw - 2)) {
        $script:ServerAddrLabel.Height = 32
        try { $script:ServerAddrLabel.MaximumSize = New-Object System.Drawing.Size $aw, 32 } catch {}
        try { $script:ServerAddrLabel.AutoSize = $false } catch {}
      }
    } catch {}
    $script:ServerAddrLabel.Visible = $true
    $script:ServerAddrLabel.BringToFront()
  }
}

function Update-LauncherCardLayout {
  if (-not $script:CardsFlow) { return }
  $script:UiScale = Get-UiScale
  $hostW = 800
  $hostH = 400
  try {
    $src = $null
    if ($script:PageHome -and $script:PageHome.ClientSize.Width -gt 40) { $src = $script:PageHome }
    elseif ($script:CardsScroll -and $script:CardsScroll.ClientSize.Width -gt 40) { $src = $script:CardsScroll }
    if ($src) {
      $hostW = $src.ClientSize.Width
      $hostH = [Math]::Max(200, $src.ClientSize.Height)
    }
  } catch {}
  # Use CardsScroll client size only - do not inflate beyond viewport (avoids outer scrollbar)

  # 1.0.30s: equal left/right margins vs neon (CardsFlow transparent - no dark strip)
  $side = 16
  if ($hostW -lt 700) { $side = 14 }
  $w = [Math]::Max(300, $hostW - (2 * $side))
  # keep even: if hostW odd, prefer left=right by flooring width
  if ((($hostW - $w) % 2) -ne 0) { $w = $w - 1 }
  $side = [int][Math]::Max(8, [Math]::Floor(($hostW - $w) / 2.0))
  $cols = 1
  if ($w -ge 740) { $cols = 3 }
  elseif ($w -ge 560) { $cols = 2 }
  $pad = S 8
  $script:NcCardsSide = $side
  # Balanced grid: row1 Server|News|Rules; row2 Links|PackRestart|Settings
  $cards = @($script:CardServer, $script:CardNews, $script:CardRules, $script:CardLinks, $script:CardPackRestart)
  $cards = @($cards | Where-Object { $_ })
  $n = $cards.Count
  if ($n -lt 1) { return }
  $rows = [Math]::Max(1, [int][Math]::Ceiling($n / [double]$cols))
  # Fill available height: equal row heights; when Character card present keep rows tall enough for controls
  $rowH = [int](($hostH - 12) / $rows)
  $minRow = S 220
  if ($cols -ge 3) { $minRow = S 210 }
  $minRow = S 180
  if ($cols -ge 2) { $minRow = S 170 }
  # Home page must never scroll: shrink rows to fit viewport
  $needScroll = $false
  if ($rowH -lt $minRow) { $rowH = [Math]::Max((S 150), $rowH) }
  # 1.0.34: keep last good size (minimize / monitor move can report tiny client sizes and "eat" columns)
  if ($hostW -lt 480 -or $hostH -lt 160) {
    if ($script:NcCardsLastHostW -and $script:NcCardsLastHostH) {
      $hostW = [int]$script:NcCardsLastHostW
      $hostH = [int]$script:NcCardsLastHostH
      if ($w -lt 300) {
        $w = [Math]::Max(300, $hostW - (2 * $side))
        if ($w -ge 740) { $cols = 3 } elseif ($w -ge 560) { $cols = 2 } else { $cols = 1 }
        $rows = [Math]::Max(1, [int][Math]::Ceiling($n / [double]$cols))
      }
    } else {
      return
    }
  } else {
    $script:NcCardsLastHostW = $hostW
    $script:NcCardsLastHostH = $hostH
  }
  $structKey = "{0}x{1}:{2}" -f $cols, $rows, (($cards | ForEach-Object { $_.GetHashCode() }) -join ',')
  $needRebuild = $true
  try {
    if ($script:NcCardsStructKey -eq $structKey -and $script:CardsFlow.Controls.Count -eq $n) { $needRebuild = $false }
  } catch { $needRebuild = $true }
  $script:CardsFlow.SuspendLayout()
  if ($needRebuild) {
    $script:CardsFlow.Controls.Clear()
    $script:CardsFlow.ColumnStyles.Clear()
    $script:CardsFlow.RowStyles.Clear()
    $script:CardsFlow.ColumnCount = $cols
    $script:CardsFlow.RowCount = $rows
    $script:NcCardsStructKey = $structKey
  } else {
    # still refresh column/row counts if needed without detaching cards
    if ($script:CardsFlow.ColumnCount -ne $cols -or $script:CardsFlow.RowCount -ne $rows) {
      $script:CardsFlow.Controls.Clear()
      $script:CardsFlow.ColumnStyles.Clear()
      $script:CardsFlow.RowStyles.Clear()
      $script:CardsFlow.ColumnCount = $cols
      $script:CardsFlow.RowCount = $rows
      $needRebuild = $true
      $script:NcCardsStructKey = $structKey
    }
  }
  if ($needRebuild -or $script:CardsFlow.ColumnStyles.Count -ne $cols -or $script:CardsFlow.RowStyles.Count -ne $rows) {
    $script:CardsFlow.ColumnStyles.Clear()
    $script:CardsFlow.RowStyles.Clear()
    $pct = [double](100.0 / $cols)
    for ($i = 0; $i -lt $cols; $i++) {
      [void]$script:CardsFlow.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, $pct)))
    }
    for ($r = 0; $r -lt $rows; $r++) {
      if ($needScroll) {
        [void]$script:CardsFlow.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, [float]$rowH)))
      } else {
        [void]$script:CardsFlow.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, [double](100.0 / $rows))))
      }
    }
  }
  $flowH = [Math]::Max(180, $hostH - 4)
  if ($needScroll) { $flowH = $rows * $rowH + 8 }
  $script:CardsFlow.Width = $w
  $script:CardsFlow.Height = $flowH
  try { $script:CardsScroll.AutoScroll = [bool]$needScroll } catch {}
  for ($i = 0; $i -lt $n; $i++) {
    $c = $cards[$i]
    $c.Dock = 'Fill'
    $c.Margin = New-Object System.Windows.Forms.Padding $pad
    $c.MinimumSize = New-Object System.Drawing.Size (S 200), (S 140)
    # scale card title
    foreach ($ctl in $c.Controls) {
      if ($ctl.Name -eq 'CardTitle') {
        $ctl.Font = Get-UiFont (Sf 18) ([System.Drawing.FontStyle]::Bold)
        $ctl.Height = S 32
      }
    }
    $col = $i % $cols
    $row = [int][Math]::Floor($i / [double]$cols)
    $script:CardsFlow.Controls.Add($c, $col, $row)
    try {
      # With 5 cards at 3 columns, span Pack/Restart across the empty bottom-right cell
      if ($cols -ge 3 -and $n -eq 5 -and $c -eq $script:CardPackRestart) {
        $script:CardsFlow.SetColumnSpan($c, 2)
      } else {
        $script:CardsFlow.SetColumnSpan($c, 1)
      }
    } catch {}
    # keep manually-placed children above the (transparent, Dock=Top) title so the title never paints over them
    foreach ($ctl in @($c.Controls)) { if ($ctl.Name -ne 'CardTitle' -and $ctl.Dock -eq 'None') { $ctl.BringToFront() } }
  }
  foreach ($c in $cards) { try { $c.Visible = $true } catch {} }
  try { if ($script:CardsFlow) { $script:CardsFlow.Visible = $true } } catch {}
  try { if ($script:CardsScroll) { $script:CardsScroll.Visible = $true } } catch {}
  try { Update-PingChipSize } catch {}
  $script:CardsFlow.ResumeLayout($true)
  $script:CardsFlow.PerformLayout()
  try { Fit-ServerCard } catch {}
  try { Update-PingChipSize } catch {}
  foreach ($c in $cards) { Fit-NcCardLabels $c }
  try { Fit-PackRestartCard } catch {}
  try { Fit-ActionsLinks } catch {}
  Reset-NcBoxesTop
  try {
    $script:CardsFlow.Height = $flowH
    $side = 12
    try { if ($script:NcCardsSide) { $side = [int]$script:NcCardsSide } } catch {}
    $script:CardsFlow.Left = $side
    $script:CardsFlow.Width = $w
    $script:CardsFlow.Top = 0
  } catch {}
  try { Update-CharacterCardLayout } catch {}
  try { Fit-SettingsCard } catch {}
  # refresh markdown fonts on scale change
  try {
    if ($script:NewsMd -and $script:NewsBox) {
      $nb = (Read-PackMarkdown 'news.md') -replace '\A\s*#{1,3}[^\r\n]*[Nn]ews[^\r\n]*\r?\n','' -replace '%APPDATA%\\?\.norcom','your NORCOM folder' -replace '%APPDATA%','your Minecraft folder'
      $nb = $nb.TrimStart()
      $script:NewsFullMd = $nb
      Set-NcMdPreview $script:CardNews $script:NewsBox $nb
    }
    if ($script:RulesBox) {
      $rb = (Read-PackMarkdown 'rules.md') -replace '\A\s*#{1,3}[^\r\n]*[Rr]ules[^\r\n]*\r?\n','' -replace '%APPDATA%\\?\.norcom','your NORCOM folder' -replace '%APPDATA%','your Minecraft folder'
      $rb = $rb.TrimStart()
      $script:RulesFullMd = $rb
      Set-NcMdPreview $script:CardRules $script:RulesBox $rb
    }
  } catch {}
  try { Fit-ActionsLinks } catch {}
}

function Update-LauncherHeroLayout {
  if (-not $script:HeroPanel) { return }
  $script:UiScale = Get-UiScale
  # 1.0.30s: Compact/shot path may skip ResizeDebounce - force hero tall enough for status
  try {
    $fh = 720
    try { if ($script:MainForm) { $fh = [int]$script:MainForm.ClientSize.Height } } catch {}
    if ($fh -lt 720) {
      $needHero = 255
      if ([int]$script:HeroPanel.Height -ne $needHero) {
        $script:HeroPanel.Height = $needHero
        $script:NcHeroHeight = $needHero
      }
    }
  } catch {}
  $hw = $script:HeroPanel.ClientSize.Width
  $hh = $script:HeroPanel.ClientSize.Height
  $logoSize = S 48
  $titleFont = Get-UiFont (Sf 26) ([System.Drawing.FontStyle]::Bold)
  $subFont = Get-UiFont (Sf 11)
  $playW = S 440
  $playH = S 72
  $playFont = Sf 24
  $heroCompact = ($hh -gt 0 -and $hh -lt 165)
  if ($hh -gt 0 -and $hh -lt 185) { $playH = S 56; $playW = S 400; $playFont = Sf 20 }
  if ($heroCompact) { $playH = S 42; $playW = S 380; $playFont = Sf 18; $logoSize = S 34; $titleFont = Get-UiFont (Sf 21) ([System.Drawing.FontStyle]::Bold) }
  if ($script:UiScale -ge 1.35) {
    $playW = S 560
    $playH = S 110
    $playFont = Sf 32
    $logoSize = S 64
    $titleFont = Get-UiFont (Sf 30) ([System.Drawing.FontStyle]::Bold)
    $subFont = Get-UiFont (Sf 12)
  }
  $titleW = S 220
  $titleH = S 34
  $subW = S 320
  $subH = S 20
  if ($heroCompact) { $titleH = S 30; $subH = S 18 }
  if ($script:HeroLogo) {
    $script:HeroLogo.Size = New-Object System.Drawing.Size $logoSize, $logoSize
  }
  if ($script:HeroTitle) {
    $script:HeroTitle.Font = $titleFont
    $script:HeroTitle.Size = New-Object System.Drawing.Size $titleW, $titleH
    $script:HeroTitle.TextAlign = 'MiddleLeft'
  }
  if ($script:HeroSub) {
    $script:HeroSub.Font = $subFont
    $script:HeroSub.Size = New-Object System.Drawing.Size $subW, $subH
    $script:HeroSub.TextAlign = 'MiddleCenter'
  }
  if ($script:BtnPrimary) {
    $script:BtnPrimary.Size = New-Object System.Drawing.Size $playW, $playH
    $script:BtnPrimary.Font = Get-UiFont $playFont ([System.Drawing.FontStyle]::Bold)
    if ($script:HasNorcomUi -and $script:BtnPrimary -is [NorcomUi.RoundedButton]) {
      $script:BtnPrimary.CornerRadius = [int]($playH * 0.28)
    }
  }
  if ($script:StatusLabel) {
    $script:StatusLabel.Font = Get-UiFont (Sf 11)
    $script:StatusLabel.AutoSize = $true
    $script:StatusLabel.BackColor = [System.Drawing.Color]::Transparent
    $script:StatusLabel.ForeColor = $Cdim
  }
  if ($script:Progress) {
    $script:Progress.Size = New-Object System.Drawing.Size $playW, (S 8)
  }
  # Cyber Sleek: NORCOM wordmark only (no extra N icon); PLAY stays centered
  $wmW = S 280; $wmH = S 56
  if ($heroCompact) { $wmW = S 220; $wmH = S 44 }
  $brandLeft = S 18
  $topBrand = S 8
  if ($script:HeroTitle) { $script:HeroTitle.Font = Get-DisplayFont (Sf 26) ([System.Drawing.FontStyle]::Bold); $script:HeroTitle.ForeColor = $Ccyan }
  # Prefer wordmark alone; hide circular N when wordmark is available
  if ($script:HeroLogo) {
    if ($script:HeroWordmark -and $script:HeroWordmark.Visible) {
      $script:HeroLogo.Visible = $false
      $logoSize = 0
    } else {
      $script:HeroLogo.Visible = $true
      $script:HeroLogo.Left = $brandLeft
      $script:HeroLogo.Top = $topBrand + [int](([Math]::Max($logoSize, $titleH) - $logoSize) / 2)
    }
  }
  $rowH = [Math]::Max($logoSize, $titleH)
  if ($script:HeroWordmark -and $script:HeroWordmark.Visible) { $rowH = [Math]::Max($rowH, $wmH) }
  if ($script:HeroWordmark -and $script:HeroWordmark.Visible) {
    $script:HeroWordmark.Size = New-Object System.Drawing.Size $wmW, $wmH
    $script:HeroWordmark.Left = $brandLeft
    $script:HeroWordmark.Top = $topBrand + [int](($rowH - $wmH) / 2)
    if ($script:HeroTitle) { $script:HeroTitle.Visible = $false }
  } elseif ($script:HeroTitle) {
    $script:HeroTitle.Visible = $true
    $script:HeroTitle.Left = $brandLeft + $logoSize + 12
    $script:HeroTitle.Top = $topBrand + [int](($rowH - $titleH) / 2)
  }
  $subTop = $topBrand + $rowH + $(if ($heroCompact) { S 1 } else { S 4 })
  if ($script:HeroSub) {
    $script:HeroSub.Left = [Math]::Max(0, [int](($hw - $subW) / 2))
    $script:HeroSub.Top = $subTop
  }
  $playLeft = [Math]::Max(0, [int](($hw - $playW) / 2))
  $playTop = $subTop + $subH + $(if ($heroCompact) { S 5 } else { S 8 })
  # 1.0.30q: reserve full status line under PLAY (tabs sit just below hero)
  $statusReserve = $(if ($hh -lt 220) { 26 } else { 28 })
  $need = $playTop + $playH + $statusReserve
  if ($need -gt $hh -and $hh -gt 80) {
    $playH = [Math]::Max((S 44), $playH - ($need - $hh))
    if ($script:BtnPrimary) {
      $script:BtnPrimary.Size = New-Object System.Drawing.Size $playW, $playH
      if ($script:HasNorcomUi -and $script:BtnPrimary -is [NorcomUi.RoundedButton]) {
        $script:BtnPrimary.CornerRadius = [int]($playH * 0.28)
      }
    }
  }
  if ($script:BtnPrimary) {
    $script:BtnPrimary.Left = $playLeft
    $script:BtnPrimary.Top = $playTop
  }
  if ($script:StatusLabel) {
    $script:StatusLabel.AutoSize = $true
    $script:StatusLabel.Top = $playTop + $playH + $(if ($heroCompact) { S 2 } else { S 4 })
    $sw = 0
    try { $sw = [int]$script:StatusLabel.PreferredWidth } catch {}
    if ($sw -lt 20) {
      try { $sw = [System.Windows.Forms.TextRenderer]::MeasureText([string]$script:StatusLabel.Text, $script:StatusLabel.Font).Width } catch { $sw = 200 }
    }
    $script:StatusLabel.Left = $playLeft + [Math]::Max(0, [int](($playW - $sw) / 2))
    $script:StatusLabel.TextAlign = 'MiddleCenter'
    $script:StatusLabel.BackColor = [System.Drawing.Color]::Transparent
    # 1.0.30q: always keep full status glyphs above hero bottom (tabs sit just below hero)
    try {
      $stH = 18
      try { $stH = [Math]::Max(16, [int]$script:StatusLabel.PreferredHeight) } catch {}
      try {
        $mh = [System.Windows.Forms.TextRenderer]::MeasureText('Ay', $script:StatusLabel.Font).Height
        if ($mh -gt $stH) { $stH = $mh }
      } catch {}
      $maxTop = [Math]::Max(0, $hh - $stH - 14)  # 1.0.30s: keep status well above tabs
      if ($script:StatusLabel.Top -gt $maxTop) { $script:StatusLabel.Top = $maxTop }
      if ($script:BtnPrimary -and ($script:StatusLabel.Top -lt ($playTop + $playH + 2))) {
        # nudge PLAY up/shorter so status clears PLAY and hero bottom
        $newPlayH = [Math]::Max((S 40), $script:StatusLabel.Top - $playTop - 4)
        if ($newPlayH -lt $playH) {
          $script:BtnPrimary.Height = $newPlayH
          $playH = $newPlayH
          if ($script:HasNorcomUi -and $script:BtnPrimary -is [NorcomUi.RoundedButton]) {
            $script:BtnPrimary.CornerRadius = [int]($playH * 0.28)
          }
        }
      }
    } catch {}
    try { $script:StatusLabel.BringToFront() } catch {}
  }
  if ($script:Progress) {
    $script:Progress.Left = $playLeft
    $script:Progress.Top = $playTop + $playH + (S 28)
  }
  if ($script:HeroUnderline) {
    if ($script:HeroWordmark -and $script:HeroWordmark.Visible) {
      $script:HeroUnderline.Visible = $false
    } elseif ($script:HeroTitle -and $script:HeroTitle.Visible) {
      $script:HeroUnderline.Visible = $true
      $script:HeroUnderline.Width = [Math]::Max(80, $script:HeroTitle.Width - 20)
      $script:HeroUnderline.Height = 3
      $script:HeroUnderline.Left = $script:HeroTitle.Left
      $script:HeroUnderline.Top = $script:HeroTitle.Bottom + 2
    } else {
      $script:HeroUnderline.Visible = $false
    }
  }
}

function Save-LauncherWindowBounds {
  try {
    if (-not $script:MainForm) { return }
    if ($script:MainForm.WindowState -ne 'Normal') { return }
    $s = Get-NorcomSettings
    $s.windowW = $script:MainForm.ClientSize.Width
    $s.windowH = $script:MainForm.ClientSize.Height
    Save-NorcomSettings $s
  } catch {}
}

# ===== MAIN FORM =====
# Dark scrollbars / edit borders: Windows dark-mode theme for native controls (no white system scrollbars)
function Initialize-NcDark {
  try {
    if (-not ('NcDark' -as [type])) {
      Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices; using System.Windows.Forms;
public static class NcDark {
  [DllImport("uxtheme.dll", CharSet=CharSet.Unicode)] static extern int SetWindowTheme(IntPtr h, string app, string idl);
  [DllImport("uxtheme.dll", EntryPoint="#135")] static extern int SetPreferredAppMode(int mode);
  [DllImport("uxtheme.dll", EntryPoint="#133")] static extern bool AllowDarkModeForWindow(IntPtr h, bool allow);
  [DllImport("uxtheme.dll", EntryPoint="#136")] static extern void FlushMenuThemes();
  static bool inited;
  public static void Init() { if (inited) return; inited = true; try { SetPreferredAppMode(2); FlushMenuThemes(); } catch {} }
  static void One(Control c) {
    try {
      TextBoxBase tbb = c as TextBoxBase;
      if (tbb != null && tbb.Multiline && tbb.BorderStyle != BorderStyle.None) tbb.BorderStyle = BorderStyle.None;
      ListBox lbx = c as ListBox;
      if (lbx != null && lbx.BorderStyle != BorderStyle.None) lbx.BorderStyle = BorderStyle.None;
      TreeView tvw = c as TreeView;
      if (tvw != null && tvw.BorderStyle != BorderStyle.None) tvw.BorderStyle = BorderStyle.None;
      if (!c.IsHandleCreated) return;
      string theme = null;
      if (tbb != null && tbb.Multiline) theme = "DarkMode_Explorer";
      else if (c is TextBoxBase || c is ComboBox) theme = "DarkMode_CFD";
      else if (c is ListBox || c is TreeView || c is ListView || c is ScrollableControl || c is DataGridView) theme = "DarkMode_Explorer";
      if (theme == null) return;
      try { AllowDarkModeForWindow(c.Handle, true); } catch {}
      SetWindowTheme(c.Handle, theme, null);
    } catch {}
  }
  public static void Apply(Control root) {
    Init(); One(root);
    foreach (Control ch in root.Controls) Apply(ch);
  }
  static System.Collections.Generic.HashSet<Control> hooked = new System.Collections.Generic.HashSet<Control>();
  public static void Hook(Control c) {
    Init();
    if (hooked.Add(c)) {
      c.ControlAdded += (s, e) => { try { Hook(e.Control); } catch {} };
      c.HandleCreated += (s, e) => { try { One((Control)s); } catch {} };
      c.Disposed += (s, e) => { hooked.Remove((Control)s); };
    }
    One(c);
    foreach (Control ch in c.Controls) Hook(ch);
  }
}
'@ -ReferencedAssemblies System.Windows.Forms
    }
    [NcDark]::Init()
  } catch {}
}
Initialize-NcDark



function Enable-NorcomSmoothPaint {
  param([System.Windows.Forms.Control]$Ctrl)
  if (-not $Ctrl) { return }
  try {
    $prop = $Ctrl.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'Instance,NonPublic')
    if ($prop) { $prop.SetValue($Ctrl, $true, $null) }
  } catch {}
  try {
    $m = $Ctrl.GetType().GetMethod('SetStyle', [Reflection.BindingFlags]'Instance,NonPublic', $null, [type[]]@([System.Windows.Forms.ControlStyles], [bool]), $null)
    if ($m) {
      $styles = [System.Windows.Forms.ControlStyles]::AllPaintingInWmPaint -bor [System.Windows.Forms.ControlStyles]::UserPaint -bor [System.Windows.Forms.ControlStyles]::OptimizedDoubleBuffer -bor [System.Windows.Forms.ControlStyles]::ResizeRedraw
      [void]$m.Invoke($Ctrl, @($styles, $true))
    }
  } catch {}
}
# Preload composited helper BEFORE any UI Show (Add-Type during Shown can deadlock STA).
if (-not ('NcExStyle' -as [type])) {
  try {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class NcExStyle {
  public const int GWL_EXSTYLE = -20;
  public const int WS_EX_COMPOSITED = 0x02000000;
  [DllImport("user32.dll", EntryPoint="GetWindowLong")] public static extern int GetWindowLong32(IntPtr h, int n);
  [DllImport("user32.dll", EntryPoint="SetWindowLong")] public static extern int SetWindowLong32(IntPtr h, int n, int v);
  [DllImport("user32.dll", EntryPoint="GetWindowLongPtr")] public static extern IntPtr GetWindowLongPtr64(IntPtr h, int n);
  [DllImport("user32.dll", EntryPoint="SetWindowLongPtr")] public static extern IntPtr SetWindowLongPtr64(IntPtr h, int n, IntPtr v);
  public static void EnableComposited(IntPtr hwnd) {
    if (IntPtr.Size == 8) {
      var cur = GetWindowLongPtr64(hwnd, GWL_EXSTYLE).ToInt64();
      SetWindowLongPtr64(hwnd, GWL_EXSTYLE, new IntPtr(cur | WS_EX_COMPOSITED));
    } else {
      var cur = GetWindowLong32(hwnd, GWL_EXSTYLE);
      SetWindowLong32(hwnd, GWL_EXSTYLE, cur | WS_EX_COMPOSITED);
    }
  }
}
'@
  } catch {}
}

function Set-NorcomRedraw([System.Windows.Forms.Control]$Ctrl, [bool]$Enable) {
  if (-not $Ctrl -or $Ctrl.IsDisposed -or -not $Ctrl.IsHandleCreated) { return }
  try {
    $WM_SETREDRAW = 0x000B
    $hwnd = $Ctrl.Handle
    if (-not ('NcRedraw' -as [type])) {
      Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices;
public static class NcRedraw {
  [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);
}
"@
    }
    [void][NcRedraw]::SendMessage($hwnd, $WM_SETREDRAW, [IntPtr]($(if ($Enable) { 1 } else { 0 })), [IntPtr]::Zero)
    if ($Enable) { try { $Ctrl.Invalidate($true); $Ctrl.Update() } catch {} }
  } catch {}
}

function Enable-NorcomComposited([System.Windows.Forms.Form]$Form) {
  if (-not $Form) { return }
  try {
    if ($Form.IsHandleCreated -and ('NcExStyle' -as [type])) { [NcExStyle]::EnableComposited($Form.Handle) }
  } catch {}
}
function Invoke-NorcomFinishLayoutHidden {
  # Layout is finalized pre-Application.Run; reveal only fades.
  try { Write-NcStartupLog 'clean-startup: layout hidden noop' } catch {}
}
function Test-NorcomReducedMotion {
  try {
    if ($env:NORCOM_REDUCED_MOTION -eq '1') { return $true }
    $key = Get-ItemProperty -Path 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name 'MinAnimate' -EA SilentlyContinue
    if ($null -ne $key -and [string]$key.MinAnimate -eq '0') { return $true }
    if (-not ('NcAnimPref' -as [type])) {
      Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices;
public static class NcAnimPref {
  [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a, uint b, ref int c, uint d);
  public static bool ClientAreaAnimation() { int v = 1; SystemParametersInfo(0x1042, 0, ref v, 0); return v != 0; }
}
"@
    }
    if (-not [NcAnimPref]::ClientAreaAnimation()) { return $true }
  } catch {}
  return $false
}
function Invoke-NorcomCleanReveal {
  # 1.0.33: SOLID reveal only — never Opacity fade / never translucent overlays.
  # Window stays Opacity=1. Optional short opaque glide; reduced-motion = instant.
  if ($script:NcRevealDone) { return }
  $script:NcRevealDone = $true
  $form = $script:MainForm
  if (-not $form) { return }
  try { Write-NcStartupLog 'clean-startup: reveal begin (solid opaque)' } catch {}

  try {
    Enable-NorcomComposited $form
    Enable-NorcomSmoothPaint $form
    if ($script:RootPanel) {
      Enable-NorcomSmoothPaint $script:RootPanel
      try { $script:RootPanel.BackColor = [System.Drawing.Color]::FromArgb(6, 10, 28) } catch {}
      # Pre-paint city scene into cache while still Opacity=0 / splash covering
      try {
        if ($script:RootPanel.GetType().Name -eq 'AnimatedCityBg') {
          $script:RootPanel.WarmSceneCache()
          Write-NcStartupLog 'clean-startup: WarmSceneCache done'
        }
      } catch { try { Write-NcStartupLog ('clean-startup: WarmSceneCache ' + $_.Exception.Message) } catch {} }
    }
    try { $form.BackColor = [System.Drawing.Color]::FromArgb(6, 10, 28) } catch {}
    try { $form.Invalidate($true); $form.Update() } catch {}
    # Instant opaque show (not a fade) once first frame is ready
    try { $form.Opacity = 1 } catch {}
    try { Set-NorcomRedraw $form $true } catch {}
    try { Write-NcStartupLog 'clean-startup: WM_SETREDRAW release + Opacity=1' } catch {}
    try { $form.Refresh() } catch {}
    # Close splash AFTER main is opaque and painted — no white gap
    try { Close-NorcomSplash $script:Splash } catch {}
    $script:Splash = $null
    try { Write-NcStartupLog 'clean-startup: splash closed after solid show' } catch {}

    $reduced = $false
    try { $reduced = Test-NorcomReducedMotion } catch {}
    $script:NcRevealFinalTop = $form.Top
    $script:NcRevealGlide = 14
    $script:NcRevealReduced = $reduced
    $script:NcRevealMs = 0
    $script:NcRevealTotalMs = $(if ($reduced) { 0 } else { 720 })

    if ($reduced -or $script:NcRevealTotalMs -le 0) {
      try { $form.Opacity = 1; $form.Top = $script:NcRevealFinalTop; $form.Activate() } catch {}
      try { Write-NorcomActivateAck } catch {}
      try { Write-NcStartupLog 'clean-startup: solid instant show (reduced motion)' } catch {}
      try {
        Enable-NorcomComposited $form
        Enable-NorcomSmoothPaint $form
        if ($script:RootPanel) { Enable-NorcomSmoothPaint $script:RootPanel }
        Write-NcStartupLog 'clean-startup: composited+smoothpaint steady'

          try {
            if (-not $script:NcFpsTimer) {
              $script:NcFpsTimer = New-Object System.Windows.Forms.Timer
              $script:NcFpsTimer.Interval = 2500
              $script:NcFpsTimer.Add_Tick({
                try {
                  $script:NcFpsTimer.Stop()
                  $rp = $script:RootPanel
                  if ($rp -and $rp.GetType().Name -eq 'AnimatedCityBg') {
                    $fps = [int]$rp.MeasuredFps
                    $avg = [double]$rp.MeasuredFrameMsAvg
                    $var = [double]$rp.MeasuredFrameMsVar
                    Write-NcStartupLog ("perf: AnimClock fps={0} frameMsAvg={1:N2} frameMsVar={2:N2}" -f $fps,$avg,$var)
                  }
                } catch {
                  try { Write-NcStartupLog ('perf: fps probe failed: ' + $_.Exception.Message) } catch {}
                }
              })
              $script:NcFpsTimer.Start()
            }
          } catch {}
      } catch {}
      try {
        $script:NcTopTimer = New-Object System.Windows.Forms.Timer
        $script:NcTopTimer.Interval = 700
        $script:NcTopTimer.Add_Tick({ $script:NcTopTimer.Stop(); Reset-NcBoxesTop })
        $script:NcTopTimer.Start()
      } catch {}
      return
    }

    # Start glide from slightly below — fully opaque the whole time
    try { $form.Top = $script:NcRevealFinalTop + $script:NcRevealGlide; $form.Opacity = 1 } catch {}
    try { $form.Activate() } catch {}

    $script:NcFadeTimer = New-Object System.Windows.Forms.Timer
    $script:NcFadeTimer.Interval = 8
    $script:NcFadeTimer.Add_Tick({
      try {
        $script:NcRevealMs += 8
        $t = [Math]::Min(1.0, $script:NcRevealMs / [double]$script:NcRevealTotalMs)
        $e = 1.0 - [Math]::Pow(1.0 - $t, 3)
        $form = $script:MainForm
        if ($form -and -not $form.IsDisposed) {
          try { $form.Opacity = 1 } catch {}
          try { $form.Top = [int]($script:NcRevealFinalTop + ((1.0 - $e) * $script:NcRevealGlide)) } catch {}
        }
        # Opaque wordmark power-on: brighten via existing paint path if available (no translucent overlay)
        try {
          if ($script:HeroWordmark -and -not $script:HeroWordmark.IsDisposed) {
            $script:HeroWordmark.Invalidate($false)
          }
        } catch {}
        if ($t -ge 1.0) {
          $script:NcFadeTimer.Stop()
          try { $script:NcFadeTimer.Dispose() } catch {}
          try { if ($form) { $form.Opacity = 1; $form.Top = $script:NcRevealFinalTop } } catch {}
          try { Write-NcStartupLog 'clean-startup: solid glide complete' } catch {}
          try { if ($form) { $form.Activate() } } catch {}
          try { Write-NorcomActivateAck } catch {}
          try {
            Enable-NorcomComposited $form
            Enable-NorcomSmoothPaint $form
            if ($script:RootPanel) { Enable-NorcomSmoothPaint $script:RootPanel }
            foreach ($c in @($script:HeroPanel,$script:CardsHost,$script:CardsFlow,$script:NavHome,$script:NavCharacter,$script:NavSettings,$script:BtnPrimary,$script:FooterPanel,$script:HeroWordmark)) {
              try { if ($c) { Enable-NorcomSmoothPaint $c } } catch {}
            }
            try { Write-NcStartupLog 'clean-startup: composited+smoothpaint steady' } catch {}

          try {
            if (-not $script:NcFpsTimer) {
              $script:NcFpsTimer = New-Object System.Windows.Forms.Timer
              $script:NcFpsTimer.Interval = 2500
              $script:NcFpsTimer.Add_Tick({
                try {
                  $script:NcFpsTimer.Stop()
                  $rp = $script:RootPanel
                  if ($rp -and $rp.GetType().Name -eq 'AnimatedCityBg') {
                    $fps = [int]$rp.MeasuredFps
                    $avg = [double]$rp.MeasuredFrameMsAvg
                    $var = [double]$rp.MeasuredFrameMsVar
                    Write-NcStartupLog ("perf: AnimClock fps={0} frameMsAvg={1:N2} frameMsVar={2:N2}" -f $fps,$avg,$var)
                  }
                } catch {
                  try { Write-NcStartupLog ('perf: fps probe failed: ' + $_.Exception.Message) } catch {}
                }
              })
              $script:NcFpsTimer.Start()
            }
          } catch {}
          } catch {}
          try {
            $script:NcTopTimer = New-Object System.Windows.Forms.Timer
            $script:NcTopTimer.Interval = 700
            $script:NcTopTimer.Add_Tick({ $script:NcTopTimer.Stop(); Reset-NcBoxesTop })
            $script:NcTopTimer.Start()
          } catch {}
        }
      } catch {
        try { $script:NcFadeTimer.Stop() } catch {}
        try { if ($script:MainForm) { $script:MainForm.Opacity = 1; if ($null -ne $script:NcRevealFinalTop) { $script:MainForm.Top = $script:NcRevealFinalTop } } } catch {}
        try { Close-NorcomSplash $script:Splash } catch {}
        try { Write-NcStartupLog ('clean-startup: solid anim fallback: ' + $_.Exception.Message) } catch {}
      }
    })
    try { Write-NcStartupLog 'clean-startup: solid glide start' } catch {}
    $script:NcFadeTimer.Start()
  } catch {
    try { Write-NcStartupLog ('clean-startup reveal failed: ' + $_.Exception.Message) } catch {}
    try { $form.Opacity = 1 } catch {}
    try { Close-NorcomSplash $script:Splash } catch {}
  }
}

function Show-NorcomSplash {
  param([string]$Message = 'Starting NORCOM...')
  $forceSplashShot = $false
  try {
    if ($env:NORCOM_FORCE_SPLASH_SHOT) { $forceSplashShot = $true }
    if ($env:NORCOM_SHOT_PAGE -and $env:NORCOM_SHOT_PAGE.Trim().ToLowerInvariant() -eq 'splash') { $forceSplashShot = $true }
  } catch {}
  if (-not $forceSplashShot -and ($shotPath -or $env:NORCOM_LAUNCHER_SELFTEST -or $ScreenshotPath)) { return $null }
  try {
    $sp = New-Object System.Windows.Forms.Form
    $sp.FormBorderStyle = 'None'
    $sp.StartPosition = 'CenterScreen'
    $sp.Size = New-Object System.Drawing.Size 460, 260
    $sp.BackColor = [System.Drawing.Color]::FromArgb(6, 8, 18)
    $sp.TopMost = $true
    $sp.ShowInTaskbar = $false
    # City glow backdrop
    $bgBox = New-Object System.Windows.Forms.PictureBox
    $bgBox.Dock = 'Fill'
    $bgBox.SizeMode = 'Stretch'
    $bgBox.BackColor = [System.Drawing.Color]::FromArgb(6, 8, 18)
    foreach ($cand in @(
      (Join-Path $Assets 'city-bg.jpg'),
      (Join-Path $ScriptDir 'assets\city-bg.jpg'),
      (Join-Path $Assets 'bg.png'),
      (Join-Path $ScriptDir 'assets\bg.png')
    )) {
      if (Test-Path -LiteralPath $cand) {
        try { $bgBox.Image = [System.Drawing.Image]::FromFile($cand); break } catch {}
      }
    }
    $sp.Controls.Add($bgBox)
    $veil = New-Object System.Windows.Forms.Panel
    $veil.Dock = 'Fill'
    # Lighter veil so city glow reads behind the wordmark + loading bar
    $veil.BackColor = [System.Drawing.Color]::FromArgb(110, 4, 6, 18)
    $sp.Controls.Add($veil)
    $veil.BringToFront()
    $pb = New-Object System.Windows.Forms.PictureBox
    $pb.Size = New-Object System.Drawing.Size 380, 78
    $pb.Location = New-Object System.Drawing.Point 40, 36
    $pb.SizeMode = 'Zoom'
    $pb.BackColor = [System.Drawing.Color]::Transparent
    $wm = $null
    foreach ($cand in @(
      (Join-Path $Assets 'wordmark-norcom.png'),
      (Join-Path $ScriptDir 'assets\wordmark-norcom.png'),
      (Join-Path $ScriptDir 'assets\norcom-wordmark-full.png'),
      (Join-Path $ScriptDir 'norcom-wordmark-full.png')
    )) { if (Test-Path -LiteralPath $cand) { $wm = $cand; break } }
    if ($wm) { try { $pb.Image = [System.Drawing.Image]::FromFile($wm) } catch {} }
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $Message
    $lbl.ForeColor = [System.Drawing.Color]::FromArgb(0, 229, 255)
    $lbl.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
    $lbl.AutoSize = $false
    $lbl.TextAlign = 'MiddleCenter'
    $lbl.Size = New-Object System.Drawing.Size 420, 24
    $lbl.Location = New-Object System.Drawing.Point 20, 126
    $lbl.BackColor = [System.Drawing.Color]::Transparent
    # Loading bar under wordmark (tall + neon so city-glow shots read clearly)
    $barHost = New-Object System.Windows.Forms.Panel
    $barHost.Size = New-Object System.Drawing.Size 340, 18
    $barHost.Location = New-Object System.Drawing.Point 60, 168
    $barHost.BackColor = [System.Drawing.Color]::FromArgb(255, 12, 24, 48)
    $barBorder = New-Object System.Windows.Forms.Panel
    $barBorder.Size = New-Object System.Drawing.Size 340, 18
    $barBorder.Location = New-Object System.Drawing.Point 0, 0
    $barBorder.BackColor = [System.Drawing.Color]::FromArgb(255, 0, 180, 220)
    $barInner = New-Object System.Windows.Forms.Panel
    $barInner.Size = New-Object System.Drawing.Size 336, 14
    $barInner.Location = New-Object System.Drawing.Point 2, 2
    $barInner.BackColor = [System.Drawing.Color]::FromArgb(255, 8, 14, 32)
    $barFill = New-Object System.Windows.Forms.Panel
    $barFill.Size = New-Object System.Drawing.Size 140, 14
    $barFill.Location = New-Object System.Drawing.Point 0, 0
    $barFill.BackColor = [System.Drawing.Color]::FromArgb(255, 0, 229, 255)
    $barInner.Controls.Add($barFill)
    $barHost.Controls.Add($barBorder)
    $barHost.Controls.Add($barInner)
    $barInner.BringToFront()
    $veil.Controls.Add($pb); $veil.Controls.Add($lbl); $veil.Controls.Add($barHost)
    $sp.Tag = @{ fill = $barFill; host = $barInner; tick = 40 }
    $tm = New-Object System.Windows.Forms.Timer
    $tm.Interval = 30
    $tm.Add_Tick({
      try {
        $tag = $sp.Tag
        if (-not $tag) { return }
        $tag.tick = ([int]$tag.tick + 7) % 100
        $w = [Math]::Max(24, [int]($tag.host.Width * (($tag.tick % 100) / 100.0)))
        $tag.fill.Width = $w
      } catch {}
    }.GetNewClosure())
    $sp.Add_FormClosed({ try { $tm.Stop(); $tm.Dispose() } catch {} }.GetNewClosure())
    $tm.Start()
    $sp.Show(); [System.Windows.Forms.Application]::DoEvents()
    return $sp
  } catch { return $null }
}
function Close-NorcomSplash($sp) {
  try { if ($sp) { $sp.Close(); $sp.Dispose() } } catch {}
}

$form = New-Object System.Windows.Forms.Form
$script:Splash = Show-NorcomSplash 'Loading NORCOM launcher...'
try { [NcDark]::Hook($form) } catch {}
$script:MainForm = $form
$form.Text = 'NORCOM'
$form.StartPosition = 'CenterScreen'
$form.BackColor = $Cbg
$form.ForeColor = $Ctext
$form.Font = Get-UiFont 13
$form.MinimumSize = New-Object System.Drawing.Size(1000, 680)  # 1.0.30u: never shrink below readable Actions/Pack
# Default compact window; restore last size if reasonable
$defW = 1100; $defH = 720
try {
  $ws = Get-NorcomSettings
  if ($ws.windowW -ge 1000 -and $ws.windowW -le 2400) { $defW = [int]$ws.windowW }
  if ($ws.windowH -ge 680 -and $ws.windowH -le 1600) { $defH = [int]$ws.windowH }
} catch {}
$form.ClientSize = New-Object System.Drawing.Size($defW, $defH)
$form.MaximizeBox = $true
$form.MinimizeBox = $true
$form.ShowInTaskbar = $true
$form.WindowState = 'Normal'
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
$form.AutoScroll = $false
if (Test-Path $IconPath) { try { $form.Icon = New-Object System.Drawing.Icon($IconPath) } catch {} }
try {
  $prop = $form.GetType().GetProperty('DoubleBuffered',[Reflection.BindingFlags]'Instance,NonPublic')
  if ($prop) { $prop.SetValue($form, $true, $null) }
} catch {}
# 1.0.33z: Opacity=0 until first full painted frame (kills white client flash under splash)
try { $form.Opacity = 0 } catch {}
try { $form.SuspendLayout() } catch {}
try { Enable-NorcomSmoothPaint $form } catch {}
try {
  $form.Add_HandleCreated({
    try { Enable-NorcomComposited $form } catch {}
    try { Enable-NorcomSmoothPaint $form } catch {}
    try { if ($script:RootPanel) { Enable-NorcomSmoothPaint $script:RootPanel } } catch {}
    # Handle exists now — hold redraw for real (pre-Run call was a no-op)
    try { Set-NorcomRedraw $form $false } catch {}
    try { Write-NcStartupLog 'clean-startup: HandleCreated composited + SETREDRAW hold' } catch {}
  })
} catch {}
$script:NcRevealDone = $false


# Animated city background (toggleable; pauses when minimized / Minecraft running)
$script:AnimBgEnabled = $true
try { $sAnim = Get-NorcomSettings; if ($null -ne $sAnim.animatedBackground) { $script:AnimBgEnabled = [bool]$sAnim.animatedBackground } } catch {}
$script:UseAnimBg = $false
try { if ($script:HasNorcomUi -and ('NorcomUi.AnimatedCityBg' -as [type])) { $script:UseAnimBg = $true } } catch {}
$script:BgImage = $null
if ((Test-Path $BgPath)) {
  try { $script:BgImage = [System.Drawing.Image]::FromFile($BgPath) } catch {}
}

if ($script:UseAnimBg) {
  $root = New-Object NorcomUi.AnimatedCityBg
  try { if ($script:BgImage) { $root.SetBaseImage($script:BgImage) } } catch {}
  try { $root.AnimEnabled = [bool]$script:AnimBgEnabled } catch {}
} else {
  $root = New-Object System.Windows.Forms.Panel
}
$script:RootPanel = $root
$root.Dock = 'Fill'
$root.BackColor = $Cbg
try {
  $rp = $root.GetType().GetProperty('DoubleBuffered',[Reflection.BindingFlags]'Instance,NonPublic')
  if ($rp) { $rp.SetValue($root, $true, $null) }
} catch {}
try { Enable-NorcomSmoothPaint $root } catch {}
if (-not $script:UseAnimBg) { $root.Add_Paint({
  param($s, $e)
  try {
    $e.Graphics.Clear($Cbg)
    $e.Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $e.Graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $e.Graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    if ($script:BgImage) {
      $cw = $s.ClientSize.Width; $ch = $s.ClientSize.Height
      if ($cw -lt 1) { $cw = 1 }; if ($ch -lt 1) { $ch = 1 }
      $iw = $script:BgImage.Width; $ih = $script:BgImage.Height
      $scale = [Math]::Max($cw / [double]$iw, $ch / [double]$ih)
      $dw = [int]($iw * $scale); $dh = [int]($ih * $scale)
      $dx = [int](($cw - $dw) / 2); $dy = [int](($ch - $dh) / 2)
      $e.Graphics.DrawImage($script:BgImage, $dx, $dy, $dw, $dh)
    }
    # dark glass wash so cards stay readable
    $ov = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(120, 4, 8, 22))
    $e.Graphics.FillRectangle($ov, 0, 0, $s.Width, $s.Height)
    $ov.Dispose()
    # neon cyanÃ¢â€ â€™pink window frame
    $w = $s.ClientSize.Width; $h = $s.ClientSize.Height
    if ($w -gt 8 -and $h -gt 8) {
      $rect = New-Object System.Drawing.Rectangle 2, 2, ($w - 5), ($h - 5)
      $path = New-Object System.Drawing.Drawing2D.GraphicsPath
      $rad = 18; $d = $rad * 2
      $path.AddArc($rect.X, $rect.Y, $d, $d, 180, 90)
      $path.AddArc($rect.Right - $d, $rect.Y, $d, $d, 270, 90)
      $path.AddArc($rect.Right - $d, $rect.Bottom - $d, $d, $d, 0, 90)
      $path.AddArc($rect.X, $rect.Bottom - $d, $d, $d, 90, 90)
      $path.CloseFigure()
      try {
        $lb = New-Object System.Drawing.Drawing2D.LinearGradientBrush $rect, $Ccyan, $Cpink, 0.0
        $penGlow = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(70, $Ccyan), 6.0)
        $e.Graphics.DrawPath($penGlow, $path)
        $penGlow.Dispose()
        $pen = New-Object System.Drawing.Pen $lb, 2.2
        $e.Graphics.DrawPath($pen, $path)
        $pen.Dispose(); $lb.Dispose()
      } catch {}
      $path.Dispose()
    }
  } catch {}
}) }
$form.Controls.Add($root)

# 1.0.30m: no TableLayoutPanel (opaque cells = dark PLAY strip). Dock hero/cards/footer on AnimatedCityBg.
$layout = $null  # kept name for resize hooks that set RowStyles[0]
$script:NcHeroHeight = 190
$script:RootPadding = New-Object System.Windows.Forms.Padding 18, 8, 18, 6
$root.Padding = $script:RootPadding

# Hero: large centered brand + Play + subtle status under Play
$hero = if ($script:HasNorcomUi) { New-Object NorcomUi.TransparentPanel } else { New-Object System.Windows.Forms.Panel }
$script:HeroPanel = $hero
$hero.Dock = 'Top'
$hero.Height = 190
$hero.BackColor = [System.Drawing.Color]::Transparent  # 1.0.30m: docked on city bg

$script:HeroLogo = New-Object System.Windows.Forms.PictureBox
$script:HeroLogo.Size = New-Object System.Drawing.Size 56,56
$script:HeroLogo.SizeMode = 'Zoom'
$script:HeroLogo.BackColor = [System.Drawing.Color]::Transparent
try {
  $logoSrc = $null
  if (Test-Path -LiteralPath $LogoNPath) { $logoSrc = $LogoNPath }
  elseif (Test-Path -LiteralPath (Join-Path $Assets 'norcom-icon.png')) { $logoSrc = Join-Path $Assets 'norcom-icon.png' }
  if ($logoSrc) {
    $img = [System.Drawing.Image]::FromFile($logoSrc)
    $bmp = New-Object System.Drawing.Bitmap 72,72
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.Clear([System.Drawing.Color]::FromArgb(0,0,0,0))
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.DrawImage($img, 4, 4, 64, 64); $g.Dispose(); $img.Dispose()
    $script:HeroLogo.Image = $bmp
  }
} catch {}
$script:HeroWordmark = New-Object System.Windows.Forms.PictureBox
$script:HeroWordmark.Size = New-Object System.Drawing.Size 280,56
$script:HeroWordmark.SizeMode = 'Zoom'
$script:HeroWordmark.BackColor = [System.Drawing.Color]::Transparent
$script:HeroWordmark.Visible = $false
if (Test-Path -LiteralPath $WordmarkPath) {
  try { $script:HeroWordmark.Image = [System.Drawing.Image]::FromFile($WordmarkPath); $script:HeroWordmark.Visible = $true } catch {}
}
if ($script:HasNorcomUi) {
  try { $script:HeroTitle = New-Object NorcomUi.GlassLabel } catch { $script:HeroTitle = New-Object System.Windows.Forms.Label }
} else {
  $script:HeroTitle = New-Object System.Windows.Forms.Label
}
$script:HeroTitle.Text = 'NORCOM'
$script:HeroTitle.Font = Get-DisplayFont 28 ([System.Drawing.FontStyle]::Bold)
$script:HeroTitle.ForeColor = $Ccyan
$script:HeroTitle.BackColor = [System.Drawing.Color]::Transparent
$script:HeroTitle.AutoSize = $false
$script:HeroTitle.UseMnemonic = $false
try { $script:HeroTitle.TextAlign = 'MiddleCenter' } catch {}
if ($script:HeroWordmark.Visible) { $script:HeroTitle.Visible = $false; if ($script:HeroLogo) { $script:HeroLogo.Visible = $false }; if ($script:HeroUnderline) { $script:HeroUnderline.Visible = $false } }
$script:HeroSub = New-Object System.Windows.Forms.Label  # 1.0.30i: plain Label â€” GlassLabel painted Theme.Bg dark strip under PLAY
$script:HeroSub.Text = 'Friends launcher - Fabric 26.3'
$script:HeroSub.Font = Get-UiFont 12
$script:HeroSub.ForeColor = $Cdim
$script:HeroSub.BackColor = [System.Drawing.Color]::Transparent
$script:HeroSub.UseMnemonic = $false
try { $script:HeroSub.TextAlign = 'MiddleCenter' } catch {}

$script:BtnPrimary = New-SimplePill -text 'PLAY' `
  -size (New-Object System.Drawing.Size(440, 72)) `
  -loc (New-Object System.Drawing.Point 0, 90) `
  -back $Ccyan -fore ([System.Drawing.Color]::White) `
  -hover ([System.Drawing.Color]::FromArgb(255, 45, 180)) -fontSize 24
if ($script:HasNorcomUi -and $script:BtnPrimary -is [NorcomUi.RoundedButton]) {
  $script:BtnPrimary.CornerRadius = 26
  $script:BtnPrimary.UseGoldGradient = $true
  $script:BtnPrimary.DrawShadow = $false  # 1.0.30h: no dark rect under PLAY on transparent hero
  $script:BtnPrimary.BorderColor = [System.Drawing.Color]::FromArgb(200, $Cpink)
  try { $script:BtnPrimary.LeadingIcon = [NorcomUi.StatusIconKind]::Play } catch {}
}

$script:StatusLabel = New-Object System.Windows.Forms.Label  # 1.0.30i: plain Label â€” GlassLabel painted Theme.Bg dark strip under PLAY
$script:StatusLabel.Text = 'Ready when you are'
$script:StatusLabel.AutoSize = $true
$script:StatusLabel.Font = Get-UiFont 12
$script:StatusLabel.ForeColor = $Cdim
$script:StatusLabel.BackColor = [System.Drawing.Color]::Transparent
$script:StatusLabel.TextAlign = 'MiddleCenter'
$script:StatusLabel.UseMnemonic = $false
try { $script:StatusLabel.FlatStyle = 'Standard' } catch {}

if ($script:HasNorcomUi) {
  $script:Progress = New-Object NorcomUi.RoundedProgress
} else {
  $script:Progress = New-Object System.Windows.Forms.ProgressBar
  $script:Progress.Style = 'Continuous'
}
$script:Progress.Size = New-Object System.Drawing.Size 480, 10
$script:Progress.Visible = $false

$hero.Controls.Add($script:HeroLogo)
$hero.Controls.Add($script:HeroWordmark)
$hero.Controls.Add($script:HeroTitle)
$script:HeroUnderline = New-Object System.Windows.Forms.Panel
$script:HeroUnderline.Height = 3
$script:HeroUnderline.Width = 160
$script:HeroUnderline.BackColor = $Cpink
try {
  $script:HeroUnderline.Add_Paint({
    param($s,$e)
    $r = $s.ClientRectangle
    $lb = New-Object System.Drawing.Drawing2D.LinearGradientBrush $r, $Ccyan, $Cpink, 0.0
    $e.Graphics.FillRectangle($lb, $r); $lb.Dispose()
  })
} catch {}
$hero.Controls.Add($script:HeroUnderline)
if ($script:HeroWordmark -and $script:HeroWordmark.Visible) { $script:HeroUnderline.Visible = $false }
$hero.Controls.Add($script:HeroSub)
$hero.Controls.Add($script:BtnPrimary)
$hero.Controls.Add($script:StatusLabel)
$hero.Controls.Add($script:Progress)
$hero.Add_Resize({ Update-LauncherHeroLayout })
# 1.0.30o: defer $root.Controls.Add($hero) until after cards/footer (dock z-order)

# Cards scroll
$script:CardsScroll = if ($script:HasNorcomUi) { New-Object NorcomUi.TransparentPanel } else { New-Object System.Windows.Forms.Panel }
$script:CardsScroll.Dock = 'Fill'
$script:CardsScroll.AutoScroll = $false
$script:CardsScroll.BackColor = [System.Drawing.Color]::Transparent  # 1.0.30o: was $Cbg solid band
# 1.0.30o: defer Add until dock block

$script:CardsFlow = New-Object System.Windows.Forms.TableLayoutPanel
$script:CardsFlow.Left = 0
$script:CardsFlow.Top = 0
$script:CardsFlow.Width = 900
$script:CardsFlow.Height = 800
$script:CardsFlow.AutoSize = $false
$script:CardsFlow.ColumnCount = 3
$script:CardsFlow.RowCount = 2
$script:CardsFlow.BackColor = [System.Drawing.Color]::Transparent  # 1.0.30q: remove mismatched Cbg strip
$script:CardsFlow.Padding = New-Object System.Windows.Forms.Padding 2
$script:CardsFlow.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left
$script:CardsScroll.Controls.Add($script:CardsFlow)

# --- Page host: Home / Character / Settings ---
$script:NavBar = New-Object System.Windows.Forms.Panel
$script:NavBar.Height = 36
$script:NavBar.Dock = 'Top'
$script:NavBar.BackColor = [System.Drawing.Color]::Transparent  # 1.0.30l: no dark strip under PLAY
function New-NorcomNavBtn([string]$text) {
  if ($script:HasNorcomUi) {
    try {
      $b = New-Object NorcomUi.RoundedButton
      $b.Text = $text
      $b.Height = 30
      $b.Width = 118
      $b.CornerRadius = 15
      $b.BorderColor = [System.Drawing.Color]::FromArgb(140, $Ccyan)
      $b.BackColor = [System.Drawing.Color]::FromArgb(50, 8, 16, 36)
      $b.ForeColor = $Ctext
      $b.Font = Get-UiFont 11 ([System.Drawing.FontStyle]::Bold)
      $b.Cursor = [System.Windows.Forms.Cursors]::Hand
      $b.Margin = New-Object System.Windows.Forms.Padding 4, 3, 4, 3
      return $b
    } catch {}
  }
  $b = New-Object System.Windows.Forms.Button
  $b.Text = $text
  $b.FlatStyle = 'Flat'
  $b.FlatAppearance.BorderSize = 1
  $b.FlatAppearance.BorderColor = $Ccyan
  $b.Height = 30
  $b.Width = 118
  $b.Margin = New-Object System.Windows.Forms.Padding 4, 3, 4, 3
  $b.Font = Get-UiFont 11 ([System.Drawing.FontStyle]::Bold)
  $b.ForeColor = $Ctext
  $b.BackColor = [System.Drawing.Color]::FromArgb(40, 8, 16, 36)
  $b.Cursor = [System.Windows.Forms.Cursors]::Hand
  return $b
}
$script:NavHome = New-NorcomNavBtn 'Home'
$script:NavCharacter = New-NorcomNavBtn 'Character'
$script:NavSettings = New-NorcomNavBtn 'Settings'
$script:NavHome.Location = New-Object System.Drawing.Point 8, 3
$script:NavCharacter.Location = New-Object System.Drawing.Point 134, 3
$script:NavSettings.Location = New-Object System.Drawing.Point 260, 3
$script:NavHome.Add_Click({ Show-NorcomPage 'home' })
$script:NavCharacter.Add_Click({ Show-NorcomPage 'character' })
$script:NavSettings.Add_Click({ Show-NorcomPage 'settings' })
$script:NavBar.Controls.Add($script:NavHome)
$script:NavBar.Controls.Add($script:NavCharacter)
$script:NavBar.Controls.Add($script:NavSettings)

$script:PageHost = New-Object System.Windows.Forms.Panel
$script:PageHost.Dock = 'Fill'
$script:PageHost.BackColor = [System.Drawing.Color]::Transparent

$script:PageHome = New-Object System.Windows.Forms.Panel
$script:PageHome.Dock = 'Fill'
$script:PageHome.BackColor = [System.Drawing.Color]::Transparent
$script:PageCharacter = New-Object System.Windows.Forms.Panel
$script:PageCharacter.Dock = 'Fill'
$script:PageCharacter.BackColor = [System.Drawing.Color]::Transparent
$script:PageCharacter.Visible = $false
$script:PageSettings = New-Object System.Windows.Forms.Panel
$script:PageSettings.Dock = 'Fill'
$script:PageSettings.BackColor = [System.Drawing.Color]::Transparent
$script:PageSettings.Visible = $false
$script:PageHost.Controls.Add($script:PageSettings)
$script:PageHost.Controls.Add($script:PageCharacter)
$script:PageHost.Controls.Add($script:PageHome)

# Re-host: CardsScroll -> Nav + PageHost; CardsFlow lives on Home
$script:CardsScroll.Controls.Clear()
$script:CardsScroll.Controls.Add($script:PageHost)
$script:CardsScroll.Controls.Add($script:NavBar)
$script:PageHome.Controls.Add($script:CardsFlow)
$script:CardsFlow.Dock = 'None'
$script:CardsFlow.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left

# --- Server card ---

# --- Character card (3D preview + skin apply) ---
$script:CardCharacter = New-OliveCard 'CHARACTER'
$script:CharacterSlim = $false
$script:CharacterSkinPath = $null
$charInner = New-Object System.Windows.Forms.Panel
$charInner.Name = 'CharInner'
$charInner.Dock = 'Fill'
$charInner.BackColor = [System.Drawing.Color]::Transparent
if ($script:HasNorcomUi -and ('NorcomUi.SkinPreview3D' -as [type])) {
  $script:SkinPreview = New-Object NorcomUi.SkinPreview3D
} else {
  $script:SkinPreview = New-Object System.Windows.Forms.PictureBox
  $script:SkinPreview.SizeMode = 'Zoom'
  $script:SkinPreview.BackColor = [System.Drawing.Color]::FromArgb(10,14,30)
}
$script:SkinPreview.Location = New-Object System.Drawing.Point 8, 4
$script:SkinPreview.Size = New-Object System.Drawing.Size 300, 210
$charInner.Controls.Add($script:SkinPreview)
$script:BtnClassicSlim = New-SimplePill -text 'Classic' -size (New-Object System.Drawing.Size 90,28) -loc (New-Object System.Drawing.Point 8,220) -back ([System.Drawing.Color]::FromArgb(50,0,180,220)) -fore $Ctext -hover $Ccyan -fontSize 11
$script:BtnClassicSlim.Add_Click({
  $script:CharacterSlim = -not $script:CharacterSlim
  $script:BtnClassicSlim.Text = $(if ($script:CharacterSlim) { 'Slim' } else { 'Classic' })
  try { if ($script:SkinPreview -and $script:SkinPreview.GetType().Name -eq 'SkinPreview3D') { $script:SkinPreview.Slim = $script:CharacterSlim } } catch {}
  try { Update-NorcomCreatorPreview } catch {}
})
$charInner.Controls.Add($script:BtnClassicSlim)
$script:BtnUploadSkin = New-SimplePill -text 'Upload skin' -size (New-Object System.Drawing.Size 110,28) -loc (New-Object System.Drawing.Point 104,220) -back ([System.Drawing.Color]::FromArgb(40,8,16,36)) -fore $Ctext -hover $Ccyan -fontSize 11
$script:BtnUploadSkin.Add_Click({
  try {
    if ($script:SelfTest) { $script:Calls.Add('upload-skin'); Set-Status 'Upload skin (dry)'; return }
    $p = Select-NorcomSkinPng
    if ($p) { Import-NorcomCharacterSkin -Path $p | Out-Null }
  } catch { (Show-NcMsg @($_.Exception.Message,'Skin','OK','Error')) | Out-Null }
})
$charInner.Controls.Add($script:BtnUploadSkin)
$script:BtnApplySkin = New-SimplePill -text 'Apply' -size (New-Object System.Drawing.Size 90,28) -loc (New-Object System.Drawing.Point 220,220) -back $Ccyan -fore ([System.Drawing.Color]::White) -hover $Cpink -fontSize 11
$script:BtnApplySkin.Add_Click({
  try {
    if ($script:SelfTest) { $script:Calls.Add('apply-skin'); Set-Status 'Skin applied (dry)'; return }
    if (-not $script:CharacterSkinPath) { (Show-NcMsg @('Upload a skin PNG first.','Skin','OK','Information')) | Out-Null; return }
    $variant = $(if ($script:CharacterSlim) { 'slim' } else { 'classic' })
    $r = Set-McSkin -PngPath $script:CharacterSkinPath -Variant $variant
    if ([int]$r.Status -ge 200 -and [int]$r.Status -lt 300) { Set-Status 'Skin applied to your Minecraft account'; (Show-NcMsg @('Skin applied successfully.','NORCOM Character','OK','Information')) | Out-Null }
    else { $msg = Format-McApiError $r; Set-Status $msg; (Show-NcMsg @($msg,'Skin Apply','OK','Warning')) | Out-Null }
  } catch { (Show-NcMsg @($_.Exception.Message,'Skin Apply','OK','Error')) | Out-Null }
})
$charInner.Controls.Add($script:BtnApplySkin)
$script:CapeCombo = New-Object System.Windows.Forms.ComboBox
$script:CapeCombo.DropDownStyle = 'DropDownList'
$script:CapeCombo.Location = New-Object System.Drawing.Point 8, 254
$script:CapeCombo.Size = New-Object System.Drawing.Size 200, 28
$script:CapeCombo.BackColor = [System.Drawing.Color]::FromArgb(10,14,30)
$script:CapeCombo.ForeColor = $Ctext
[void]$script:CapeCombo.Items.Add('Cape: none')
$script:CapeCombo.SelectedIndex = 0
$charInner.Controls.Add($script:CapeCombo)
$script:BtnBrowseOutfits2 = New-SimplePill -text 'Browse outfits' -size (New-Object System.Drawing.Size 100,28) -loc (New-Object System.Drawing.Point 214,252) -back ([System.Drawing.Color]::FromArgb(40,8,16,36)) -fore $Ctext -hover $Cpink -fontSize 10
$script:BtnBrowseOutfits2.Add_Click({ try { Show-NorcomBrowseOutfitsMenu -anchor $script:BtnBrowseOutfits2 } catch {} })
# 1.0.30x: equal-column TableLayoutPanel for Classic/Upload/Apply/Browse outfits (no clip)
$script:CharBtnTable = New-Object System.Windows.Forms.TableLayoutPanel
$script:CharBtnTable.Name = 'CharBtnTable'
$script:CharBtnTable.ColumnCount = 4
$script:CharBtnTable.RowCount = 1
$script:CharBtnTable.Dock = 'Bottom'
$script:CharBtnTable.Height = 36
$script:CharBtnTable.Padding = New-Object System.Windows.Forms.Padding 2,2,2,4
$script:CharBtnTable.Margin = New-Object System.Windows.Forms.Padding 0
$script:CharBtnTable.BackColor = [System.Drawing.Color]::Transparent
$script:CharBtnTable.ColumnStyles.Clear()
1..4 | ForEach-Object { [void]$script:CharBtnTable.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 25.0))) }
$script:CharBtnTable.RowStyles.Clear()
[void]$script:CharBtnTable.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100.0)))
foreach ($b in @($script:BtnClassicSlim, $script:BtnUploadSkin, $script:BtnApplySkin, $script:BtnBrowseOutfits2)) {
  if (-not $b) { continue }
  try { if ($b.Parent) { $b.Parent.Controls.Remove($b) } } catch {}
}
$col = 0
foreach ($b in @($script:BtnClassicSlim, $script:BtnUploadSkin, $script:BtnApplySkin, $script:BtnBrowseOutfits2)) {
  if (-not $b) { continue }
  $b.Dock = 'Fill'
  $b.Margin = New-Object System.Windows.Forms.Padding 2,1,2,1
  $b.AutoSize = $false
  try { $b.AutoEllipsis = $false } catch {}
  $script:CharBtnTable.Controls.Add($b, $col, 0)
  $col++
}
$charInner.Controls.Add($script:CharBtnTable)
$script:CharCapeHost = New-Object System.Windows.Forms.Panel
$script:CharCapeHost.Name = 'CharCapeHost'
$script:CharCapeHost.Dock = 'Bottom'
$script:CharCapeHost.Height = 28
$script:CharCapeHost.Padding = New-Object System.Windows.Forms.Padding 2,0,2,0
$script:CharCapeHost.BackColor = [System.Drawing.Color]::Transparent
if ($script:CapeCombo) {
  try { if ($script:CapeCombo.Parent) { $script:CapeCombo.Parent.Controls.Remove($script:CapeCombo) } } catch {}
  $script:CapeCombo.Dock = 'Fill'
  $script:CharCapeHost.Controls.Add($script:CapeCombo)
}
$charInner.Controls.Add($script:CharCapeHost)
try { $charInner.Controls.SetChildIndex($script:CharBtnTable, 0) } catch {}
try { $charInner.Controls.SetChildIndex($script:CharCapeHost, 1) } catch {}
$script:SavedSkinsHost = New-Object System.Windows.Forms.FlowLayoutPanel
$script:SavedSkinsHost.Location = New-Object System.Drawing.Point 8, 288
$script:SavedSkinsHost.Size = New-Object System.Drawing.Size 300, 52
$script:SavedSkinsHost.WrapContents = $false
$script:SavedSkinsHost.BackColor = [System.Drawing.Color]::Transparent
$charInner.Controls.Add($script:SavedSkinsHost)
function Update-NorcomSavedSkinThumbs {
  if (-not $script:SavedSkinsHost) { return }
  $script:SavedSkinsHost.Controls.Clear()
  foreach ($f in @(Get-NorcomSavedSkins | Select-Object -First 6)) {
    $pb = New-Object System.Windows.Forms.PictureBox
    $pb.Size = New-Object System.Drawing.Size 44,44
    $pb.SizeMode = 'Zoom'
    $pb.Margin = New-Object System.Windows.Forms.Padding 2
    $pb.Cursor = [System.Windows.Forms.Cursors]::Hand
    try { $pb.Image = [System.Drawing.Image]::FromFile($f.FullName) } catch {}
    $path = $f.FullName
    $pb.Add_Click({ Import-NorcomCharacterSkin -Path $path | Out-Null }.GetNewClosure())
    $script:SavedSkinsHost.Controls.Add($pb)
  }
}
try { Update-NorcomSavedSkinThumbs } catch {}
# Default 3D skin: Mojang profile/username textures, else built-in Steve/Alex
try { Initialize-NorcomCharacterPreview } catch {
  try {
    $def = Get-NorcomDefaultSkinPath
    if ($def) { Import-NorcomCharacterSkin -Path $def | Out-Null }
  } catch {}
}
$script:CardCharacter.Controls.Add($charInner)
$charInner.BringToFront()
$script:CharPreviewCard = $script:CardCharacter
$script:CardCharacter.Add_Resize({ try { if ($script:CurrentPage -eq 'character') { Update-CharacterPageLayout } else { Update-CharacterCardLayout } } catch {} })
try { Start-NorcomDownloadsSkinWatch } catch {}

# Skin creator panel (tone/hair/eyes/clothes/accessories + Randomize)
$script:CharCreatorCard = New-OliveCard 'SKIN CREATOR'
$script:CreatorHost = New-Object System.Windows.Forms.Panel
$script:CreatorHost.Name = 'CreatorHost'
$script:CreatorHost.Dock = 'Fill'
$script:CreatorHost.AutoScroll = $true
$script:CreatorHost.BackColor = [System.Drawing.Color]::FromArgb(12, 18, 40)
$script:CreatorHost.Padding = New-Object System.Windows.Forms.Padding 4
function Add-CreatorColorRow([string]$label, [scriptblock]$onPick, [int]$y) {
  $row = New-Object System.Windows.Forms.Panel
  $row.Height = 34
  $row.Width = 320
  $row.Location = New-Object System.Drawing.Point 4, $y
  $row.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
  $lb = New-Object System.Windows.Forms.Label
  $lb.Text = $label
  $lb.Font = Get-UiFont 11 ([System.Drawing.FontStyle]::Bold)
  $lb.ForeColor = $Ctext
  $lb.AutoSize = $false
  $lb.Size = New-Object System.Drawing.Size 96, 24
  $lb.Location = New-Object System.Drawing.Point 2, 5
  $lb.TextAlign = 'MiddleLeft'
  $row.Controls.Add($lb)
  $pal = @(
    [System.Drawing.Color]::FromArgb(255,220,180,150),
    [System.Drawing.Color]::FromArgb(255,200,150,120),
    [System.Drawing.Color]::FromArgb(255,141,85,36),
    [System.Drawing.Color]::FromArgb(255,90,50,30),
    [System.Drawing.Color]::FromArgb(255,40,40,40),
    [System.Drawing.Color]::FromArgb(255,0,170,170),
    [System.Drawing.Color]::FromArgb(255,50,50,180),
    [System.Drawing.Color]::FromArgb(255,220,40,80)
  )
  $x = 102
  foreach ($col in $pal) {
    $sw = New-Object System.Windows.Forms.Panel
    $sw.Size = New-Object System.Drawing.Size 18, 18
    $sw.Location = New-Object System.Drawing.Point $x, 7
    $sw.BackColor = $col
    $sw.Cursor = [System.Windows.Forms.Cursors]::Hand
    $cCopy = $col
    $sw.Add_Click({ & $onPick $cCopy }.GetNewClosure())
    $row.Controls.Add($sw)
    $x += 22
  }
  $custom = New-SimplePill -text '...' -size (New-Object System.Drawing.Size 32, 22) -loc (New-Object System.Drawing.Point $x, 5) -back ([System.Drawing.Color]::FromArgb(50,8,16,36)) -fore $Ctext -hover $Ccyan -fontSize 10
  $custom.Add_Click({
    try {
      $dlg = New-Object System.Windows.Forms.ColorDialog
      $dlg.FullOpen = $true
      if ($dlg.ShowDialog() -eq 'OK') { & $onPick $dlg.Color }
    } catch {}
  }.GetNewClosure())
  $row.Controls.Add($custom)
  $script:CreatorHost.Controls.Add($row)
  return ($y + 36)
}
function Add-CreatorStyleRow([string]$label, [string[]]$options, [scriptblock]$onPick, [int]$y, [string]$current) {
  $row = New-Object System.Windows.Forms.Panel
  $row.Height = 56
  $row.Width = 320
  $row.Location = New-Object System.Drawing.Point 4, $y
  $row.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
  $lb = New-Object System.Windows.Forms.Label
  $lb.Text = $label
  $lb.Font = Get-UiFont 11 ([System.Drawing.FontStyle]::Bold)
  $lb.ForeColor = $Ccyan
  $lb.AutoSize = $false
  $lb.Size = New-Object System.Drawing.Size 96, 20
  $lb.Location = New-Object System.Drawing.Point 2, 2
  $lb.TextAlign = 'MiddleLeft'
  $row.Controls.Add($lb)
  $x = 2
  foreach ($opt in $options) {
    $isOn = ($opt -eq $current)
    # 1.0.30v: equal-fit style pills (measure text; never show moh...)
    $pillFont = Get-UiFont 9 ([System.Drawing.FontStyle]::Bold)
    $tw = 58
    try { $tw = [Math]::Max(58, [System.Windows.Forms.TextRenderer]::MeasureText($opt, $pillFont).Width + 18) } catch { $tw = [Math]::Max(58, 16 + 9*$opt.Length) }
    $b = New-SimplePill -text $opt -size (New-Object System.Drawing.Size $tw, 26) -loc (New-Object System.Drawing.Point $x, 24) -back ($(if ($isOn) { [System.Drawing.Color]::FromArgb(160,0,180,220) } else { [System.Drawing.Color]::FromArgb(40,8,16,36) })) -fore ([System.Drawing.Color]::White) -hover $Ccyan -fontSize 9
    try { $b.AutoEllipsis = $false } catch {}
    $oCopy = $opt
    $b.Add_Click({
      & $onPick $oCopy
      try { Update-NorcomCreatorPreview } catch {}
      try { if ($script:CurrentPage -eq 'character') { Update-CharacterPageLayout } } catch {}
    }.GetNewClosure())
    $row.Controls.Add($b)
    $x += $b.Width + 4
  }
  $script:CreatorHost.Controls.Add($row)
  return ($y + 60)
}
$script:BtnRandomizeSkin = New-SimplePill -text 'Randomize' -size (New-Object System.Drawing.Size 110,28) -loc (New-Object System.Drawing.Point 4,4) -back $Cpink -fore ([System.Drawing.Color]::White) -hover $Ccyan -fontSize 11
$script:BtnRandomizeSkin.Add_Click({ try { Invoke-NorcomCreatorRandomize } catch {} })
$script:CreatorHost.Controls.Add($script:BtnRandomizeSkin)
$script:BtnSaveCreatorSkin = New-SimplePill -text 'Save to library' -size (New-Object System.Drawing.Size 186,34) -loc (New-Object System.Drawing.Point 120,4) -back $Ccyan -fore ([System.Drawing.Color]::White) -hover $Cpink -fontSize 11
$script:BtnSaveCreatorSkin.Add_Click({
  try {
    if ($script:SelfTest) { $script:Calls.Add('save-creator'); Set-Status 'Saved (dry)'; return }
    Save-NorcomCreatorToLibrary | Out-Null
    try { Update-NorcomSavedSkinThumbs } catch {}
    try { Update-CreatorLibraryStrip } catch {}
  } catch { (Show-NcMsg @($_.Exception.Message,'Save skin','OK','Error')) | Out-Null }
})
$script:CreatorHost.Controls.Add($script:BtnSaveCreatorSkin)
$cy = 38
$cy = Add-CreatorColorRow 'Tone' { param($c) $script:CreatorTone = $c; Update-NorcomCreatorPreview } $cy
$cy = Add-CreatorStyleRow 'Hair style' @('short','buzz','long','mohawk') { param($v) $script:CreatorHairStyle = $v } $cy $(if ($script:CreatorHairStyle) { $script:CreatorHairStyle } else { 'short' })
$cy = Add-CreatorColorRow 'Hair color' { param($c) $script:CreatorHair = $c; Update-NorcomCreatorPreview } $cy
$cy = Add-CreatorStyleRow 'Eye style' @('dot','wide','happy','glow') { param($v) $script:CreatorEyeStyle = $v } $cy $(if ($script:CreatorEyeStyle) { $script:CreatorEyeStyle } else { 'dot' })
$cy = Add-CreatorColorRow 'Eye color' { param($c) $script:CreatorEyes = $c; Update-NorcomCreatorPreview } $cy
$cy = Add-CreatorStyleRow 'Shirt style' @('tee','hoodie','jacket') { param($v) $script:CreatorShirtStyle = $v } $cy $(if ($script:CreatorShirtStyle) { $script:CreatorShirtStyle } else { 'tee' })
$cy = Add-CreatorColorRow 'Shirt color' { param($c) $script:CreatorShirt = $c; Update-NorcomCreatorPreview } $cy
$cy = Add-CreatorStyleRow 'Pants style' @('pants','shorts') { param($v) $script:CreatorPantsStyle = $v } $cy $(if ($script:CreatorPantsStyle) { $script:CreatorPantsStyle } else { 'pants' })
$cy = Add-CreatorColorRow 'Pants color' { param($c) $script:CreatorPants = $c; Update-NorcomCreatorPreview } $cy
$cy = Add-CreatorStyleRow 'Shoes' @('sneakers','boots') { param($v) $script:CreatorShoeStyle = $v } $cy $(if ($script:CreatorShoeStyle) { $script:CreatorShoeStyle } else { 'sneakers' })
$cy = Add-CreatorStyleRow 'Accessories' @('none','cap','visor','headphones','neon') { param($v) $script:CreatorAccessory = $v } $cy $(if ($script:CreatorAccessory) { $script:CreatorAccessory } else { 'none' })
$cy = Add-CreatorColorRow 'Trim color' { param($c) $script:CreatorAccent = $c; Update-NorcomCreatorPreview } $cy
$script:CreatorLibStrip = New-Object System.Windows.Forms.FlowLayoutPanel
$script:CreatorLibStrip.Location = New-Object System.Drawing.Point 4, $cy
$script:CreatorLibStrip.Size = New-Object System.Drawing.Size 300, 52
$script:CreatorLibStrip.WrapContents = $false
$script:CreatorLibStrip.BackColor = [System.Drawing.Color]::Transparent
$script:CreatorHost.Controls.Add($script:CreatorLibStrip)
function Update-CreatorLibraryStrip {
  if (-not $script:CreatorLibStrip) { return }
  $script:CreatorLibStrip.Controls.Clear()
  $hl = New-Object System.Windows.Forms.Label
  $hl.Text = 'Library'
  $hl.Font = Get-UiFont 10 ([System.Drawing.FontStyle]::Bold)
  $hl.ForeColor = $Cdim
  $hl.AutoSize = $true
  $hl.Margin = New-Object System.Windows.Forms.Padding 0, 14, 6, 0
  $script:CreatorLibStrip.Controls.Add($hl)
  foreach ($f in @(Get-NorcomSavedSkins | Select-Object -First 8)) {
    $pb = New-Object System.Windows.Forms.PictureBox
    $pb.Size = New-Object System.Drawing.Size 40,40
    $pb.SizeMode = 'Zoom'
    $pb.Margin = New-Object System.Windows.Forms.Padding 2
    $pb.Cursor = [System.Windows.Forms.Cursors]::Hand
    try { $pb.Image = [System.Drawing.Image]::FromFile($f.FullName) } catch {}
    $path = $f.FullName
    $pb.Add_Click({ Import-NorcomCharacterSkin -Path $path | Out-Null }.GetNewClosure())
    $script:CreatorLibStrip.Controls.Add($pb)
  }
}
try { Update-CreatorLibraryStrip } catch {}
$cy += 56
try { $script:CreatorHost.AutoScrollMinSize = New-Object System.Drawing.Size 0, ($cy + 12) } catch {}
$script:CharCreatorCard.Controls.Add($script:CreatorHost)
# Do not auto-apply creator preview on boot Ã¢â‚¬â€ keep Mojang/default skin until user edits

$script:CardServer = New-OliveCard 'SERVER'
$script:ServerDot = New-Object System.Windows.Forms.Panel
$script:ServerDot.Size = New-Object System.Drawing.Size 16,16
$script:ServerDot.Location = New-Object System.Drawing.Point 16, 44
$script:ServerDot.BackColor = $Cdim
$script:ServerStatusLabel = New-Object System.Windows.Forms.Label
$script:ServerStatusLabel.Location = New-Object System.Drawing.Point 40, 40
$script:ServerStatusLabel.Size = New-Object System.Drawing.Size 200, 26
$script:ServerStatusLabel.Font = Get-UiFont 14 ([System.Drawing.FontStyle]::Bold)
$script:ServerStatusLabel.ForeColor = $Ctext
$script:ServerStatusLabel.BackColor = [System.Drawing.Color]::Transparent
$script:ServerStatusLabel.Text = 'Checking...'
$script:ServerStatusLabel.UseMnemonic = $false
$script:PingChip = New-Object System.Windows.Forms.Label
$script:PingChip.Location = New-Object System.Drawing.Point 240, 40
$script:PingChip.Size = New-Object System.Drawing.Size 90, 26
$script:PingChip.Font = Get-UiFont 11 ([System.Drawing.FontStyle]::Bold)
$script:PingChip.ForeColor = [System.Drawing.Color]::FromArgb(6,10,28)
$script:PingChip.BackColor = $Cdim
$script:PingChip.TextAlign = 'MiddleCenter'
$script:PingChip.Text = '-- ms'
$script:PingChip.UseMnemonic = $false
$script:PingChip.Padding = New-Object System.Windows.Forms.Padding 0
function Update-PingChipSize {
  $c = $script:PingChip; if (-not $c -or -not $script:CardServer) { return }
  $sz = [System.Windows.Forms.TextRenderer]::MeasureText([string]$c.Text, $c.Font, (New-Object System.Drawing.Size 1000,100), [System.Windows.Forms.TextFormatFlags]::NoPadding)
  $h = [Math]::Max(24, $sz.Height + 10); $w = [Math]::Max(60, $sz.Width + 26)
  $c.Size = New-Object System.Drawing.Size $w, $h
  $card = $script:CardServer
  $ttlH = 32; foreach ($x in $card.Controls) { if ($x.Name -eq 'CardTitle') { $ttlH = $x.Height } }
  $c.Left = [Math]::Max(120, $card.ClientSize.Width - $card.Padding.Right - $w - 4)
  $c.Top = $card.Padding.Top + [int](($ttlH - $h) / 2)
  $c.BringToFront()
  try { Set-BubbleRound $c ([int]($h / 2)) } catch {}
}
$script:ServerPlayersLabel = New-Object System.Windows.Forms.Label
$script:ServerPlayersLabel.Location = New-Object System.Drawing.Point 16, 72
$script:ServerPlayersLabel.Size = New-Object System.Drawing.Size 300, 22
$script:ServerPlayersLabel.Font = Get-UiFont 13
$script:ServerPlayersLabel.ForeColor = $Cdim
$script:ServerPlayersLabel.BackColor = [System.Drawing.Color]::Transparent
$script:ServerPlayersLabel.Text = 'Players: -'
$script:ServerPlayersLabel.UseMnemonic = $false
$script:ServerNamesLabel = New-Object System.Windows.Forms.Label
$script:ServerNamesLabel.Location = New-Object System.Drawing.Point 16, 96
$script:ServerNamesLabel.Size = New-Object System.Drawing.Size 300, 48
$script:ServerNamesLabel.Font = Get-UiFont 12
$script:ServerNamesLabel.ForeColor = $Ctext
$script:ServerNamesLabel.BackColor = [System.Drawing.Color]::Transparent
$script:ServerNamesLabel.Text = ''
$script:ServerNamesLabel.UseMnemonic = $false
$script:PlayerHeadsHost = New-Object System.Windows.Forms.FlowLayoutPanel
$script:PlayerHeadsHost.Name = 'PlayerHeadsHost'
$script:PlayerHeadsHost.Location = New-Object System.Drawing.Point 16, 118
$script:PlayerHeadsHost.Size = New-Object System.Drawing.Size 300, 36
$script:PlayerHeadsHost.WrapContents = $false
$script:PlayerHeadsHost.BackColor = [System.Drawing.Color]::Transparent
$script:PlayerHeadsHost.Padding = New-Object System.Windows.Forms.Padding 0
$script:LastPlayedLabel = New-Object System.Windows.Forms.Label
$script:LastPlayedLabel.Name = 'LastPlayedLabel'
$script:LastPlayedLabel.Location = New-Object System.Drawing.Point 16, 156
$script:LastPlayedLabel.Size = New-Object System.Drawing.Size 300, 18
$script:LastPlayedLabel.Font = Get-UiFont 11
$script:LastPlayedLabel.ForeColor = $Cdim
$script:LastPlayedLabel.BackColor = [System.Drawing.Color]::Transparent
$script:LastPlayedLabel.Text = 'World: NORCOM'
$script:LastPlayedLabel.UseMnemonic = $false
try {
  $stLp = Load-State
  if ($stLp.lastPlayUtc) {
    $dt = [datetime]$stLp.lastPlayUtc
    $script:LastPlayedLabel.Text = ('Last played: {0:MMM d h:mm tt}  |  World: NORCOM' -f $dt.ToLocalTime())
  } elseif ($stLp.lastPlay) {
    $script:LastPlayedLabel.Text = ('Last played: {0}  |  World: NORCOM' -f $stLp.lastPlay)
  }
} catch {}
$script:ServerAddrLabel = New-Object System.Windows.Forms.Label
$script:ServerAddrLabel.Location = New-Object System.Drawing.Point 16, 124
$script:ServerAddrLabel.Size = New-Object System.Drawing.Size 210, 22
$script:ServerAddrLabel.Font = Get-UiFont 12
$script:ServerAddrLabel.ForeColor = $Ctan
$script:ServerAddrLabel.BackColor = [System.Drawing.Color]::Transparent
$script:ServerAddrLabel.Text = 'shrimp-cub.tun.ply.gg'
$script:ServerAddrLabel.UseMnemonic = $false
$script:BtnCopyAddr = New-SimplePill -text 'Copy' -size (New-Object System.Drawing.Size 86,28) -loc (New-Object System.Drawing.Point 230,120) -back ([System.Drawing.Color]::FromArgb(50, 0, 180, 220)) -fore $Ctext -hover $Ccyan -fontSize 11
$script:BtnCopyAddr.Anchor = 'Top,Right'
$script:BtnCopyAddr.Add_Click({
  try {
    # 1.0.30h: Copy must read address from ServerAddrLabel
    $addr = [string]$script:ServerAddrLabel.Text
    if (-not $addr) { $addr = 'shrimp-cub.tun.ply.gg' }
    $script:LastCopiedAddr = $addr
    try { [System.Windows.Forms.Clipboard]::SetDataObject($addr, $true) } catch {
      try { [System.Windows.Forms.Clipboard]::SetText($addr) } catch {}
    }
    Set-Status 'Address copied'
  } catch { Set-Status 'Copy failed' }
})
$script:CardServer.Controls.Add($script:ServerDot)
$script:CardServer.Controls.Add($script:ServerStatusLabel)
$script:CardServer.Controls.Add($script:PingChip)
$script:CardServer.Controls.Add($script:ServerPlayersLabel)
$script:CardServer.Controls.Add($script:ServerNamesLabel)
$script:CardServer.Controls.Add($script:PlayerHeadsHost)
$script:CardServer.Controls.Add($script:LastPlayedLabel)
$script:CardServer.Controls.Add($script:ServerAddrLabel)
$script:CardServer.Controls.Add($script:BtnCopyAddr)
$script:CardServer.Add_Resize({
  try { Fit-ServerCard } catch {}
  Fit-NcCardLabels $script:CardServer
})

# --- News card --- (1.0.30w: Label whole-line preview + Read more modal)
$script:CardNews = New-OliveCard 'NEWS'
$script:CardNews.Name = 'CardNews'
$script:NewsBox = New-NcMdPreviewLabel
$script:NewsMd = $true
$newsBody = (Read-PackMarkdown 'news.md')
$newsBody = $newsBody -replace '\A\s*#{1,3}[^\r\n]*[Nn]ews[^\r\n]*\r?\n',''
$newsBody = $newsBody.TrimStart()
$newsBody = $newsBody -replace '%APPDATA%\\?\.norcom','your NORCOM folder' -replace '%APPDATA%','your Minecraft folder'
$script:NewsFullMd = $newsBody
$script:CardNews.Controls.Add($script:NewsBox)
Set-NcMdPreview $script:CardNews $script:NewsBox $newsBody
$script:CardNews.Add_Resize({ try { Fit-NcMarkdownBox $script:CardNews } catch {} })

# --- Rules card --- (1.0.30w: Label whole-line preview + Read more modal)
$script:CardRules = New-OliveCard 'RULES'
$script:CardRules.Name = 'CardRules'
$script:RulesBox = New-NcMdPreviewLabel
$rulesBody = (Read-PackMarkdown 'rules.md')
$rulesBody = $rulesBody -replace '\A\s*#{1,3}[^\r\n]*[Rr]ules[^\r\n]*\r?\n',''
$rulesBody = $rulesBody.TrimStart()
$rulesBody = $rulesBody -replace '%APPDATA%\\?\.norcom','your NORCOM folder' -replace '%APPDATA%','your Minecraft folder'
$script:RulesFullMd = $rulesBody
$script:CardRules.Controls.Add($script:RulesBox)
Set-NcMdPreview $script:CardRules $script:RulesBox $rulesBody
$script:CardRules.Add_Resize({ try { Fit-NcMarkdownBox $script:CardRules } catch {} })

# --- Quick Links ---
$script:CardLinks = New-OliveCard 'ACTIONS'
$linksHost = New-Object System.Windows.Forms.Panel  # 1.0.30v: Panel+manual grid (TLP overrides Location)
$linksHost.Dock = 'None'
$linksHost.AutoScroll = $false
$linksHost.BackColor = [System.Drawing.Color]::Transparent
$linksHost.Padding = New-Object System.Windows.Forms.Padding 6, 4, 6, 14
function New-LinkBtn([string]$text, [string]$iconKind) {
  $b = New-SimplePill -text $text -size (New-Object System.Drawing.Size 140,32) -loc (New-Object System.Drawing.Point 0,0) -back ([System.Drawing.Color]::FromArgb(40, 8, 16, 36)) -fore $Ctext -hover ([System.Drawing.Color]::FromArgb(60, 0, 200, 230)) -fontSize 13
  $b.Margin = New-Object System.Windows.Forms.Padding 4, 5, 4, 5
  if ($script:HasNorcomUi -and $b -is [NorcomUi.RoundedButton]) {
    try {
      $b.LeadingIcon = [NorcomUi.StatusIconKind]::$iconKind
      $b.CornerRadius = 14
      $b.BorderColor = [System.Drawing.Color]::FromArgb(180, $Ccyan)
      $b.IconAccent = $Ccyan
    } catch {}
  }
  return $b
}
$btnSkin = New-LinkBtn 'Character / Skin' 'Skin'
$btnSkin.Add_Click({
  try {
    if ($script:CardCharacter) { $script:CardCharacter.Focus(); Set-Status 'Use the Character panel to upload or apply a skin' }
    else {
      $p = Select-NorcomSkinPng
      if ($p) { Import-NorcomCharacterSkin -Path $p | Out-Null }
    }
  } catch { try { Start-Process 'https://www.minecraft.net/en-us/msaprofile/mygames/editskin' } catch {} }
})
$linksHost.Controls.Add($btnSkin)
$btnCrash = New-LinkBtn 'Crash Report' 'Save'
$btnCrash.Add_Click({
  try {
    if ($script:SelfTest) { $script:Calls.Add('crashzip'); Set-Status 'Crash zip (dry)'; return }
    $z = Invoke-CrashLogZip
    Set-Status ('Crash report ready: ' + [IO.Path]::GetFileName($z))
  } catch { (Show-NcMsg @($_.Exception.Message, 'Crash Report', 'OK', 'Error')) | Out-Null }
})
$linksHost.Controls.Add($btnCrash)
$btnBrowseOutfits = New-LinkBtn 'Browse outfits' 'Globe'
$btnBrowseOutfits.Add_Click({ try { Show-NorcomBrowseOutfitsMenu -anchor $btnBrowseOutfits } catch {} })
$linksHost.Controls.Add($btnBrowseOutfits)
$script:BtnDiscord = New-LinkBtn 'Discord' 'Discord'
$script:BtnDiscord.Visible = $false
$script:DiscordUrl = 'https://discord.gg/baZx9CGxw'
$script:BtnDiscord.Add_Click({ $u = Get-DiscordInviteUrl; if (-not $u) { $u = $script:DiscordUrl }; if ($u) { Start-Process $u } })
$linksHost.Controls.Add($script:BtnDiscord)
$btnVoice = New-LinkBtn 'Voice Chat Test' 'Voice'
try { if ($script:HasNorcomUi -and $btnVoice -is [NorcomUi.RoundedButton]) { $btnVoice.LeadingIcon = [NorcomUi.StatusIconKind]::Voice } } catch {}
$btnVoice.Add_Click({
  try {
    $okJar = $false
    $modsDir = Join-Path $GameDir 'mods'
    if (Test-Path $modsDir) { $okJar = [bool](Get-ChildItem $modsDir -Filter '*voicechat*' -EA SilentlyContinue) }
    $tunnel = 'jensen-plasma.tun.ply.gg:2292'
    $msg = @()
    $msg += 'Simple Voice Chat (proximity)'
    $msg += ''
    $msg += 'In-game: V = voice menu Â· N = mute'
    $msg += ('Voice tunnel: ' + $tunnel)
    if ($okJar) { $msg += 'Client mod: installed' } else { $msg += 'Client mod: missing - run Repair / Re-sync' }
    $msg += ''
    $msg += 'Tip: join the Minecraft server first, then open the V menu to pick your mic.'
    (Show-NcMsg @(($msg -join [Environment]::NewLine), 'NORCOM Voice Chat', 'OK', 'Information')) | Out-Null
    Set-Status $(if ($okJar) { 'Voice chat ready' } else { 'Voice chat mod missing - use Repair' })
  } catch {
    (Show-NcMsg @($_.Exception.Message, 'Voice Chat Test', 'OK', 'Error')) | Out-Null
  }
})
$linksHost.Controls.Add($btnVoice)
$btnShots = New-LinkBtn 'Screenshots' 'Camera'
$btnShots.Add_Click({
  $dir = Join-Path $GameDir 'screenshots'
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  Start-Process explorer.exe $dir
})
$linksHost.Controls.Add($btnShots)
$btnMods = New-LinkBtn 'Open Mods (view)' 'Folder'
$btnMods.Add_Click({
  $dir = Join-Path $GameDir 'mods'
  if (-not (Test-Path $dir)) { (Show-NcMsg @('Mods folder not found yet. Play once to sync.','Mods','OK','Information'))|Out-Null; return }
  Start-Process explorer.exe $dir
})
$linksHost.Controls.Add($btnMods)
$script:CardLinks.Controls.Add($linksHost)
# 1.0.30v: do NOT BringToFront Fill host - that steals the Dock=Top title band
$script:LinksHost = $linksHost
$script:BtnSkin = $btnSkin
$script:BtnBrowseOutfits = $btnBrowseOutfits
$script:BtnVoice = $btnVoice
$script:BtnShots = $btnShots
$script:BtnCrash = $btnCrash
$script:BtnMods = $btnMods
# Character card already owns skin upload + browse outfits Ã¢â‚¬â€ hide duplicates so Actions fits
try {
  if ($script:CardCharacter) {
    if ($btnSkin) { $btnSkin.Visible = $false }
    if ($btnBrowseOutfits) { $btnBrowseOutfits.Visible = $false }
  }
} catch {}
$script:CardLinks.Add_Resize({ try { Fit-ActionsLinks } catch {} })
try { Fit-ActionsLinks } catch {}

# --- Pack + Next Restart combined ---
$script:CardPackRestart = New-OliveCard 'PACK / RESTART'
$script:PackInfoLabel = New-Object System.Windows.Forms.Label
$script:PackInfoLabel.Location = New-Object System.Drawing.Point 16, 40
$script:PackInfoLabel.Size = New-Object System.Drawing.Size 300, 72
$script:PackInfoLabel.Font = Get-UiFont 13
$script:PackInfoLabel.ForeColor = $Ctext
$script:PackInfoLabel.BackColor = [System.Drawing.Color]::Transparent
$script:PackInfoLabel.Text = Get-PackInfoText
$script:PackInfoLabel.UseMnemonic = $false
$rstHint = New-Object System.Windows.Forms.Label
$rstHint.Text = 'Restart daily 4:00 AM (Denver)'
$rstHint.Location = New-Object System.Drawing.Point 16, 108
$rstHint.Size = New-Object System.Drawing.Size 300, 20
$rstHint.Font = Get-UiFont 11
$rstHint.ForeColor = $Cdim
$rstHint.BackColor = [System.Drawing.Color]::Transparent
$rstHint.UseMnemonic = $false
$script:RestartCountdownLabel = New-Object System.Windows.Forms.Label
$script:RestartCountdownLabel.Location = New-Object System.Drawing.Point 16, 128
$script:RestartCountdownLabel.Size = New-Object System.Drawing.Size 300, 32
$script:RestartCountdownLabel.Font = Get-UiFont 18 ([System.Drawing.FontStyle]::Bold)
$script:RestartCountdownLabel.ForeColor = $Cgold
$script:RestartCountdownLabel.BackColor = [System.Drawing.Color]::Transparent
$script:RestartCountdownLabel.Text = Get-NextRestartCountdownText
$script:RestartCountdownLabel.UseMnemonic = $false
$script:CardPackRestart.Controls.Add($script:PackInfoLabel)
$script:CardPackRestart.Controls.Add($rstHint)
$script:CardPackRestart.Controls.Add($script:RestartCountdownLabel)

# --- Settings card (RAM + Repair) ---
$script:CardSettings = New-OliveCard 'SETTINGS'
$script:RamLabel = New-Object System.Windows.Forms.Label
$script:RamLabel.Name = 'RamLabel'
$script:RamLabel.Text = 'RAM (this PC)'
$script:RamLabel.Location = New-Object System.Drawing.Point 16, 42
$script:RamLabel.AutoSize = $true
$script:RamLabel.ForeColor = $Ctan
$script:RamLabel.Font = Get-UiFont 11 ([System.Drawing.FontStyle]::Bold)
$script:RamLabel.BackColor = [System.Drawing.Color]::Transparent
$script:RamLabel.UseMnemonic = $false
$script:RamValueLabel = New-Object System.Windows.Forms.Label
$script:RamValueLabel.Location = New-Object System.Drawing.Point 160, 42
$script:RamValueLabel.Size = New-Object System.Drawing.Size 140, 22
$script:RamValueLabel.ForeColor = $Cgold
$script:RamValueLabel.Font = Get-UiFont 13 ([System.Drawing.FontStyle]::Bold)
$script:RamValueLabel.BackColor = [System.Drawing.Color]::Transparent
$script:RamValueLabel.UseMnemonic = $false
$script:RamSlider = New-Object System.Windows.Forms.TrackBar
$script:RamSlider.Minimum = 2048
$script:RamSlider.Maximum = 12288
$script:RamSlider.TickStyle = 'None'
$script:RamSlider.SmallChange = 512
$script:RamSlider.LargeChange = 1024
$script:RamSlider.Location = New-Object System.Drawing.Point 10, 70
$script:RamSlider.Size = New-Object System.Drawing.Size 300, 40
$script:RamSlider.BackColor = [System.Drawing.Color]::FromArgb(14, 20, 42)
$settings0 = Get-NorcomSettings
$script:RamSlider.Value = [Math]::Max(2048,[Math]::Min(12288,[int]$settings0.ramMb))
function Update-RamLabel {
  if (-not $script:RamSlider -or -not $script:RamValueLabel) { return }
  $v = [int]$script:RamSlider.Value
  if ($v -lt 1024) { $v = [Math]::Max(2048, [int]$script:RamSlider.Minimum) }
  $gb = [Math]::Round($v / 1024.0, 1)
  if ($gb -lt 0.5) { $gb = [Math]::Round([Math]::Max(2048,$script:RamSlider.Minimum) / 1024.0, 1) }
  $script:RamValueLabel.Text = ("{0} GB" -f $gb)
}
Update-RamLabel
$script:RamSlider.Add_ValueChanged({
  Update-RamLabel
  $v = $script:RamSlider.Value
  $s = Get-NorcomSettings; $s.ramMb = $v; Save-NorcomSettings $s
  try { Update-ProfileRam $v } catch { Write-LogUi ('RAM save: ' + $_.Exception.Message) }
})
$btnVerify = New-SimplePill -text 'Repair / Re-sync' -size (New-Object System.Drawing.Size 136,32) -loc (New-Object System.Drawing.Point 16,152) -back $Cpink -fore ([System.Drawing.Color]::White) -hover ([System.Drawing.Color]::FromArgb(255, 90, 200)) -fontSize 11
$btnVerify.Add_Click({
  try {
    Set-Status 'Running Repair / Re-sync...'
    $r = Invoke-VerifyAndRepair
    $icon = 'Information'
    if ($r.level -eq 'yellow') { $icon = 'Warning' }
    if ($r.level -eq 'red') { $icon = 'Error' }
    $body = ($r.lines -join [Environment]::NewLine)
    (Show-NcMsg @($body, ("NORCOM Verify (" + $r.level + ")"), 'OK', $icon)) | Out-Null
    Set-Status ('Verify done: ' + $r.level)
    try { $script:PackInfoLabel.Text = Get-PackInfoText } catch {}
  } catch {
    (Show-NcMsg @($_.Exception.Message,'Verify failed','OK','Error'))|Out-Null
  }
})
$btnFixNorcom = New-SimplePill -text 'Fix NORCOM' -size (New-Object System.Drawing.Size 136,32) -loc (New-Object System.Drawing.Point 160,152) -back ([System.Drawing.Color]::FromArgb(0, 160, 180)) -fore ([System.Drawing.Color]::White) -hover ([System.Drawing.Color]::FromArgb(0, 229, 255)) -fontSize 11
$btnFixNorcom.Name = 'BtnFixNorcom'
$btnFixNorcom.Add_Click({
  try {
    $ans = Show-NorcomFixConfirmDialog
    if ($ans -ne [System.Windows.Forms.DialogResult]::Yes) { Set-Status 'Fix NORCOM canceled'; return }
    Set-Status 'Fix NORCOM: cleaning...'
    $r = Invoke-NorcomFix -Restart:(-not [bool]$script:SelfTest) -Silent:$false
    Set-Status ('Fix NORCOM done (removed ' + @($r.removed).Count + ' stale)')
    if ($script:SelfTest -or $env:NORCOM_LAUNCHER_SELFTEST) {
      if (-not $script:Calls) { $script:Calls = New-Object System.Collections.Generic.List[string] }
      $script:Calls.Add('fix-norcom')
    }
  } catch {
    (Show-NcMsg @($_.Exception.Message,'Fix NORCOM failed','OK','Error'))|Out-Null
  }
})
$script:BtnFixNorcom = $btnFixNorcom
$script:CardSettings.Controls.Add($script:RamLabel)
$script:CardSettings.Controls.Add($script:RamValueLabel)
$script:CardSettings.Controls.Add($script:RamSlider)
try { $script:CardSettings.Controls.Add($btnVerify) } catch {}
try { $script:CardSettings.Controls.Add($btnFixNorcom) } catch {}

# RAM presets Low / Balanced / High
$script:RamPresetHost = New-Object System.Windows.Forms.FlowLayoutPanel
$script:RamPresetHost.Location = New-Object System.Drawing.Point 10, 96
$script:RamPresetHost.Size = New-Object System.Drawing.Size 300, 28
$script:RamPresetHost.BackColor = [System.Drawing.Color]::Transparent
$script:RamPresetHost.WrapContents = $false
function Get-AutoRamPresetMb {
  $total = 8
  try { $total = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB) } catch {}
  if ($total -le 8) { return @{ name='Low'; mb=3072 } }
  elseif ($total -le 16) { return @{ name='Balanced'; mb=6144 } }
  else { return @{ name='High'; mb=8192 } }
}
function Set-RamPreset([string]$name) {
  $map = @{ Low = 3072; Balanced = 6144; High = 8192 }
  if (-not $map.ContainsKey($name)) { return }
  $mb = [int]$map[$name]
  $script:RamSlider.Value = [Math]::Max($script:RamSlider.Minimum, [Math]::Min($script:RamSlider.Maximum, $mb))
  Update-RamLabel
  $s = Get-NorcomSettings; $s.ramMb = $mb; $s.ramPreset = $name; Save-NorcomSettings $s
  try { Update-ProfileRam $mb } catch {}
}
$script:RecommendedRamName = 'Balanced'
try { $script:RecommendedRamName = (Get-AutoRamPresetMb).name } catch {}
foreach ($n in @('Low','Balanced','High')) {
  $label = $n
  if ($n -eq $script:RecommendedRamName) { $label = "$n *" }
  $b = New-SimplePill -text $label -size (New-Object System.Drawing.Size 110,30) -loc (New-Object System.Drawing.Point 0,0) -back ([System.Drawing.Color]::FromArgb(40,8,16,36)) -fore $Ctext -hover $Ccyan -fontSize 10
  $b.Margin = New-Object System.Windows.Forms.Padding 3,0,3,0
  $b.AutoSize = $false
  if ($n -eq $script:RecommendedRamName) {
    try {
      if ($b -is [NorcomUi.RoundedButton]) { $b.BorderColor = [System.Drawing.Color]::FromArgb(220, $Cgold) }
    } catch {}
  }
  $nm = $n
  $b.Add_Click({ Set-RamPreset $nm }.GetNewClosure())
  $script:RamPresetHost.Controls.Add($b)
}
$script:LblSecPerf = New-Object System.Windows.Forms.Label
$script:LblSecPerf.Text = 'Performance'
$script:LblSecPerf.Name = 'SecPerf'
$script:LblSecPerf.BackColor = [System.Drawing.Color]::Transparent
$script:LblSecAppear = New-Object System.Windows.Forms.Label
$script:LblSecAppear.Text = 'Appearance'
$script:LblSecAppear.Name = 'SecAppear'
$script:LblSecAppear.BackColor = [System.Drawing.Color]::Transparent
$script:LblSecGame = New-Object System.Windows.Forms.Label
$script:LblSecGame.Text = 'Game'
$script:LblSecGame.Name = 'SecGame'
$script:LblSecGame.BackColor = [System.Drawing.Color]::Transparent
$script:LblSecMaint = New-Object System.Windows.Forms.Label
$script:LblSecMaint.Text = 'Maintenance'
$script:LblSecMaint.Name = 'SecMaint'
$script:LblSecMaint.BackColor = [System.Drawing.Color]::Transparent
$script:GraphicsProfileLabel = New-Object System.Windows.Forms.Label
$script:GraphicsProfileLabel.Name = 'GfxProfile'
$script:GraphicsProfileLabel.ForeColor = $Cdim
$script:GraphicsProfileLabel.BackColor = [System.Drawing.Color]::Transparent
$script:GraphicsProfileLabel.Text = 'Graphics profile: detecting...'
$script:GraphicsProfileLabel.UseMnemonic = $false
try {
  $gi = Get-NorcomGpuInfo
  $script:GraphicsProfileLabel.Text = ('Graphics: {0} (profile: {1})' -f $gi.Name, $gi.Profile)
} catch { $script:GraphicsProfileLabel.Text = 'Graphics: unknown (profile: Generic)' }
$script:BtnOpenGameFolder = New-SimplePill -text 'Game folder' -size (New-Object System.Drawing.Size 128,30) -loc (New-Object System.Drawing.Point 0,0) -back ([System.Drawing.Color]::FromArgb(40,8,16,36)) -fore $Ctext -hover $Ccyan -fontSize 10
$script:BtnOpenGameFolder.Add_Click({ try { if (-not (Test-Path $GameDir)) { New-Item -ItemType Directory -Path $GameDir -Force | Out-Null }; Start-Process explorer.exe $GameDir } catch {} })
$script:BtnOpenScreenshotsFolder = New-SimplePill -text 'Shots folder' -size (New-Object System.Drawing.Size 128,30) -loc (New-Object System.Drawing.Point 0,0) -back ([System.Drawing.Color]::FromArgb(40,8,16,36)) -fore $Ctext -hover $Ccyan -fontSize 10
$script:BtnOpenScreenshotsFolder.Add_Click({ $d = Join-Path $GameDir 'screenshots'; if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }; Start-Process explorer.exe $d })
$script:BtnOpenModsFolder = New-SimplePill -text 'Mods folder' -size (New-Object System.Drawing.Size 128,30) -loc (New-Object System.Drawing.Point 0,0) -back ([System.Drawing.Color]::FromArgb(40,8,16,36)) -fore $Ctext -hover $Ccyan -fontSize 10
$script:BtnOpenModsFolder.Add_Click({ $d = Join-Path $GameDir 'mods'; if (-not (Test-Path $d)) { (Show-NcMsg @('Mods folder not found yet. Play once to sync.','Mods','OK','Information'))|Out-Null; return }; Start-Process explorer.exe $d })
$script:JavaInfoLabel = New-Object System.Windows.Forms.Label
$script:JavaInfoLabel.ForeColor = $Cdim
$script:JavaInfoLabel.BackColor = [System.Drawing.Color]::Transparent
$script:JavaInfoLabel.UseMnemonic = $false
try {
  $j = Get-JavaExe
  $script:JavaInfoLabel.Text = $(if ($j) { "Java: $j" } else { 'Java: not detected yet (Play will install/find one)' })
} catch { $script:JavaInfoLabel.Text = 'Java: not detected yet' }
$script:BtnRepairSettings = $null
$script:BtnCrashSettings = New-SimplePill -text 'Crash report' -size (New-Object System.Drawing.Size 160,32) -loc (New-Object System.Drawing.Point 0,0) -back ([System.Drawing.Color]::FromArgb(40,8,16,36)) -fore $Ctext -hover $Ccyan -fontSize 10
$script:BtnCrashSettings.Add_Click({
  try {
    if ($script:SelfTest) { $script:Calls.Add('crashzip'); Set-Status 'Crash zip (dry)'; return }
    $z = Invoke-CrashLogZip
    Set-Status ('Crash report ready: ' + [IO.Path]::GetFileName($z))
  } catch { (Show-NcMsg @($_.Exception.Message, 'Crash Report', 'OK', 'Error')) | Out-Null }
})
$script:BtnCheckUpdates = New-SimplePill -text 'Check for updates' -size (New-Object System.Drawing.Size 160,32) -loc (New-Object System.Drawing.Point 0,0) -back ([System.Drawing.Color]::FromArgb(40,8,16,36)) -fore $Ctext -hover $Cpink -fontSize 10
$script:BtnCheckUpdates.Add_Click({
  try {
    Set-Status 'Checking for launcher updates...'
    if (Get-Command Invoke-NorcomSelfUpdateCheck -EA SilentlyContinue) {
      Invoke-NorcomSelfUpdateCheck -Force
    } elseif (Get-Command Start-NorcomUpdateCheck -EA SilentlyContinue) {
      Start-NorcomUpdateCheck
    } else {
      Set-Status ('Launcher v' + $script:NcLauncherVersion + ' - update check on next launch')
      (Show-NcMsg @(("Installed launcher: v$($script:NcLauncherVersion)`nUpdates apply automatically when you open NORCOM."), 'NORCOM Updates', 'OK', 'Information')) | Out-Null
    }
  } catch { Set-Status $_.Exception.Message }
})
$script:VersionInfoLabel = New-Object System.Windows.Forms.Label
$script:VersionInfoLabel.ForeColor = $Cdim
$script:VersionInfoLabel.BackColor = [System.Drawing.Color]::Transparent
$script:VersionInfoLabel.Text = ("NORCOM launcher v{0}  |  * = recommended RAM for this PC" -f $script:NcLauncherVersion)
$script:VersionInfoLabel.UseMnemonic = $false
# 1.0.30f: opaque Label (GlassLabel text often blank under PrintWindow captures)
$script:AboutNorcomLabel = New-Object System.Windows.Forms.Label
$script:AboutNorcomLabel.ForeColor = $Ccyan
$script:AboutNorcomLabel.BackColor = [System.Drawing.Color]::FromArgb(18, 26, 52)
$script:AboutNorcomLabel.UseMnemonic = $false
$script:AboutNorcomLabel.Text = ("About NORCOM  v{0}  -  discord.gg/baZx9CGxw" -f $script:NcLauncherVersion)
$script:AboutNorcomLabel.TextAlign = 'MiddleLeft'
try { $script:AboutNorcomLabel.FlatStyle = 'Standard' } catch {}

$script:CardSettings.Controls.Add($script:RamPresetHost)
$script:ChkAnimBg = New-Object System.Windows.Forms.CheckBox
$script:ChkAnimBg.Text = 'Animated background'
$script:ChkAnimBg.AutoSize = $true
$script:ChkAnimBg.Location = New-Object System.Drawing.Point 16, 126
$script:ChkAnimBg.ForeColor = $Ctext
$script:ChkAnimBg.BackColor = [System.Drawing.Color]::Transparent
$script:ChkAnimBg.Checked = [bool]$script:AnimBgEnabled
$script:ChkAnimBg.Add_CheckedChanged({
  $script:AnimBgEnabled = $script:ChkAnimBg.Checked
  try { if ($script:RootPanel -and $script:RootPanel.GetType().Name -eq 'AnimatedCityBg') { $script:RootPanel.AnimEnabled = $script:AnimBgEnabled } } catch {}
  $s = Get-NorcomSettings; $s.animatedBackground = $script:AnimBgEnabled; Save-NorcomSettings $s
})
$script:CardSettings.Controls.Add($script:ChkAnimBg)
$script:ChkSound = New-Object System.Windows.Forms.CheckBox
$script:ChkSound.Text = 'Launcher sounds'
$script:ChkSound.AutoSize = $true
$script:ChkSound.Location = New-Object System.Drawing.Point 180, 126
$script:ChkSound.ForeColor = $Cdim
$script:ChkSound.BackColor = [System.Drawing.Color]::Transparent
try { $ss = Get-NorcomSettings; $script:ChkSound.Checked = [bool]$ss.launcherSounds } catch { $script:ChkSound.Checked = $false }
$script:ChkSound.Add_CheckedChanged({ $s = Get-NorcomSettings; $s.launcherSounds = $script:ChkSound.Checked; Save-NorcomSettings $s })
$script:CardSettings.Controls.Add($script:ChkSound)
# Auto-pick RAM preset on first run
try {
  $s0 = Get-NorcomSettings
  if (-not $s0.ramPreset) {
    $auto = Get-AutoRamPresetMb
    Set-RamPreset $auto.name
  }
} catch {}
# Graphics profile hint (AMD boost / low shaders) Ã¢â‚¬â€ non-destructive suggestion only
try {
  $gi = Get-NorcomGpuInfo
  Write-LogUi ('GPU profile: {0} ({1})' -f $gi.Name, $gi.Profile)
} catch {}

$script:BtnRepairSettings = $btnVerify
try { $script:CardSettings.Controls.Add($btnFixNorcom) } catch {}
try { $btnVerify.Text = 'Repair / Re-sync' } catch {}
foreach ($ctl in @(
  $script:LblSecPerf, $script:LblSecAppear, $script:LblSecGame, $script:LblSecMaint,
  $script:GraphicsProfileLabel,
  $script:BtnOpenGameFolder, $script:BtnOpenScreenshotsFolder, $script:BtnOpenModsFolder,
  $script:JavaInfoLabel, $script:BtnCrashSettings, $script:BtnCheckUpdates, $script:VersionInfoLabel, $script:AboutNorcomLabel
)) { if ($ctl) { $script:CardSettings.Controls.Add($ctl) } }
$script:CardSettings.Controls.Add($btnVerify)
$script:CardSettings.Add_Resize({
  try { Fit-SettingsCard } catch {}
  if ($script:RamSlider) { $script:RamSlider.Width = [Math]::Max(160, $script:CardSettings.ClientSize.Width - 28) }
})
$script:CardPackRestart.Add_Resize({ Fit-NcCardLabels $script:CardPackRestart; try { Fit-PackRestartCard } catch {} })

# Compat alias for older refresh code
$script:CardPack = $script:CardPackRestart
$script:CardRestart = $script:CardPackRestart

if ($script:HasNorcomUi) {
  try { $footer = New-Object NorcomUi.GlassLabel } catch { $footer = New-Object System.Windows.Forms.Label }
} else {
  $footer = New-Object System.Windows.Forms.Label
}
$footer.Text = 'Official mods only  |  Physics Mod Pro is optional and not included'
$footer.Dock = 'Fill'
$footer.ForeColor = $Cdim
$footer.BackColor = [System.Drawing.Color]::Transparent
$footer.Font = Get-UiFont 10
$footer.TextAlign = 'MiddleCenter'
$footer.UseMnemonic = $false
$footer.AutoSize = $false
# Mount Character + Settings onto their pages (Home keeps CardsFlow)
try {
  if ($script:PageCharacter -and $script:CharPreviewCard) {
    $script:CharPreviewCard.Dock = 'None'
    $script:PageCharacter.Controls.Add($script:CharPreviewCard)
  }
  if ($script:PageCharacter -and $script:CharCreatorCard) {
    $script:CharCreatorCard.Dock = 'None'
    $script:PageCharacter.Controls.Add($script:CharCreatorCard)
  }
  if ($script:PageSettings -and $script:CardSettings) {
    $script:CardSettings.Dock = 'None'
    $script:PageSettings.Controls.Add($script:CardSettings)
  }
  if ($script:PageSettings -and $script:CardRules) {
    # Rules stay accessible from Home via optional second mount? Keep on settings below settings card when tall.
  }
} catch { Write-LogUi ('page mount: ' + $_.Exception.Message) }
$footer.Dock = 'Bottom'
$footer.Height = 26
# 1.0.30o: Dock z-order â€” highest index docks to edge first. Add Fill, then Bottom, then Top last.
# Never SetChildIndex on docked siblings (that made hero paint over cards = dark strip + mid-line cuts).
$root.Controls.Add($script:CardsScroll)
$root.Controls.Add($footer)
$root.Controls.Add($hero)

# Compat stubs for older helpers (do NOT null PageSettings/NavSettings Ã¢â‚¬â€ used by tabbed UI)
$script:Tabs = $null
$script:PagePlay = $null
$script:PageNews = $null
$script:NavPlay = $null
$script:NavNews = $null
$script:ModsList = $null
$script:WhatsNewBox = $null
$script:LogBox = $null
$script:ModsCountLabel = $null
$script:DetailTitle = $null
$script:DetailSummary = $null
$script:DetailMeta = $null
$script:DetailLink = $null
$script:DetailChange = $null
$script:ImageList = $null
$script:BannerHost = $null

function Show-NorcomPage([string]$name) {
  if (-not $name) { $name = 'home' }
  $name = $name.ToLowerInvariant()
  $script:CurrentPage = $name
  $isHome = ($name -eq 'home')
  $isChar = ($name -eq 'character')
  $isSet = ($name -eq 'settings')
  foreach ($pair in @(
    @{ b = $script:NavHome; on = $isHome },
    @{ b = $script:NavCharacter; on = $isChar },
    @{ b = $script:NavSettings; on = $isSet }
  )) {
    if (-not $pair.b) { continue }
    if ($pair.on) {
      $pair.b.BackColor = [System.Drawing.Color]::FromArgb(200, 0, 190, 230)
      $pair.b.ForeColor = [System.Drawing.Color]::White
      try {
        if ($pair.b -is [NorcomUi.RoundedButton]) {
          $pair.b.BorderColor = [System.Drawing.Color]::FromArgb(255, 0, 240, 255)
          $pair.b.BackColor = [System.Drawing.Color]::FromArgb(230, 0, 170, 230)
        }
      } catch {}
    } else {
      $pair.b.BackColor = [System.Drawing.Color]::FromArgb(40, 8, 16, 36)
      $pair.b.ForeColor = $Ctext
      try {
        if ($pair.b -is [NorcomUi.RoundedButton]) {
          $pair.b.BorderColor = [System.Drawing.Color]::FromArgb(120, $Ccyan)
        }
      } catch {}
    }
  }
  if ($script:PageHome) { $script:PageHome.Visible = $isHome }
  if ($script:PageCharacter) { $script:PageCharacter.Visible = $isChar }
  if ($script:PageSettings) { $script:PageSettings.Visible = $isSet }
  # Keep legacy CardsFlow hosting on home page panel
  try {
    if ($isHome) { Update-LauncherCardLayout }
    if ($isChar) { Update-CharacterPageLayout }
    if ($isSet) { Update-SettingsPageLayout }
  } catch {}
}

function Update-CharacterPageLayout {
  if (-not $script:PageCharacter) { return }
  $pw = [Math]::Max(200, $script:PageCharacter.ClientSize.Width)
  $ph = [Math]::Max(200, $script:PageCharacter.ClientSize.Height)
  $pad = 8
  $gap = 8
  $leftW = [Math]::Max(260, [int](($pw - 3 * $pad) * 0.48))
  if ($leftW -gt 460) { $leftW = 460 }
  $rightX = $leftW + 2 * $pad
  $rightW = [Math]::Max(260, $pw - $rightX - $pad)
  $cardH = $ph - 2 * $pad
  if ($script:CharPreviewCard) {
    $script:CharPreviewCard.Location = New-Object System.Drawing.Point $pad, $pad
    $script:CharPreviewCard.Size = New-Object System.Drawing.Size $leftW, $cardH
  }
  # Work inside charInner (Dock Fill under card padding+title)
  $hostPanel = $null
  try { $hostPanel = $script:CharPreviewCard.Controls | Where-Object { $_.Name -eq 'CharInner' } | Select-Object -First 1 } catch {}
  if (-not $hostPanel) { $hostPanel = $script:CharPreviewCard }
  $cw = [Math]::Max(160, $hostPanel.ClientSize.Width - 4)
  $ch = [Math]::Max(160, $hostPanel.ClientSize.Height - 4)
  $btnH = 30
  $btnGap = 4
  $capeH = 26
  # 1.0.30x: reserve Dock-Bottom table (36) + cape host (~28) + padding so row never clips card border
  $bottomH = 36 + 6 + ($capeH + 2) + 8
  $targetPrev = [int]([Math]::Max(160, $ph * 0.70))
  $prevH = [Math]::Max(140, [Math]::Min($targetPrev, $ch - $bottomH - 4))
  if ($script:SkinPreview) {
    try { $script:SkinPreview.Dock = 'Fill' } catch {
      $script:SkinPreview.Location = New-Object System.Drawing.Point 2, 2
      $script:SkinPreview.Size = New-Object System.Drawing.Size $cw, $prevH
    }
    try { if ($script:SkinPreview.GetType().Name -eq 'SkinPreview3D') { $script:SkinPreview.IdleSpin = $true } } catch {}
    $script:SkinPreview.Visible = $true
  }
  # 1.0.30x: CharBtnTable Dock Bottom — 4 equal columns; only refresh labels/fonts
  if ($script:CharBtnTable) {
    $script:CharBtnTable.Visible = $true
    $script:CharBtnTable.Height = 36
    try { $hostPanel.Controls.SetChildIndex($script:CharBtnTable, 0) } catch {}
  }
  if ($script:CharCapeHost) {
    $script:CharCapeHost.Visible = $true
    $script:CharCapeHost.Height = $capeH + 2
    try { $hostPanel.Controls.SetChildIndex($script:CharCapeHost, 1) } catch {}
  }
  if ($script:BtnClassicSlim) {
    $script:BtnClassicSlim.Visible = $true
    $script:BtnClassicSlim.Text = $(if ($script:CharacterSlim) { 'Slim' } else { 'Classic' })
    $script:BtnClassicSlim.Font = Get-UiFont 9 ([System.Drawing.FontStyle]::Bold)
  }
  if ($script:BtnUploadSkin) {
    $script:BtnUploadSkin.Visible = $true
    $script:BtnUploadSkin.Text = 'Upload'
    $script:BtnUploadSkin.Font = Get-UiFont 9 ([System.Drawing.FontStyle]::Bold)
  }
  if ($script:BtnApplySkin) {
    $script:BtnApplySkin.Visible = $true
    $script:BtnApplySkin.Text = 'Apply'
    $script:BtnApplySkin.Font = Get-UiFont 9 ([System.Drawing.FontStyle]::Bold)
  }
  if ($script:BtnBrowseOutfits2) {
    $script:BtnBrowseOutfits2.Visible = $true
    $script:BtnBrowseOutfits2.Text = 'Browse outfits'
    $script:BtnBrowseOutfits2.Font = Get-UiFont 8 ([System.Drawing.FontStyle]::Bold)
  }
  if ($script:CapeCombo) { $script:CapeCombo.Visible = $true }
  if ($script:SavedSkinsHost) { $script:SavedSkinsHost.Visible = $false }
  if ($script:SkinPreview) {
    try { $script:SkinPreview.Dock = 'Fill' } catch {}
  }
  if ($script:CharCreatorCard) {
    $script:CharCreatorCard.Location = New-Object System.Drawing.Point $rightX, $pad
    $script:CharCreatorCard.Size = New-Object System.Drawing.Size $rightW, $cardH
  }
  if ($script:CreatorHost) {
    $script:CreatorHost.BringToFront()
    try { $script:CreatorHost.Dock = 'Fill' } catch {}
    try { $script:CreatorHost.HorizontalScroll.Enabled = $false; $script:CreatorHost.HorizontalScroll.Visible = $false } catch {}
    $rw = [Math]::Max(200, $script:CreatorHost.ClientSize.Width - 8)
    if ($rw -lt 120) { $rw = [Math]::Max(200, $rightW - 40) }
    $vsw = 0
    try { $vsw = [System.Windows.Forms.SystemInformation]::VerticalScrollBarWidth } catch { $vsw = 18 }
    $inner = [Math]::Max(160, $rw - $vsw - 4)
    $maxBottom = 0
    foreach ($row in @($script:CreatorHost.Controls)) {
      try {
        if ($row -is [System.Windows.Forms.Panel]) {
          $row.Width = $rw
          # 1.0.30v: equal-fit style pills across row so labels like mohawk never truncate
          $pills = @($row.Controls | Where-Object { $_ -is [System.Windows.Forms.Button] -or ($_.GetType().Name -match 'Button|Pill|Rounded') })
          if ($pills.Count -ge 2 -and $row.Height -ge 50) {
            $gap = 4
            $avail = [Math]::Max(120, $inner - 4)
            $bw = [Math]::Max(52, [int](($avail - $gap * ($pills.Count - 1)) / $pills.Count))
            $x = 2
            foreach ($pb in ($pills | Sort-Object Left)) {
              $pb.AutoSize = $false
              try { $pb.AutoEllipsis = $false } catch {}
              $pb.Size = New-Object System.Drawing.Size $bw, 26
              $pb.Location = New-Object System.Drawing.Point $x, 24
              $x += $bw + $gap
            }
          }
        }
        $b = $row.Top + $row.Height
        if ($b -gt $maxBottom) { $maxBottom = $b }
      } catch {}
    }
    try { $script:CreatorHost.AutoScrollMinSize = New-Object System.Drawing.Size 0, ($maxBottom + 10) } catch {}
  }
}

function Update-SettingsPageLayout {
  if (-not $script:PageSettings -or -not $script:CardSettings) { return }
  $pw = [Math]::Max(300, $script:PageSettings.ClientSize.Width)
  $ph = [Math]::Max(200, $script:PageSettings.ClientSize.Height)
  try { $script:PageSettings.AutoScroll = $false } catch {}
  # 1.0.30u: card fills page; CardSettings AutoScroll handles overflow (no About pin)
  $script:CardSettings.Location = New-Object System.Drawing.Point 8, 8
  $script:CardSettings.Size = New-Object System.Drawing.Size ($pw - 16), ($ph - 16)
  try { Fit-SettingsCard } catch {}
}

$st = Load-State
$already = (Test-Path (Join-Path $GameDir 'mods')) -or ($st.installed -eq $true)
if ($already) {
  $script:BtnPrimary.Text = 'PLAY'
  Set-Status 'Ready - Play updates then launches'
} else {
  $script:BtnPrimary.Text = 'INSTALL'
  Set-Status 'First time? Tap INSTALL'
}

$script:BtnPrimary.Add_Click({
  if ($script:BtnPrimary.Text -like 'INSTALL*' -or $script:BtnPrimary.Text -like 'Install*') { Invoke-InstallOrSync }
  else { Invoke-Play }
})

$script:Changes = @()
Write-LogUi "Pack URL: $PackUrl"
Write-LogUi "Game dir: $GameDir"
Write-LogUi "MC dir: $McDir"

function Set-ServerStatusPill($ping) {
  if (-not $script:ServerStatusLabel) { return }
  if ($ping.online) {
    $script:ServerDot.BackColor = $Conline
    $script:ServerStatusLabel.ForeColor = $Conline
    $script:ServerStatusLabel.Text = 'Online'
    $ms = [int]$ping.latencyMs
    if ($script:PingChip) {
      $script:PingChip.Text = ('{0} ms' -f $ms)
      if ($ms -lt 120) { $script:PingChip.BackColor = $Conline }
      elseif ($ms -lt 250) { $script:PingChip.BackColor = $Cgold }
      else { $script:PingChip.BackColor = $Coffline }
      $script:PingChip.ForeColor = [System.Drawing.Color]::FromArgb(28,28,20)
      try { Update-PingChipSize } catch {}
    }
    $script:ServerPlayersLabel.Text = ('Players: {0}/{1}' -f $ping.players, $ping.max)
    $script:ServerPlayersLabel.ForeColor = $Ctext
    $nameList = ''
    try {
      if ($ping.names -and @($ping.names).Count -gt 0) {
        $nameList = (@($ping.names) | Select-Object -First 12) -join ', '
      }
    } catch {}
    if ($script:ServerNamesLabel) {
      if ($nameList) { $script:ServerNamesLabel.Text = $nameList; $script:ServerNamesLabel.ForeColor = $Ctext }
      else {
        $script:ServerNamesLabel.Text = 'Easy - Friends only'
        $script:ServerNamesLabel.ForeColor = $Cdim
      }
    }
    try {
      if ($script:PlayerHeadsHost) {
        $script:PlayerHeadsHost.Controls.Clear()
        $names = @()
        try { if ($ping.names) { $names = @($ping.names) | Select-Object -First 8 } } catch {}
        foreach ($nm in $names) {
          $chip = New-Object System.Windows.Forms.Label
          $chip.AutoSize = $false
          $chip.Size = New-Object System.Drawing.Size 34, 34
          $chip.Margin = New-Object System.Windows.Forms.Padding 2, 0, 2, 0
          $chip.TextAlign = 'MiddleCenter'
          $chip.Font = Get-UiFont 9 ([System.Drawing.FontStyle]::Bold)
          $chip.ForeColor = [System.Drawing.Color]::White
          $chip.BackColor = [System.Drawing.Color]::FromArgb(180, 0, 160, 200)
          $chip.Text = if ($nm) { ($nm.ToString().Substring(0,1)).ToUpperInvariant() } else { '?' }
          $chip.Cursor = [System.Windows.Forms.Cursors]::Default
          try { $tip = New-Object System.Windows.Forms.ToolTip; $tip.SetToolTip($chip, [string]$nm) } catch {}
          $script:PlayerHeadsHost.Controls.Add($chip)
        }
        if ($names.Count -eq 0) {
          $empty = New-Object System.Windows.Forms.Label
          $empty.AutoSize = $false
          $empty.Size = New-Object System.Drawing.Size ([Math]::Max(120, $script:PlayerHeadsHost.ClientSize.Width - 4)), 32
          $empty.Text = 'No players online - be the first!'
          $empty.ForeColor = $Ccyan
          $empty.Font = Get-UiFont 11 ([System.Drawing.FontStyle]::Bold)
          $empty.BackColor = [System.Drawing.Color]::FromArgb(50, 0, 40, 70)
          $empty.TextAlign = 'MiddleLeft'
          $script:PlayerHeadsHost.Controls.Add($empty)
        }
      }
    } catch {}
  } else {
    $script:ServerDot.BackColor = $Coffline
    $script:ServerStatusLabel.ForeColor = $Coffline
    $err = if ($ping.error) { $ping.error } else { 'unreachable' }
    $script:ServerStatusLabel.Text = ('Offline')
    if ($script:PingChip) {
      $script:PingChip.Text = 'down'
      $script:PingChip.BackColor = $Coffline
      $script:PingChip.ForeColor = $Ctext
      try { Update-PingChipSize } catch {}
    }
    $script:ServerPlayersLabel.Text = 'Players: -'
    $script:ServerPlayersLabel.ForeColor = $Cdim
    if ($script:ServerNamesLabel) { $script:ServerNamesLabel.Text = $err; $script:ServerNamesLabel.ForeColor = $Cdim }
  }
}

# Server list ping runs in a background runspace so startup and the 30 s tick never block the UI.
function Start-NorcomPingAsync {
  if ($script:PingPs) { return }
  try {
    if ($script:ServerStatusLabel -and -not $script:PingEverDone) { $script:ServerStatusLabel.Text = 'Checking...' }
    $rs = [runspacefactory]::CreateRunspace(); $rs.ApartmentState = 'MTA'; $rs.Open()
    $ps = [powershell]::Create(); $ps.Runspace = $rs
    [void]$ps.AddScript({ param($extras) function Write-LogUi { param($m) }; . $extras; Invoke-ServerListPing }).AddArgument((Join-Path $ScriptDir 'tools\NorcomExtras.ps1'))
    $script:PingPs = $ps; $script:PingAr = $ps.BeginInvoke()
    $script:PingPoll.Start()
  } catch { $script:PingPs = $null; try { Set-ServerStatusPill (Invoke-ServerListPing) } catch {} }
}
$script:PingPoll = New-Object System.Windows.Forms.Timer
$script:PingPoll.Interval = 100
$script:PingPoll.Add_Tick({
  if (-not $script:PingAr -or -not $script:PingAr.IsCompleted) { return }
  $script:PingPoll.Stop()
  $res = $null
  try { $res = @($script:PingPs.EndInvoke($script:PingAr)) | Select-Object -Last 1 } catch {}
  try { $script:PingPs.Runspace.Dispose(); $script:PingPs.Dispose() } catch {}
  $script:PingPs = $null; $script:PingAr = $null; $script:PingEverDone = $true
  try {
    if ($res) { Set-ServerStatusPill ([pscustomobject]$res) }
    elseif ($script:ServerStatusLabel) { $script:ServerDot.BackColor = $Coffline; $script:ServerStatusLabel.Text = 'Offline  |  status error' }
  } catch {}
})
Start-NorcomPingAsync
try {
  $du = Get-DiscordInviteUrl
  if (-not $du) { $du = 'https://discord.gg/baZx9CGxw' }
  $script:DiscordUrl = $du
  if ($script:BtnDiscord) { $script:BtnDiscord.Visible = $true }
} catch {}

try { Ensure-NorcomShortcuts } catch { Write-LogUi ('Ensure shortcuts: ' + $_.Exception.Message) }

$script:ResizeDebounce = New-Object System.Windows.Forms.Timer
$script:ResizeDebounce.Interval = 80
$script:ResizeDebounce.Add_Tick({
  $script:ResizeDebounce.Stop()
  try {
    $script:UiScale = Get-UiScale
    $heroH = [int](210 * $script:UiScale)
    if ($heroH -lt 190) { $heroH = 190 }
    try { if ($form.ClientSize.Height -lt 720) { $heroH = 255 } } catch {}  # 1.0.30s: status fully above tabs
    if ($heroH -gt 300) { $heroH = 300 }
    if ($script:UiScale -ge 1.35) { $heroH = [Math]::Min(420, [int](235 * $script:UiScale)) }
    try { if ($script:HeroPanel) { $script:HeroPanel.Height = $heroH }; $script:NcHeroHeight = $heroH } catch {}  # 1.0.30m
    Update-LauncherHeroLayout
    try {
      if ($script:CurrentPage -eq 'character') { Update-CharacterPageLayout }
      elseif ($script:CurrentPage -eq 'settings') { Update-SettingsPageLayout }
      else { Update-LauncherCardLayout }
    } catch { Update-LauncherCardLayout }
    try { $root.Invalidate($false) } catch { $root.Invalidate() }
  } catch {}
})
$form.Add_Resize({ try { $script:ResizeDebounce.Stop(); $script:ResizeDebounce.Start() } catch { Update-LauncherCardLayout } })

# System tray / close-to-tray
try {
  
# 1.0.31: bring running instance to front when a second launch signals us (event or activate.request)
function Show-NorcomMainWindow {
  try {
    if ($script:TrayIcon) { $script:TrayIcon.Visible = $false }
  } catch {}
  try {
    $f = $null
    try { if ($script:form) { $f = $script:form } } catch {}
    try { if (-not $f -and $form) { $f = $form } } catch {}
    if ($f) {
      # Do NOT Show() before Application.Run creates the handle / NcUiReady.
      if (-not $f.IsHandleCreated) { return }
      if (-not $script:NcUiReady) { return }
      $f.Show()
      $f.WindowState = 'Normal'
      $f.ShowInTaskbar = $true
      $f.Activate()
      $f.BringToFront()
      try {
        if (-not ('NcFg' -as [type])) {
          Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class NcFg { [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr h, int n); [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h); }'
        }
        $h = $f.Handle
        if ([NcFg]::IsIconic($h)) { [void][NcFg]::ShowWindowAsync($h, 9) }
        [void][NcFg]::SetForegroundWindow($h)
      } catch {}
      Write-NcStartupLog 'activate: main window restored/foreground'
      try { Write-NorcomActivateAck } catch {}
    }
  } catch {
    Write-NcStartupLog ('activate failed: ' + $_.Exception.Message)
  }
}
function Start-NorcomActivateWatcher {
  try {
    if ($script:NcActivateStarted) { return }
    $script:NcActivateStarted = $true
    $created = $false
    $script:NcActivateEvent = New-Object System.Threading.EventWaitHandle($false, [System.Threading.EventResetMode]::AutoReset, 'Global\NORCOM.Launcher.Activate', [ref]$created)
    # Discard stub's own pre-launch SignalActivate so we do not Show() before ShowDialog.
    try { [void]$script:NcActivateEvent.WaitOne(0) } catch {}
    try {
      $req0 = Join-Path $env:LOCALAPPDATA 'NORCOM\Launcher\activate.request'
      if (Test-Path -LiteralPath $req0) { Remove-Item -LiteralPath $req0 -Force -EA SilentlyContinue }
    } catch {}
    $script:NcActivateIgnoreUntil = [DateTime]::UtcNow.AddSeconds(8)
    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 600
    $timer.Add_Tick({
      try {
        $hit = $false
        try { if ($script:NcActivateEvent -and $script:NcActivateEvent.WaitOne(0)) { $hit = $true } } catch {}
        $req = Join-Path $env:LOCALAPPDATA 'NORCOM\Launcher\activate.request'
        if (Test-Path -LiteralPath $req) {
          try {
            $age = [DateTime]::UtcNow - [DateTime]::Parse([IO.File]::ReadAllText($req), $null, [System.Globalization.DateTimeStyles]::RoundtripKind)
            if ($age.TotalSeconds -lt 30) { $hit = $true }
          } catch { $hit = $true }
          try { Remove-Item -LiteralPath $req -Force -EA SilentlyContinue } catch {}
        }
        if (-not $hit) { return }
        # Always ack so a second launch's self-heal handoff succeeds even during the startup ignore window.
        try { Write-NorcomActivateAck } catch {}
        if ($script:NcActivateIgnoreUntil -and [DateTime]::UtcNow -lt $script:NcActivateIgnoreUntil) {
          Write-NcStartupLog 'activate: ack during ignore window (defer show)'
          return
        }
        Show-NorcomMainWindow
      } catch {}
    })
    $timer.Start()
    $script:NcActivateTimer = $timer
    Write-NcStartupLog 'activate watcher started'
  } catch {
    Write-NcStartupLog ('activate watcher failed: ' + $_.Exception.Message)
  }
}$script:TrayIcon = New-Object System.Windows.Forms.NotifyIcon
  $script:TrayIcon.Text = 'NORCOM Launcher'
  try { if ($form.Icon) { $script:TrayIcon.Icon = $form.Icon } elseif (Test-Path $IconPath) { $script:TrayIcon.Icon = New-Object System.Drawing.Icon($IconPath) } } catch {}
  $script:TrayIcon.Visible = $false
  $trayMenu = New-Object System.Windows.Forms.ContextMenuStrip
  $miShow = New-Object System.Windows.Forms.ToolStripMenuItem 'Open NORCOM'
  $miShow.Add_Click({ $form.Show(); $form.WindowState = 'Normal'; $form.Activate(); $script:TrayIcon.Visible = $false })
  $miQuit = New-Object System.Windows.Forms.ToolStripMenuItem 'Quit'
  $miQuit.Add_Click({ $script:ForceClose = $true; $form.Close() })
  [void]$trayMenu.Items.Add($miShow); [void]$trayMenu.Items.Add($miQuit)
  $script:TrayIcon.ContextMenuStrip = $trayMenu
  $script:TrayIcon.Add_DoubleClick({ $form.Show(); $form.WindowState = 'Normal'; $form.Activate(); $script:TrayIcon.Visible = $false })
} catch { $script:TrayIcon = $null }
try { Start-NorcomActivateWatcher } catch {}

$form.Add_FormClosing({
  if (-not $script:ForceClose -and -not $shotPath -and -not $env:NORCOM_LAUNCHER_SELFTEST) {
    $sTray = $null; try { $sTray = Get-NorcomSettings } catch {}
    $closeTray = $true; try { if ($null -ne $sTray.closeToTray) { $closeTray = [bool]$sTray.closeToTray } } catch {}
    if ($closeTray -and $script:TrayIcon) {
      # 1.0.32: Application.Run message loop. Cancel all non-ForceClose closes.
      # Only Hide on real user X. Spurious CloseReason=None must re-show or the
      # window stays invisible forever (1.0.31 cancel-without-hide bug).
      $_.Cancel = $true
      $userClose = $false
      try { $userClose = ($_.CloseReason -eq [System.Windows.Forms.CloseReason]::UserClosing) } catch {}
      if ($userClose -and $script:NcUiReady) {
        $form.Hide()
        $script:TrayIcon.Visible = $true
        try { $script:TrayIcon.ShowBalloonTip(1200, 'NORCOM', 'Still running in the tray. Double-click to open.', [System.Windows.Forms.ToolTipIcon]::Info) } catch {}
        try { Write-NcStartupLog 'close-to-tray (user close)' } catch {}
      } else {
        try {
          if (-not $form.Visible) {
            $form.Visible = $true
            $form.ShowInTaskbar = $true
            $form.WindowState = 'Normal'
            $form.Show()
            $form.Activate()
            Write-NcStartupLog ('close canceled (reason=' + $_.CloseReason + ', forced visible)')
          } else {
            Write-NcStartupLog ('close canceled (reason=' + $_.CloseReason + ', kept visible)')
          }
        } catch {
          try { Write-NcStartupLog ('close canceled restore fail: ' + $_.Exception.Message) } catch {}
        }
      }
      return
    }
  }
  try { if ($script:TrayIcon) { $script:TrayIcon.Visible = $false; $script:TrayIcon.Dispose() } } catch {}
  Save-LauncherWindowBounds
})
$form.Add_Shown({
  # 1.0.33: defer clean reveal so Shown returns; solid opaque (no Opacity fade)
  try {
    $t = New-Object System.Windows.Forms.Timer
    $t.Interval = 15
    $t.Add_Tick({
      try { $t.Stop(); $t.Dispose() } catch {}
      try { Invoke-NorcomCleanReveal } catch {
        try { Close-NorcomSplash $script:Splash } catch {}
        try { $form.Opacity = 1 } catch {}
      }
    })
    $t.Start()
  } catch {
    try { Invoke-NorcomCleanReveal } catch {
      try { Close-NorcomSplash $script:Splash } catch {}
      try { $form.Opacity = 1 } catch {}
    }
  }
})

$script:UiTimer = New-Object System.Windows.Forms.Timer
$script:UiTimer.Interval = 1000
$script:UiTimer.Add_Tick({
  try { $script:RestartCountdownLabel.Text = Get-NextRestartCountdownText } catch {}
  try {
    if ($script:RootPanel -and $script:RootPanel.GetType().Name -eq 'AnimatedCityBg') {
      $mc = $false; try { $mc = Test-MinecraftRunning } catch {}
      $script:RootPanel.SetPaused( ($mc -or ($form.WindowState -eq 'Minimized') -or (-not $script:AnimBgEnabled)) )
    }
  } catch {}
})
$script:UiTimer.Start()
$script:PingTimer = New-Object System.Windows.Forms.Timer
$script:PingTimer.Interval = 30000
$script:PingTimer.Add_Tick({
  if ($form.WindowState -eq 'Minimized') { return }
  try { Start-NorcomPingAsync } catch {}
})
$script:PingTimer.Start()
$form.Add_FormClosing({
  try { $script:UiTimer.Stop() } catch {}
  try { $script:PingTimer.Stop() } catch {}
  try { $script:PingPoll.Stop() } catch {}
})

# Self-update (hash-verified). Runs once at startup; restarts launcher if a newer package is on GitHub.
if (-not $shotPath -and -not $env:NORCOM_LAUNCHER_SELFTEST) {
  $form.Add_Shown({
    try {
      if ($env:NORCOM_SKIP_SELFUPDATE) { return }
      Start-Sleep -Milliseconds 250
      [System.Windows.Forms.Application]::DoEvents()
      Invoke-NorcomLauncherSelfUpdate | Out-Null
    } catch { Write-LogUi ('Self-update: ' + $_.Exception.Message) }
  })
}

# One-click friend install: start pack sync as soon as UI is up
if ($AutoInstall) {
  $form.Add_Shown({
    try {
      Start-Sleep -Milliseconds 400
      [System.Windows.Forms.Application]::DoEvents()
      if ($script:BtnPrimary -and $script:BtnPrimary.Text -like 'Install*') {
        Write-LogUi 'AutoInstall: starting Invoke-InstallOrSync'
        Invoke-InstallOrSync
      } else {
        Write-LogUi ('AutoInstall: primary is ' + $(if ($script:BtnPrimary) { $script:BtnPrimary.Text } else { 'null' }))
      }
    } catch { Write-LogUi ('AutoInstall: ' + $_.Exception.Message) }
  })
}

if ($env:NORCOM_FRIEND_E2E_PLAY -eq '1') {
  $form.Add_Shown({
    try {
      Start-Sleep -Milliseconds 2500
      [System.Windows.Forms.Application]::DoEvents()
      Write-LogUi 'E2E: starting Invoke-Play'
      Invoke-Play
    } catch { Write-LogUi ('E2E play: ' + $_.Exception.Message) }
  })
}

# Screenshot path / mode (OFF-SCREEN only - never flash on desktop)
$shotPath = $ScreenshotPath
if (-not $shotPath) { $shotPath = $env:NORCOM_SCREENSHOT }
if (-not $shotPath -and (Test-Path (Join-Path $ScriptDir 'screenshot-path.txt'))) {
  $shotPath = (Get-Content (Join-Path $ScriptDir 'screenshot-path.txt') -Raw).Trim()
}

if ($shotPath) {
  # Dedicated splash capture (city glow + loading bar under wordmark)
  $wantSplash = $false
  try {
    if ($env:NORCOM_FORCE_SPLASH_SHOT) { $wantSplash = $true }
    if ($env:NORCOM_SHOT_PAGE -and $env:NORCOM_SHOT_PAGE.Trim().ToLowerInvariant() -eq 'splash') { $wantSplash = $true }
    $hook0 = Join-Path $ScriptDir 'screenshot-page.txt'
    if (Test-Path $hook0) {
      $hp = (Get-Content $hook0 -Raw).Trim().ToLowerInvariant()
      if ($hp -eq 'splash') { $wantSplash = $true }
    }
  } catch {}
  if ($wantSplash) {
    try {
      $env:NORCOM_FORCE_SPLASH_SHOT = '1'
      $sp = Show-NorcomSplash 'Loading NORCOM launcher...'
      if ($sp) {
        $sp.StartPosition = 'Manual'
        $sp.Location = New-Object System.Drawing.Point(-32000, -32000)
        try { $sp.Opacity = 1 } catch {}
        $sp.Show(); [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 180
        for ($i = 0; $i -lt 28; $i++) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 40 }
        $bmpS = New-Object System.Drawing.Bitmap ([Math]::Max(100,$sp.Width)), ([Math]::Max(100,$sp.Height))
        try {
          $sp.DrawToBitmap($bmpS, (New-Object System.Drawing.Rectangle 0, 0, $sp.Width, $sp.Height))
        } catch {
          if (-not ('NcPw' -as [type])) { Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class NcPw{[DllImport("user32.dll")]public static extern bool PrintWindow(IntPtr h,IntPtr dc,uint f);}' }
          $gS = [System.Drawing.Graphics]::FromImage($bmpS); $hdcS = $gS.GetHdc(); [void][NcPw]::PrintWindow($sp.Handle, $hdcS, 2); $gS.ReleaseHdc($hdcS); $gS.Dispose()
        }
        $dirS = Split-Path $shotPath -Parent
        if ($dirS) { New-Item -ItemType Directory -Path $dirS -Force | Out-Null }
        $bmpS.Save($shotPath, [System.Drawing.Imaging.ImageFormat]::Png)
        $bmpS.Dispose()
        Write-LogUi ("Splash screenshot saved: " + $shotPath)
        try { Close-NorcomSplash $sp } catch {}
        exit 0
      }
    } catch {
      Write-LogUi ('Splash shot failed: ' + $_.Exception.Message)
    }
  }
  $form.ShowInTaskbar = $false
  $form.StartPosition = 'Manual'
  $form.Location = New-Object System.Drawing.Point(-32000, -32000)
  $form.WindowState = 'Normal'
  if ($ScreenshotMode -eq 'Maximized') {
    $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
    $form.ClientSize = New-Object System.Drawing.Size($wa.Width, $wa.Height)
  } elseif ($ScreenshotMode -eq 'Compact') {
    $form.ClientSize = New-Object System.Drawing.Size(1000, 680)  # 1.0.30u Compact = MinimumSize
  } elseif ($ScreenshotMode -eq 'Medium') {
    $form.ClientSize = New-Object System.Drawing.Size(1440, 900)
  } else {
    $form.ClientSize = New-Object System.Drawing.Size(1100, 720)
  }
  try { $form.Opacity = 1 } catch {}
  try {
    $form.Show()
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 300
    # 1.0.30r: apply compact hero height before layout/capture
    try {
      if ($ScreenshotMode -eq 'Compact' -or $form.ClientSize.Height -lt 720) {
        if ($script:HeroPanel) { $script:HeroPanel.Height = 255; $script:NcHeroHeight = 255 }
      }
    } catch {}
    Update-LauncherHeroLayout
    try { Update-LauncherCardLayout } catch {}
    $shotPage = 'home'
    try { if ($env:NORCOM_SHOT_PAGE) { $shotPage = $env:NORCOM_SHOT_PAGE.Trim().ToLowerInvariant() } } catch {}
    try {
      $hook = Join-Path $ScriptDir 'screenshot-page.txt'
      if (Test-Path $hook) { $shotPage = (Get-Content $hook -Raw).Trim().ToLowerInvariant() }
    } catch {}
    try { Show-NorcomPage $shotPage } catch { try { Show-NorcomPage 'home' } catch { Update-LauncherCardLayout } }
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 250
    try { Update-LauncherCardLayout } catch {}
    try { Fit-ActionsLinks } catch {}
    try { Fit-PackRestartCard } catch {}
    try { Fit-NcMarkdownBox $script:CardNews } catch {}
    try { Fit-NcMarkdownBox $script:CardRules } catch {}
    [System.Windows.Forms.Application]::DoEvents()
    try { # 1.0.30d: do not BubbleRound StatusLabel - Clear(EffectiveBack) paints a dark strip under PLAY
  } catch {}
    $bmp = New-Object System.Drawing.Bitmap ([Math]::Max(100,$form.Width)), ([Math]::Max(100,$form.Height))
    Invoke-NcCapture $form $bmp
    $dir = Split-Path $shotPath -Parent
    if ($dir) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $bmp.Save($shotPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-LogUi ("Screenshot saved: " + $shotPath)
    try {
      if (-not ('NcPw' -as [type])) { Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class NcPw{[DllImport("user32.dll")]public static extern bool PrintWindow(IntPtr h,IntPtr dc,uint f);}' }
      $pb = New-Object System.Drawing.Bitmap $form.Width, $form.Height
      $g = [System.Drawing.Graphics]::FromImage($pb); $hdc = $g.GetHdc(); [void][NcPw]::PrintWindow($form.Handle, $hdc, 2); $g.ReleaseHdc($hdc); $g.Dispose()
      $pb.Save(($shotPath -replace '\.png$','-pw.png'), [System.Drawing.Imaging.ImageFormat]::Png); $pb.Dispose()
    } catch {}
    if ($env:NORCOM_LAUNCHER_SELFTEST) {
      $L = New-Object System.Collections.Generic.List[string]
      function LT([string]$n,[bool]$ok,[string]$d) { $L.Add(("{0}`t{1}`t{2}" -f $(if($ok){'PASS'}else{'FAIL'}),$n,$d)) }
      try {
        $card = $script:CardLinks; $cb = $card.ClientSize.Height
        try { Fit-ActionsLinks } catch {
          LT 'links:fit-ex' $false ($_.Exception.GetType().FullName + ': ' + $_.Exception.Message)
        }
        try {
          $script:CardLinks.PerformLayout()
          if ($script:LinksHost) { $script:LinksHost.PerformLayout() }
        } catch {}
        $ttl = $null; foreach ($c in $card.Controls) { if ($c.Name -eq 'CardTitle') { $ttl = $c } }
        # Skin/Browse live on Character tab; Discord may still be deferred
        $probe = @()
        foreach ($pair in @(@('Crash',$script:BtnCrash),@('Discord',$script:BtnDiscord),@('Voice',$script:BtnVoice),@('Shots',$script:BtnShots),@('Mods',$script:BtnMods))) {
          $nm=$pair[0]; $bx=$pair[1]
          if (-not $bx) { $probe += ($nm + '=null'); continue }
          try {
            $disposed = $bx.IsDisposed
            $par = if ($bx.Parent) { $bx.Parent.Name } else { 'noparent' }
            $probe += ('{0}:vis={1};disp={2};par={3};sz={4}x{5}' -f $nm, $bx.Visible, $disposed, $par, $bx.Width, $bx.Height)
          } catch { $probe += ($nm + '=err:' + $_.Exception.Message) }
        }
        $vis = @(@($script:BtnCrash, $script:BtnDiscord, $script:BtnVoice, $script:BtnShots, $script:BtnMods) | Where-Object { $_ -and $_.Visible })
        if ($vis.Count -eq 0) {
          LT 'links:fit' $false ('no visible action buttons | err=' + $script:LastActionsFitErr + ' | ' + ($probe -join ' | '))
        } else {
          $bots = @(); $tops = @()
          foreach ($b in $vis) {
            try {
              $pt = $card.PointToClient($b.Parent.PointToScreen($b.Location))
              $tops += $pt.Y; $bots += ($pt.Y + $b.Height)
            } catch {
              $tops += $b.Top; $bots += ($b.Top + $b.Height)
            }
          }          $maxB = ($bots | Measure-Object -Maximum).Maximum; $minT = ($tops | Measure-Object -Minimum).Minimum
          $titleBottom = if ($ttl) { $ttl.Bottom } else { 0 }
          $uniqTops = @($tops | Select-Object -Unique)
          $okFit = ($null -ne $maxB) -and ($maxB -le ($cb - 4)) -and ($minT -ge $titleBottom) -and ($uniqTops.Count -ge 2)
          LT 'links:fit' $okFit ("card h=$cb title bottom=$titleBottom btn top=$minT bottom=$maxB count=$($vis.Count) h=$($vis[0].Height) rows=$($uniqTops.Count)")
        }
        foreach ($k in @('CardCharacter','CardServer','CardNews','CardRules','CardLinks','CardPackRestart','CardSettings')) {
          $c = Get-Variable -Scope Script -Name $k -ValueOnly -EA SilentlyContinue
          if ($c) { $bad = @(); foreach ($x in $c.Controls) { if ($x.Visible -and ($x.Right -gt $c.ClientSize.Width -or $x.Bottom -gt $c.ClientSize.Height)) { $bad += ($x.GetType().Name + ':' + $x.Text) } }
            LT "card:$k inside" ($bad.Count -eq 0) ("size=$($c.ClientSize) " + ($bad -join ',')) }
        }
        $script:SelfTest = $true; $env:NORCOM_MOCK_MC_API = '1'
        try { if ($script:CardLinks) { $script:CardLinks.PerformLayout(); $script:CardLinks.GetType().GetMethod('OnResize',[Reflection.BindingFlags]'NonPublic,Instance').Invoke($script:CardLinks, @([EventArgs]::Empty)) } } catch {}
        if (-not $script:Calls) { $script:Calls = New-Object System.Collections.Generic.List[string] }
        LT 'character:card' ([bool]$script:CardCharacter) 'CardCharacter present'
        LT 'nav:home' ([bool]$script:NavHome) 'Nav Home'
        LT 'nav:character' ([bool]$script:NavCharacter) 'Nav Character'
        LT 'nav:settings' ([bool]$script:NavSettings) 'Nav Settings'
        LT 'page:character' ([bool]$script:PageCharacter) 'PageCharacter'
        LT 'creator:card' ([bool]$script:CharCreatorCard) 'Skin creator card'
        LT 'skin:default' (Test-Path (Join-Path $Assets 'skins\default-steve.png')) 'default-steve.png'
        try { Show-NorcomPage 'character'; [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 120 } catch {}
        LT 'character:page-visible' ([bool]($script:PageCharacter -and $script:PageCharacter.Visible)) 'Character page visible'
        try { Show-NorcomPage 'settings'; [System.Windows.Forms.Application]::DoEvents() } catch {}
        LT 'settings:page-visible' ([bool]($script:PageSettings -and $script:PageSettings.Visible)) 'Settings page visible'
        try { Show-NorcomPage 'home'; [System.Windows.Forms.Application]::DoEvents() } catch {}

        LT 'character:preview' ([bool]$script:SkinPreview) ('preview type=' + $(if($script:SkinPreview){$script:SkinPreview.GetType().Name}else{'null'}))
        LT 'anim:bg' ($script:UseAnimBg -eq $true) ('UseAnimBg=' + $script:UseAnimBg + ' enabled=' + $script:AnimBgEnabled)
        LT 'wordmark' ($script:HeroWordmark -and $script:HeroWordmark.Visible) 'neon wordmark visible'
        LT 'rules:easy' (([string]$script:RulesFullMd) -match '(?i)Easy|Survival' -and ([string]$script:RulesFullMd) -notmatch '(?i)Hardcore') ('snippet=' + (([string]$script:RulesFullMd).Substring(0, [Math]::Min(80,([string]$script:RulesFullMd).Length)) -replace "`r|`n",' '))
        # Mock Minecraft Services skin API (never hit live with token in self-test)
        function script:Invoke-McServices { param($Method,$Path,$Body,$ContentType); $script:Calls.Add('mcs:' + $Method + ':' + $Path); return @{ Status = 200; Body = '{"ok":true}' } }
        try {
          $tmpPng = Join-Path $env:TEMP 'norcom-selftest-skin.png'
          # minimal 64x64 PNG via .NET
          $bmp = New-Object System.Drawing.Bitmap 64,64
          $g = [System.Drawing.Graphics]::FromImage($bmp); $g.Clear([System.Drawing.Color]::Magenta); $g.Dispose()
          $bmp.Save($tmpPng, [System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
          $script:CharacterSkinPath = $tmpPng
          $r = Set-McSkin -PngPath $tmpPng -Variant 'classic'
          $st = 0; try { $st = [int]$r.Status } catch {}
          LT 'character:mock-apply' ($null -ne $r -and $st -eq 200) ("status=$st mock=$($r.Mock) calls=" + (($script:Calls -match '^mcs:') -join ','))
        } catch { LT 'character:mock-apply' $false $_.Exception.Message }
        foreach ($hostName in @('skindex.net','namemc.com','planetminecraft.com','api.minecraftservices.com')) {
          try {
            $dns = [System.Net.Dns]::GetHostAddresses($hostName)
            LT ("dns:" + $hostName) ($dns -and $dns.Count -gt 0) (($dns | Select-Object -First 1).IPAddressToString)
          } catch { LT ("dns:" + $hostName) $false $_.Exception.Message }
        }
        # idle CPU/RAM sample (best-effort)
        try {
          $p = Get-Process -Id $PID
          Start-Sleep -Milliseconds 200
          $cpu = $p.CPU
          $ram = [int]($p.WorkingSet64 / 1MB)
          LT 'perf:idle' ($ram -lt 900) ("cpuSec=$cpu ramMB=$ram")
        } catch { LT 'perf:idle' $true 'n/a' }
        if ($script:ChkAnimBg) {
          try { $script:ChkAnimBg.Checked = -not $script:ChkAnimBg.Checked; $script:ChkAnimBg.Checked = -not $script:ChkAnimBg.Checked; LT 'settings:anim-toggle' $true ('AnimBgEnabled=' + $script:AnimBgEnabled) } catch { LT 'settings:anim-toggle' $false $_.Exception.Message }
        }
        try { Set-RamPreset 'Balanced'; LT 'settings:ram-preset' ($script:RamSlider.Value -eq 6144) ("ram=" + $script:RamSlider.Value) } catch { LT 'settings:ram-preset' $false $_.Exception.Message }
        LT 'news:text' (([string]$script:NewsFullMd).Length -gt 0 -and $script:NewsBox -and $script:NewsBox.Text.Length -gt 0) ("full=$([string]$script:NewsFullMd.Length) preview=$($script:NewsBox.Text.Length)")
        LT 'rules:text' (([string]$script:RulesFullMd).Length -gt 0 -and $script:RulesBox -and $script:RulesBox.Text.Length -gt 0) ("full=$([string]$script:RulesFullMd.Length) preview=$($script:RulesBox.Text.Length)")
        $prev = $null; try { if ([System.Windows.Forms.Clipboard]::ContainsText()) { $prev = [System.Windows.Forms.Clipboard]::GetText() } } catch {}
        $script:BtnCopyAddr.PerformClick(); [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 50
        $got = ''
        try { $got = [System.Windows.Forms.Clipboard]::GetText() } catch {}
        if (-not $got) { $got = [string]$script:LastCopiedAddr }
        LT 'copy:address' ($got -eq $script:ServerAddrLabel.Text -or $got -eq $script:LastCopiedAddr) $got
        try { if ($prev) { [System.Windows.Forms.Clipboard]::SetText($prev) } else { [System.Windows.Forms.Clipboard]::Clear() } } catch {}
        LT 'startup:ms' $true ([string]$script:StartupSw.ElapsedMilliseconds)
        # ---- click smoke test: every button, with side effects stubbed ----
        $script:SelfTest = $true; $script:Calls = New-Object System.Collections.Generic.List[string]
        function script:Start-Process { $script:Calls.Add('open:' + ($args -join ' ')) }
        function script:Invoke-Play { $script:Calls.Add('play'); Set-ProgressBusy 'dry play'; Set-Progress 40; Set-Progress 0 }
        function script:Invoke-InstallOrSync { $script:Calls.Add('install'); Set-ProgressBusy 'dry install'; Set-Progress 60; Set-Progress 0 }
        function script:Invoke-VerifyAndRepair { $script:Calls.Add('repair'); Set-ProgressBusy 'dry repair'; Set-Progress 70; Set-Progress 0; return [pscustomobject]@{ level='green'; lines=@('dry-run') } }
        function script:Update-ProfileRam { $script:Calls.Add('ram:' + ($args -join ' ')) }
        $all = New-Object System.Collections.Generic.List[object]
        $walk = { param($c) foreach ($x in $c.Controls) { if ($x -is [System.Windows.Forms.Button]) { $all.Add($x) }; & $walk $x } }
        & $walk $form
        foreach ($b in $all) {
          $e0 = [int]$script:NcErrCount; $c0 = $script:Calls.Count; $err = ''
          if (-not $b.Visible) { LT ("click:'" + $b.Text + "'") $true 'hidden - skipped'; continue }
          try { $b.PerformClick(); [System.Windows.Forms.Application]::DoEvents() } catch { $err = $_.Exception.Message }
          $e1 = [int]$script:NcErrCount
          LT ("click:'" + $b.Text + "'") (-not $err -and $e1 -eq $e0) ("calls=" + (($script:Calls | Select-Object -Skip $c0) -join ',') + " status=" + $script:StatusLabel.Text + " " + $err + $(if($e1 -ne $e0){' (logged exception)'}))
        }
        try { $v = $script:RamSlider.Value; $script:RamSlider.Value = [Math]::Max($script:RamSlider.Minimum, $v - 1); $script:RamSlider.Value = $v; LT 'ram:slider' ($script:Calls -match '^ram').Count ("calls=" + (($script:Calls -match '^ram') -join ',')) } catch { LT 'ram:slider' $false $_.Exception.Message }
        foreach ($tk in @(@{n='ui-tick'; s={ $script:RestartCountdownLabel.Text = Get-NextRestartCountdownText }}, @{n='ping-tick(async)'; s={ $sw=[Diagnostics.Stopwatch]::StartNew(); Start-NorcomPingAsync; $c=$sw.ElapsedMilliseconds; while ($script:PingPs -and $sw.ElapsedMilliseconds -lt 8000) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 20 }; if ($c -gt 300) { throw "ping blocked UI $c ms" }; "start=$c ms, done=$($sw.ElapsedMilliseconds) ms, status=" + $script:ServerStatusLabel.Text }})) {
          try { $o = & $tk.s; LT $tk.n $true ([string]$o) } catch { LT $tk.n $false $_.Exception.Message } }
        foreach ($sz in @(@(900,640), @(1440,900), @(1100,720))) {
          try { $form.Size = New-Object System.Drawing.Size $sz[0], $sz[1]; $t0=[Diagnostics.Stopwatch]::StartNew(); while ($t0.ElapsedMilliseconds -lt 250) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 15 }; LT ("resize:" + ($sz -join 'x')) ([int]$script:NcErrCount -eq 0) '' } catch { LT 'resize' $false $_.Exception.Message } }
        LT 'taskbar:flags' ($form.MinimizeBox -and $form.Icon -ne $null -and ('NorcomUi.ShortcutAumid' -as [type])) 'MinimizeBox, Icon, AUMID helper loaded (off-screen ShowInTaskbar=false by design)'
        LT 'errors:total' ([int]$script:NcErrCount -eq 0) ("NcErrCount=" + [int]$script:NcErrCount)
        # --- Fix NORCOM / self-heal self-tests ---
        try {
          LT 'fix:button' ([bool]$script:BtnFixNorcom) ('BtnFixNorcom text=' + $(if($script:BtnFixNorcom){$script:BtnFixNorcom.Text}else{'null'}))
          $probeDir = Join-Path $env:TEMP ('norcom-fix-probe-' + $PID)
          New-Item -ItemType Directory -Path $probeDir,(Join-Path $probeDir 'tools'),(Join-Path $probeDir 'assets') -Force | Out-Null
          [IO.File]::WriteAllText((Join-Path $probeDir 'Launcher.ps1'), '# keep')
          [IO.File]::WriteAllText((Join-Path $probeDir 'NORCOM-Launcher.ps1'), '# keep')
          [IO.File]::WriteAllText((Join-Path $probeDir 'assets\skins-keep.txt'), 'skin')
          [IO.File]::WriteAllText((Join-Path $probeDir 'settings.json'), '{"keep":true}')
          [IO.File]::WriteAllText((Join-Path $probeDir 'Launcher.ps1.bak1030v'), 'stale')
          [IO.File]::WriteAllText((Join-Path $probeDir 'NORCOM-Launcher.ps1.pre-diag'), 'stale')
          [IO.File]::WriteAllText((Join-Path $probeDir 'NORCOM-Launcher.ps1.pre-diag4'), 'stale')
          [IO.File]::WriteAllText((Join-Path $probeDir 'tools\NorcomUi.cs'), '# keep ui')
          [IO.File]::WriteAllText((Join-Path $probeDir 'tools\NorcomUi.cs.bak-v33-test'), 'stale')
          $oldScope = $script:NcSelfDir
          $script:NcSelfDir = $probeDir
          $rm = Clear-NorcomStaleLauncherFiles -Dir $probeDir
          $script:NcSelfDir = $oldScope
          $keptLauncher = Test-Path (Join-Path $probeDir 'Launcher.ps1')
          $keptUi = Test-Path (Join-Path $probeDir 'tools\NorcomUi.cs')
          $keptSkin = Test-Path (Join-Path $probeDir 'assets\skins-keep.txt')
          $keptSettings = Test-Path (Join-Path $probeDir 'settings.json')
          $goneBak = -not (Test-Path (Join-Path $probeDir 'Launcher.ps1.bak1030v'))
          $goneDiag = -not (Test-Path (Join-Path $probeDir 'NORCOM-Launcher.ps1.pre-diag4'))
          $goneUiBak = -not (Test-Path (Join-Path $probeDir 'tools\NorcomUi.cs.bak-v33-test'))
          LT 'fix:cleanup-safe' ($keptLauncher -and $keptUi -and $keptSkin -and $keptSettings -and $goneBak -and $goneDiag -and $goneUiBak) ("removed=$($rm.Count) keptL=$keptLauncher keptUi=$keptUi keptSkin=$keptSkin keptSettings=$keptSettings goneBak=$goneBak goneDiag=$goneDiag goneUiBak=$goneUiBak")
          try { Remove-Item -LiteralPath $probeDir -Recurse -Force -EA SilentlyContinue } catch {}
        } catch { LT 'fix:cleanup-safe' $false $_.Exception.Message }
        try {
          Clear-NorcomActivateAck
          $since = [DateTime]::UtcNow
          Write-NorcomActivateAck
          $okAck = Test-NorcomActivateAckRecent -NotBeforeUtc $since
          LT 'selfheal:activate-ack' $okAck ('ack path=' + (Get-NorcomActivateAckPath))
        } catch { LT 'selfheal:activate-ack' $false $_.Exception.Message }
        try {
          $or = @(Get-NorcomLauncherOrphanProcesses)
          $badJava = @($or | Where-Object { Test-NorcomProcessIsMinecraftJava -Name $_.Name -CommandLine $_.CommandLine })
          LT 'selfheal:orphan-scope' ($badJava.Count -eq 0) ("orphans=$($or.Count) javaHits=$($badJava.Count) scope=$($script:NcSelfDir)")
        } catch { LT 'selfheal:orphan-scope' $false $_.Exception.Message }
        try {
          if (-not $script:Calls) { $script:Calls = New-Object System.Collections.Generic.List[string] }
          try { Show-NorcomPage 'settings'; [System.Windows.Forms.Application]::DoEvents() } catch {}
          if ($script:BtnFixNorcom) { $script:BtnFixNorcom.PerformClick() }
          LT 'crash:helpers' ([bool](Get-Command Send-NorcomCrashReport -EA SilentlyContinue)) 'Send-NorcomCrashReport present'

        LT 'fix:click-dry' ($script:Calls -contains 'fix-norcom') ('calls=' + ($script:Calls -join ','))
        } catch { LT 'fix:click-dry' $false $_.Exception.Message }
      } catch { LT 'selftest:error' $false $_.Exception.Message }
      [IO.File]::WriteAllLines($env:NORCOM_LAUNCHER_SELFTEST, $L)
    }
  } catch {
    Write-LogUi ("Screenshot failed: " + $_.Exception.Message)
    try { [IO.File]::WriteAllText(($shotPath + '.err.txt'), $_.Exception.ToString()) } catch {}
  } finally {
    try { $form.Close() } catch {}
  }
  return
}

if ($ScreenshotMode -eq 'Maximized') { $form.WindowState = 'Maximized' }
elseif ($ScreenshotMode -eq 'Windowed') {
  $form.WindowState = 'Normal'
  $form.ClientSize = New-Object System.Drawing.Size(1100, 720)
  $form.StartPosition = 'CenterScreen'
}

# 1.0.32: Application.Run (not ShowDialog). Hide-to-tray must not end the UI loop.
# Also mark UI ready after Shown and watchdog-force visible if a spurious close hid us.
$script:NcUiReady = $false
$form.Add_Shown({
  try {
    $script:NcUiReady = $true
    Write-NcStartupLog ('ui ready Visible=' + $form.Visible + ' State=' + $form.WindowState)
    if (-not $form.Visible) {
      $form.Visible = $true
      $form.ShowInTaskbar = $true
      $form.WindowState = 'Normal'
      $form.Activate()
      Write-NcStartupLog 'ui ready: forced Visible=true'
    }
  } catch {}
  try {
    $wd = New-Object System.Windows.Forms.Timer
    $wd.Interval = 900
    $script:NcVisWatchN = 0
    $wd.Add_Tick({
      try {
        $script:NcVisWatchN++
        if ($script:NcVisWatchN -gt 8) { $wd.Stop(); return }
        if ($script:ForceClose) { $wd.Stop(); return }
        if ($form -and -not $form.IsDisposed -and -not $form.Visible) {
          $traying = $false
          try { if ($script:TrayIcon -and $script:TrayIcon.Visible) { $traying = $true } } catch {}
          if (-not $traying) {
            Write-NcStartupLog ('visibility watchdog #' + $script:NcVisWatchN + ': restoring')
            $form.Visible = $true
            $form.ShowInTaskbar = $true
            $form.WindowState = 'Normal'
            $form.Show()
            $form.Activate()
          }
        }
      } catch {}
    })
    $wd.Start()
    $script:NcVisWatch = $wd
  } catch {}
})
try { $form.ResumeLayout($true) } catch {}
try {
  # Finalize geometry before the message loop (solid opaque).
  $hh0 = [int](210 * (Get-UiScale))
  if ($hh0 -lt 190) { $hh0 = 190 }
  if ($hh0 -gt 300) { $hh0 = 300 }
  if ((Get-UiScale) -ge 1.35) { $hh0 = [Math]::Min(420, [int](235 * (Get-UiScale))) }
  if ($script:MainForm -and $script:MainForm.ClientSize.Height -lt 720) { $hh0 = 255 }
  if ($script:HeroPanel) { $script:HeroPanel.Height = $hh0 }
  $script:NcHeroHeight = $hh0
  try { Update-LauncherHeroLayout } catch {}
  try { Update-LauncherCardLayout } catch {}
  try { $form.PerformLayout() } catch {}
  Write-NcStartupLog 'clean-startup: pre-run layout done'
} catch { try { Write-NcStartupLog ('clean-startup: pre-run layout ' + $_.Exception.Message) } catch {} }

try {
  if ($env:NORCOM_OFFSCREEN -eq '1') {
    $form.StartPosition = 'Manual'
    $form.Location = New-Object System.Drawing.Point(-32000, -32000)
    Write-NcStartupLog 'clean-startup: NORCOM_OFFSCREEN park at -32000,-32000'
  }
} catch {}

try { Write-NcStartupLog 'clean-startup: entering Application.Run at Opacity=0 (hold until first frame)' } catch {}
try { $form.BackColor = [System.Drawing.Color]::FromArgb(6, 10, 28) } catch {}
try { $form.Opacity = 0 } catch {}
try { Enable-NorcomComposited $form } catch {}
try { Enable-NorcomSmoothPaint $form } catch {}
try { if ($script:RootPanel) { Enable-NorcomSmoothPaint $script:RootPanel; $script:RootPanel.BackColor = [System.Drawing.Color]::FromArgb(6, 10, 28) } } catch {}
# SETREDRAW hold: only works if handle already exists; HandleCreated also holds
try { Set-NorcomRedraw $form $false } catch {}
try { Write-NcStartupLog 'clean-startup: pre-Run hold (Opacity=0)' } catch {}

[void][System.Windows.Forms.Application]::Run($form)













