@echo off
title NORCOM Installer
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0NORCOM-Launcher.ps1" %*
