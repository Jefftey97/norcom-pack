' NORCOM Launcher - fallback if exe stub missing
Option Explicit
Dim sh, fso, dir, ps1, cmd, stub
Set sh = CreateObject("Wscript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
stub = dir & "\NORCOM Launcher.exe"
If fso.FileExists(stub) Then
  sh.Run """" & stub & """", 1, False
Else
  ps1 = dir & "\NORCOM-Launcher.ps1"
  cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File """ & ps1 & """"
  sh.Run cmd, 0, False
End If
