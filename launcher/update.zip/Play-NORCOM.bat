@echo off
title NORCOM
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0NORCOM-Launcher.ps1" -SilentSync
