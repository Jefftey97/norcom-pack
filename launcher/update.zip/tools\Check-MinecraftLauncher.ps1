$ErrorActionPreference = 'Stop'
function Find-Mc {
  $paths = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Minecraft Launcher\MinecraftLauncher.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\Minecraft Launcher\MinecraftLauncher.exe'),
    (Join-Path $env:ProgramFiles 'Minecraft Launcher\MinecraftLauncher.exe'),
    'C:\XboxGames\Minecraft Launcher\Content\Minecraft.exe',
    'C:\XboxGames\Minecraft Launcher\Content\gamelaunchhelper.exe'
  )
  foreach ($p in $paths) { if ($p -and (Test-Path -LiteralPath $p)) { return $true } }
  try { if (Get-AppxPackage -Name 'Microsoft.4297127D64EC6' -EA SilentlyContinue) { return $true } } catch {}
  return $false
}
if ($env:NORCOM_TEST -eq '1') {
  if (Find-Mc) { Write-Output 'MC_OK'; exit 0 }
  Write-Output 'MC_MISSING'
  exit 0
}
Add-Type -AssemblyName System.Windows.Forms | Out-Null
if (Find-Mc) { exit 0 }
$url = 'https://www.minecraft.net/en-us/download'
$r = [System.Windows.Forms.MessageBox]::Show(
  "NORCOM needs the official Minecraft Java Launcher installed, and you should log in once.`r`n`r`nNot Minecraft Bedrock / 'Minecraft for Windows'.`r`n`r`nOpen the official download page now?`r`n$url",
  'NORCOM - Minecraft Launcher required',
  'YesNo',
  'Information'
)
if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { Start-Process $url }
exit 0