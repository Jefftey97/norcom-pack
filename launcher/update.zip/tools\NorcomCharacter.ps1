#Requires -Version 5.1
# NORCOM Character panel helpers — Minecraft Services skin/cape API.
# Access tokens are read from the official launcher account store only.
# NEVER log, print, or persist the raw token. Self-test must mock the API.

$script:NcSkinSites = @(
  [pscustomobject]@{ Name = 'The Skindex'; Url = 'https://www.minecraftskins.com/' },
  [pscustomobject]@{ Name = 'NameMC'; Url = 'https://namemc.com/minecraft-skins' },
  [pscustomobject]@{ Name = 'Planet Minecraft'; Url = 'https://www.planetminecraft.com/skins/' }
)

function Get-NorcomSkinsLibraryDir {
  $d = Join-Path $GameDir 'norcom-skins'
  if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
  return $d
}

function Get-MinecraftLauncherAccountsPath {
  $cands = @(
    (Join-Path $env:APPDATA '.minecraft\launcher_accounts.json'),
    (Join-Path $env:APPDATA 'Minecraft Launcher\launcher_accounts.json'),
    (Join-Path $env:LOCALAPPDATA 'Packages\Microsoft.MinecraftUWP_8wekyb3d8bbwe\LocalCache\minecraftpe\launcher_accounts.json'),
    (Join-Path $McDir 'launcher_accounts.json')
  )
  foreach ($p in $cands) { if ($p -and (Test-Path -LiteralPath $p)) { return $p } }
  return $null
}

function Get-MinecraftAccessToken {
  # Returns @{ token=...; name=...; id=... } or $null. Token must not be logged.
  if ($script:SelfTest -or $env:NORCOM_MOCK_MC_API) {
    return @{ token = 'MOCK_TOKEN'; name = 'Steve'; id = '00000000000000000000000000000000'; mock = $true }
  }
  $path = Get-MinecraftLauncherAccountsPath
  if (-not $path) { return $null }
  try {
    $raw = [IO.File]::ReadAllText($path)
    $j = $raw | ConvertFrom-Json
    $accounts = @()
    if ($j.accounts) {
      $j.accounts.PSObject.Properties | ForEach-Object { $accounts += $_.Value }
    } elseif ($j.PSObject.Properties['mojang-accounts']) {
      # legacy shapes ignored
    }
    $best = $null
    foreach ($a in $accounts) {
      $tok = $null
      try { $tok = [string]$a.accessToken } catch {}
      if (-not $tok) { try { $tok = [string]$a.accessToken } catch {} }
      if (-not $tok) { continue }
      $name = $null; $id = $null
      try { if ($a.minecraftProfile) { $name = [string]$a.minecraftProfile.name; $id = [string]$a.minecraftProfile.id } } catch {}
      if (-not $name) { try { $name = [string]$a.localId } catch {} }
      $active = $false
      try { if ($j.activeAccountLocalId -and $a.localId -eq $j.activeAccountLocalId) { $active = $true } } catch {}
      $entry = @{ token = $tok; name = $name; id = $id }
      if ($active) { return $entry }
      if (-not $best) { $best = $entry }
    }
    return $best
  } catch {
    Write-LogUi 'Character: could not read launcher accounts (no token details logged)'
    return $null
  }
}

function Invoke-McServices {
  param(
    [Parameter(Mandatory)][string]$Method,
    [Parameter(Mandatory)][string]$Url,
    [hashtable]$Headers = @{},
    [byte[]]$BodyBytes = $null,
    [string]$ContentType = $null,
    [string]$FilePath = $null,
    [string]$Variant = $null
  )
  if ($script:SelfTest -or $env:NORCOM_MOCK_MC_API) {
    return @{ Status = 200; Body = '{"id":"00000000000000000000000000000000","name":"Steve","skins":[{"id":"1","state":"ACTIVE","url":"https://example.invalid/skin.png","variant":"CLASSIC"}],"capes":[]}'; Mock = $true }
  }
  $acc = Get-MinecraftAccessToken
  if (-not $acc -or -not $acc.token) { return @{ Status = 401; Body = 'Not signed in to Minecraft Launcher'; Error = 'auth' } }
  try {
    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.Method = $Method
    $req.UserAgent = 'NORCOM-Launcher/1.0'
    $req.Timeout = 20000
    $req.Headers.Add('Authorization', ('Bearer ' + $acc.token))
    foreach ($k in $Headers.Keys) { $req.Headers[$k] = [string]$Headers[$k] }
    if ($FilePath -and $Method -eq 'POST') {
      $boundary = '----NorcomSkin' + [guid]::NewGuid().ToString('N')
      $req.ContentType = "multipart/form-data; boundary=$boundary"
      $fs = [IO.File]::ReadAllBytes($FilePath)
      $head = [Text.Encoding]::UTF8.GetBytes("--$boundary`r`nContent-Disposition: form-data; name=`"variant`"`r`n`r`n$Variant`r`n--$boundary`r`nContent-Disposition: form-data; name=`"file`"; filename=`"skin.png`"`r`nContent-Type: image/png`r`n`r`n")
      $tail = [Text.Encoding]::UTF8.GetBytes("`r`n--$boundary--`r`n")
      $req.ContentLength = $head.Length + $fs.Length + $tail.Length
      $s = $req.GetRequestStream()
      $s.Write($head, 0, $head.Length); $s.Write($fs, 0, $fs.Length); $s.Write($tail, 0, $tail.Length); $s.Close()
    } elseif ($null -ne $BodyBytes) {
      if ($ContentType) { $req.ContentType = $ContentType }
      $req.ContentLength = $BodyBytes.Length
      $s = $req.GetRequestStream(); $s.Write($BodyBytes, 0, $BodyBytes.Length); $s.Close()
    }
    try {
      $resp = $req.GetResponse()
      $sr = New-Object IO.StreamReader($resp.GetResponseStream())
      $body = $sr.ReadToEnd(); $sr.Close()
      $code = [int]$resp.StatusCode
      $resp.Close()
      return @{ Status = $code; Body = $body }
    } catch [System.Net.WebException] {
      $ex = $_.Exception
      $code = 0; $body = $ex.Message
      if ($ex.Response) {
        $code = [int]$ex.Response.StatusCode
        try { $sr = New-Object IO.StreamReader($ex.Response.GetResponseStream()); $body = $sr.ReadToEnd(); $sr.Close() } catch {}
      }
      return @{ Status = $code; Body = $body; Error = 'http' }
    }
  } catch {
    return @{ Status = 0; Body = $_.Exception.Message; Error = 'offline' }
  }
}

function Get-McProfile {
  $r = Invoke-McServices -Method GET -Url 'https://api.minecraftservices.com/minecraft/profile'
  return $r
}

function Set-McSkin {
  param([Parameter(Mandatory)][string]$PngPath, [ValidateSet('classic','slim')][string]$Variant = 'classic')
  if ($script:SelfTest) {
    return @{ Status = 200; Body = '{"ok":true}'; Mock = $true }
  }
  return Invoke-McServices -Method POST -Url 'https://api.minecraftservices.com/minecraft/profile/skins' -FilePath $PngPath -Variant $Variant.ToUpperInvariant()
}

function Set-McCapeActive {
  param([string]$CapeId)
  if (-not $CapeId) {
    return Invoke-McServices -Method DELETE -Url 'https://api.minecraftservices.com/minecraft/profile/capes/active'
  }
  $json = (@{ capeId = $CapeId } | ConvertTo-Json -Compress)
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  return Invoke-McServices -Method PUT -Url 'https://api.minecraftservices.com/minecraft/profile/capes/active' -BodyBytes $bytes -ContentType 'application/json'
}

function Test-NorcomSkinPng {
  param([Parameter(Mandatory)][string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { return @{ Ok = $false; Error = 'File not found' } }
  $fi = Get-Item -LiteralPath $Path
  if ($fi.Length -gt (24 * 1024)) { return @{ Ok = $false; Error = 'Skin must be under 24 KB' } }
  try {
    $img = [System.Drawing.Image]::FromFile($Path)
    try {
      $w = $img.Width; $h = $img.Height
      if (-not (($w -eq 64 -and $h -eq 64) -or ($w -eq 64 -and $h -eq 32))) {
        return @{ Ok = $false; Error = "Skin must be 64x64 or 64x32 PNG (got ${w}x${h})" }
      }
      if ($img.RawFormat.Guid -ne [System.Drawing.Imaging.ImageFormat]::Png.Guid) {
        # allow files that open as PNG-like
      }
      return @{ Ok = $true; Width = $w; Height = $h }
    } finally { $img.Dispose() }
  } catch {
    return @{ Ok = $false; Error = 'Not a valid PNG image' }
  }
}

function Save-NorcomSkinToLibrary {
  param([Parameter(Mandatory)][string]$Path)
  $dir = Get-NorcomSkinsLibraryDir
  $name = [IO.Path]::GetFileNameWithoutExtension($Path)
  $safe = ($name -replace '[^a-zA-Z0-9_\-]','_')
  if (-not $safe) { $safe = 'skin' }
  $dest = Join-Path $dir ($safe + '.png')
  $i = 1
  while (Test-Path -LiteralPath $dest) {
    $dest = Join-Path $dir ($safe + "-$i.png"); $i++
  }
  Copy-Item -LiteralPath $Path -Destination $dest -Force
  return $dest
}

function Get-NorcomSavedSkins {
  $dir = Get-NorcomSkinsLibraryDir
  @(Get-ChildItem -LiteralPath $dir -Filter '*.png' -EA SilentlyContinue | Sort-Object LastWriteTime -Descending)
}

function Show-NorcomBrowseOutfitsMenu {
  param($anchor)
  $cm = New-Object System.Windows.Forms.ContextMenuStrip
  try { $cm.BackColor = [System.Drawing.Color]::FromArgb(14, 20, 42); $cm.ForeColor = [System.Drawing.Color]::FromArgb(235,245,255) } catch {}
  foreach ($site in $script:NcSkinSites) {
    $item = New-Object System.Windows.Forms.ToolStripMenuItem $site.Name
    $url = $site.Url
    $item.Add_Click({ param($s,$e) try { Start-Process $url } catch {} }.GetNewClosure())
    [void]$cm.Items.Add($item)
  }
  if ($anchor) {
    $cm.Show($anchor, (New-Object System.Drawing.Point 0, $anchor.Height))
  } else {
    $cm.Show([System.Windows.Forms.Cursor]::Position)
  }
}

function Get-DownloadsFolder {
  try {
    $p = [Environment]::GetFolderPath('UserProfile')
    $d = Join-Path $p 'Downloads'
    if (Test-Path -LiteralPath $d) { return $d }
  } catch {}
  return [Environment]::GetFolderPath('MyDocuments')
}

function Select-NorcomSkinPng {
  $dlg = New-Object System.Windows.Forms.OpenFileDialog
  $dlg.Title = 'Choose a Minecraft skin PNG'
  $dlg.Filter = 'Skin PNG (*.png)|*.png'
  $dlg.InitialDirectory = Get-DownloadsFolder
  $dlg.CheckFileExists = $true
  if ($script:SelfTest) { return $null }
  if ($dlg.ShowDialog() -eq 'OK') { return $dlg.FileName }
  return $null
}

function Start-NorcomDownloadsSkinWatch {
  # Optional: watch Downloads for a new 64x64/64x32 skin PNG and offer to use it.
  try {
    if ($script:DlWatcher) { return }
    $dir = Get-DownloadsFolder
    if (-not (Test-Path -LiteralPath $dir)) { return }
    $w = New-Object IO.FileSystemWatcher $dir, '*.png'
    $w.IncludeSubdirectories = $false
    $w.EnableRaisingEvents = $true
    $script:DlWatcher = $w
    $handler = {
      param($s,$e)
      try {
        Start-Sleep -Milliseconds 400
        $path = $e.FullPath
        if (-not (Test-Path -LiteralPath $path)) { return }
        $check = Test-NorcomSkinPng -Path $path
        if (-not $check.Ok) { return }
        $script:PendingDownloadedSkin = $path
        if ($script:MainForm -and $script:MainForm.IsHandleCreated) {
          $script:MainForm.BeginInvoke([action]{
            try {
              if (-not $script:PendingDownloadedSkin) { return }
              $p = $script:PendingDownloadedSkin; $script:PendingDownloadedSkin = $null
              $r = Show-NcMsg @("Use the skin you just downloaded?`n`n$([IO.Path]::GetFileName($p))", 'NORCOM Skin', 'YesNo', 'Question')
              if ($r -eq [System.Windows.Forms.DialogResult]::Yes) {
                Import-NorcomCharacterSkin -Path $p
              }
            } catch {}
          }) | Out-Null
        }
      } catch {}
    }
    Register-ObjectEvent -InputObject $w -EventName Created -Action $handler | Out-Null
    Register-ObjectEvent -InputObject $w -EventName Renamed -Action $handler | Out-Null
  } catch {}
}

function Import-NorcomCharacterSkin {
  param([Parameter(Mandatory)][string]$Path)
  $check = Test-NorcomSkinPng -Path $Path
  if (-not $check.Ok) {
    (Show-NcMsg @($check.Error, 'Skin', 'OK', 'Warning')) | Out-Null
    return $false
  }
  $lib = Save-NorcomSkinToLibrary -Path $Path
  $script:CharacterSkinPath = $lib
  try {
    $bmp = [System.Drawing.Bitmap]::FromFile($lib)
    if ($script:SkinPreview) { $script:SkinPreview.SetSkin($bmp, [bool]$script:CharacterSlim) }
    $bmp.Dispose()
  } catch {}
  try { Update-NorcomSavedSkinThumbs } catch {}
  Set-Status ('Skin loaded: ' + [IO.Path]::GetFileName($lib))
  return $true
}

function Format-McApiError($r) {
  if (-not $r) { return 'Unknown error' }
  switch ([int]$r.Status) {
    401 { return 'Not signed in. Open Minecraft Launcher and sign in, then try again.' }
    429 { return 'Rate limited by Mojang. Wait a minute and try again.' }
    0   { return 'Offline or network error. Check your connection.' }
    default { return ("Error $($r.Status): " + ([string]$r.Body).Substring(0, [Math]::Min(180, ([string]$r.Body).Length))) }
  }
}

function Get-NorcomDefaultSkinPath {
  param([switch]$Slim)
  $name = if ($Slim) { 'default-alex.png' } else { 'default-steve.png' }
  foreach ($base in @($Assets, (Join-Path $ScriptDir 'assets'), $ScriptDir)) {
    if (-not $base) { continue }
    $p = Join-Path $base ('skins\' + $name)
    if (Test-Path -LiteralPath $p) { return $p }
    $p2 = Join-Path $base $name
    if (Test-Path -LiteralPath $p2) { return $p2 }
  }
  return $null
}

function Get-NorcomSkinUrlFromProfileBody([string]$body) {
  try {
    $pj = $body | ConvertFrom-Json
    if ($pj.skins) {
      foreach ($s in @($pj.skins)) {
        if ([string]$s.state -eq 'ACTIVE' -and $s.url) { return [string]$s.url }
      }
      foreach ($s in @($pj.skins)) { if ($s.url) { return [string]$s.url } }
    }
  } catch {}
  return $null
}

function Get-NorcomSkinUrlByUsername([string]$name) {
  if (-not $name) { return $null }
  if ($script:SelfTest -or $env:NORCOM_MOCK_MC_API) { return $null }
  try {
    $uuidJson = Invoke-RestMethod -Uri ("https://api.mojang.com/users/profiles/minecraft/" + [uri]::EscapeDataString($name)) -TimeoutSec 8 -UserAgent 'NORCOM-Launcher/1.0.28'
    $id = [string]$uuidJson.id
    if (-not $id) { return $null }
    $prof = Invoke-RestMethod -Uri ("https://sessionserver.mojang.com/session/minecraft/profile/" + $id) -TimeoutSec 8 -UserAgent 'NORCOM-Launcher/1.0.28'
    foreach ($p in @($prof.properties)) {
      if ($p.name -eq 'textures') {
        $raw = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String([string]$p.value))
        $tj = $raw | ConvertFrom-Json
        $u = $null
        try { $u = [string]$tj.textures.SKIN.url } catch {}
        if ($u) { return $u }
      }
    }
  } catch {}
  return $null
}

function Import-NorcomSkinFromUrl {
  param([Parameter(Mandatory)][string]$Url)
  if ($script:SelfTest -or $env:NORCOM_MOCK_MC_API) { return $false }
  try {
    $tmp = Join-Path $env:TEMP ('norcom-skin-' + [guid]::NewGuid().ToString('N') + '.png')
    Invoke-WebRequest -Uri $Url -OutFile $tmp -UseBasicParsing -TimeoutSec 20
    $ok = Import-NorcomCharacterSkin -Path $tmp
    Remove-Item $tmp -Force -EA SilentlyContinue
    return [bool]$ok
  } catch { return $false }
}

function Initialize-NorcomCharacterPreview {
  # Prefer current account skin; else username textures; else built-in Steve/Alex.
  try {
    $acc = Get-MinecraftAccessToken
    $loaded = $false
    $prof = Get-McProfile
    if ($prof -and [int]$prof.Status -eq 200 -and $prof.Body) {
      $url = Get-NorcomSkinUrlFromProfileBody $prof.Body
      if ($url) { $loaded = Import-NorcomSkinFromUrl -Url $url }
      try {
        $pj = $prof.Body | ConvertFrom-Json
        if ($pj.name) { Set-Status ('Signed in as ' + $pj.name) }
      } catch {}
    }
    if (-not $loaded -and $acc -and $acc.name) {
      $url2 = Get-NorcomSkinUrlByUsername -name ([string]$acc.name)
      if ($url2) { $loaded = Import-NorcomSkinFromUrl -Url $url2 }
    }
    if (-not $loaded) {
      $def = Get-NorcomDefaultSkinPath -Slim:([bool]$script:CharacterSlim)
      if ($def) {
        $script:CharacterSkinPath = $def
        try {
          $bmp = [System.Drawing.Bitmap]::FromFile($def)
          if ($script:SkinPreview -and $script:SkinPreview.PSObject.Methods['SetSkin']) {
            $script:SkinPreview.SetSkin($bmp, [bool]$script:CharacterSlim)
          } elseif ($script:SkinPreview -and $script:SkinPreview.GetType().Name -eq 'SkinPreview3D') {
            $script:SkinPreview.SetSkin($bmp, [bool]$script:CharacterSlim)
          } elseif ($script:SkinPreview) {
            $script:SkinPreview.Image = $bmp
          } else { $bmp.Dispose() }
          if ($bmp -and $script:SkinPreview -and $script:SkinPreview.GetType().Name -eq 'SkinPreview3D') { $bmp.Dispose() }
        } catch {}
        Set-Status 'Default skin loaded (offline)'
      }
    }
  } catch {}
}

function New-NorcomGeneratedSkin {
  param(
    [System.Drawing.Color]$Tone,
    [System.Drawing.Color]$Hair,
    [System.Drawing.Color]$Eyes,
    [System.Drawing.Color]$Shirt,
    [System.Drawing.Color]$Pants,
    [System.Drawing.Color]$Accent,
    [bool]$Slim = $false,
    [string]$HairStyle = 'short',
    [string]$EyeStyle = 'dot',
    [string]$ShirtStyle = 'tee',
    [string]$PantsStyle = 'pants',
    [string]$ShoeStyle = 'sneakers',
    [string]$Accessory = 'none'
  )
  $bmp = New-Object System.Drawing.Bitmap 64, 64, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.Clear([System.Drawing.Color]::Transparent)
  function Fill([int]$x1,[int]$y1,[int]$x2,[int]$y2, [System.Drawing.Color]$c) {
    if ($x2 -lt $x1 -or $y2 -lt $y1) { return }
    $br = New-Object System.Drawing.SolidBrush $c
    $g.FillRectangle($br, $x1, $y1, ($x2 - $x1 + 1), ($y2 - $y1 + 1))
    $br.Dispose()
  }
  function Darken([System.Drawing.Color]$c, [double]$f) {
    return [System.Drawing.Color]::FromArgb($c.A, [int]([Math]::Max(0,[Math]::Min(255,$c.R * $f))), [int]([Math]::Max(0,[Math]::Min(255,$c.G * $f))), [int]([Math]::Max(0,[Math]::Min(255,$c.B * $f))))
  }
  $aw = if ($Slim) { 3 } else { 4 }
  $hs = ($HairStyle + '').ToLowerInvariant()
  $es = ($EyeStyle + '').ToLowerInvariant()
  $ss = ($ShirtStyle + '').ToLowerInvariant()
  $ps = ($PantsStyle + '').ToLowerInvariant()
  $sh = ($ShoeStyle + '').ToLowerInvariant()
  $acc = ($Accessory + '').ToLowerInvariant()
  # Head base
  Fill 8 0 15 7 $Tone
  Fill 16 0 23 7 $Tone
  Fill 0 8 7 15 $Tone
  Fill 8 8 15 15 $Tone
  Fill 16 8 23 15 $Tone
  Fill 24 8 31 15 $Tone
  # Hair styles (layer 1 + hat layer 2 when accessory)
  switch ($hs) {
    'buzz' { Fill 8 8 15 9 $Hair; Fill 24 8 31 9 $Hair }
    'long' {
      Fill 8 0 15 7 $Hair; Fill 8 8 15 12 $Hair; Fill 24 8 31 12 $Hair
      Fill 0 8 2 14 $Hair; Fill 29 8 31 14 $Hair
    }
    'mohawk' {
      Fill 10 0 13 7 $Hair; Fill 10 8 13 10 $Hair
      Fill 26 0 29 7 $Hair; Fill 26 8 29 10 $Hair
    }
    default { # short
      Fill 8 0 15 7 $Hair; Fill 8 8 15 10 $Hair
      Fill 24 8 31 10 $Hair
    }
  }
  # Eyes
  switch ($es) {
    'wide' { Fill 9 11 11 13 $Eyes; Fill 12 11 14 13 $Eyes }
    'happy' { Fill 10 12 11 12 $Eyes; Fill 13 12 14 12 $Eyes; Fill 10 13 14 13 (Darken $Eyes 0.6) }
    'glow' {
      $glow = [System.Drawing.Color]::FromArgb(255, 0, 229, 255)
      Fill 10 11 11 13 $glow; Fill 13 11 14 13 $glow
    }
    default { Fill 10 12 11 12 $Eyes; Fill 13 12 14 12 $Eyes }
  }
  # Body / shirt styles
  $body = $Shirt
  $sleeve = Darken $Shirt 0.85
  if ($ss -eq 'hoodie') {
    Fill 20 16 27 19 (Darken $Shirt 0.75)
    Fill 16 20 19 31 $sleeve; Fill 20 20 27 31 $body; Fill 28 20 31 31 $sleeve; Fill 32 20 39 31 (Darken $Shirt 0.7)
    Fill 20 16 27 18 $Accent  # hood trim
  } elseif ($ss -eq 'jacket') {
    Fill 20 16 27 19 $Accent
    Fill 16 20 19 31 $Accent; Fill 20 20 27 31 $body; Fill 28 20 31 31 $Accent; Fill 32 20 39 31 (Darken $Accent 0.75)
    Fill 23 20 24 31 $Accent # zipper
  } else { # tee
    Fill 20 16 27 19 $body
    Fill 28 16 35 19 (Darken $Shirt 0.7)
    Fill 16 20 19 31 $sleeve; Fill 20 20 27 31 $body; Fill 28 20 31 31 $sleeve; Fill 32 20 39 31 (Darken $Shirt 0.75)
  }
  # Arms
  Fill 44 16 (43+$aw) 19 $body
  Fill 40 20 43 31 $sleeve
  Fill 44 20 (43+$aw) 31 $body
  Fill 44 28 (43+$aw) 31 $Tone
  Fill 48 20 51 31 $sleeve
  Fill 52 20 (51+$aw) 31 (Darken $Shirt 0.75)
  Fill 36 48 (35+$aw) 51 $body
  Fill 32 52 35 63 $sleeve
  Fill 36 52 (35+$aw) 63 $body
  Fill 36 60 (35+$aw) 63 $Tone
  Fill 40 52 43 63 $sleeve
  Fill 44 52 (43+$aw) 63 (Darken $Shirt 0.75)
  # Legs / pants / shorts
  $legEnd = if ($ps -eq 'shorts') { 26 } else { 31 }
  Fill 4 16 7 19 $Pants
  Fill 0 20 3 $legEnd (Darken $Pants 0.85)
  Fill 4 20 7 $legEnd $Pants
  Fill 8 20 11 $legEnd (Darken $Pants 0.85)
  Fill 12 20 15 $legEnd (Darken $Pants 0.75)
  Fill 20 48 23 51 $Pants
  Fill 16 52 19 (52+($legEnd-20)) (Darken $Pants 0.85)
  Fill 20 52 23 (52+($legEnd-20)) $Pants
  Fill 24 52 27 (52+($legEnd-20)) (Darken $Pants 0.85)
  Fill 28 52 31 (52+($legEnd-20)) (Darken $Pants 0.75)
  if ($ps -eq 'shorts') {
    Fill 4 27 7 31 $Tone; Fill 0 27 3 31 (Darken $Tone 0.9)
    Fill 20 59 23 63 $Tone; Fill 16 59 19 63 (Darken $Tone 0.9)
  }
  # Shoes
  $shoe = if ($sh -eq 'boots') { Darken $Accent 0.55 } else { $Accent }
  Fill 4 28 7 31 $shoe
  Fill 20 60 23 63 $shoe
  if ($sh -eq 'boots') { Fill 4 26 7 27 $shoe; Fill 20 58 23 59 $shoe }
  # Accessories on 2nd (hat/jacket overlay) layer — UV 32-64 head overlay region
  # Head overlay: 40,0 / 32,8 etc.
  if ($acc -eq 'cap') {
    Fill 40 0 47 3 $Accent
    Fill 40 8 47 10 $Accent
    Fill 32 8 39 10 $Accent
    Fill 48 8 55 10 $Accent
  } elseif ($acc -eq 'visor') {
    Fill 40 8 47 9 [System.Drawing.Color]::FromArgb(180, 0, 229, 255)
    Fill 42 9 45 10 [System.Drawing.Color]::FromArgb(120, 0, 229, 255)
  } elseif ($acc -eq 'headphones') {
    Fill 32 10 33 14 $Accent
    Fill 54 10 55 14 $Accent
    Fill 40 8 47 9 (Darken $Accent 0.7)
  } elseif ($acc -eq 'neon') {
    $neon = [System.Drawing.Color]::FromArgb(220, 255, 40, 180)
    Fill 40 8 47 9 $neon
    Fill 20 20 27 21 $neon
    Fill 4 20 7 21 $neon
  }
  $g.Dispose()
  return $bmp
}

function Get-NorcomCreatorColors {
  if (-not $script:CreatorTone) { $script:CreatorTone = [System.Drawing.Color]::FromArgb(255,200,150,120) }
  if (-not $script:CreatorHair) { $script:CreatorHair = [System.Drawing.Color]::FromArgb(255,60,40,25) }
  if (-not $script:CreatorEyes) { $script:CreatorEyes = [System.Drawing.Color]::FromArgb(255,40,40,120) }
  if (-not $script:CreatorShirt) { $script:CreatorShirt = [System.Drawing.Color]::FromArgb(255,0,170,170) }
  if (-not $script:CreatorPants) { $script:CreatorPants = [System.Drawing.Color]::FromArgb(255,50,50,180) }
  if (-not $script:CreatorAccent) { $script:CreatorAccent = [System.Drawing.Color]::FromArgb(255,40,40,40) }
  if (-not $script:CreatorHairStyle) { $script:CreatorHairStyle = 'short' }
  if (-not $script:CreatorEyeStyle) { $script:CreatorEyeStyle = 'dot' }
  if (-not $script:CreatorShirtStyle) { $script:CreatorShirtStyle = 'tee' }
  if (-not $script:CreatorPantsStyle) { $script:CreatorPantsStyle = 'pants' }
  if (-not $script:CreatorShoeStyle) { $script:CreatorShoeStyle = 'sneakers' }
  if (-not $script:CreatorAccessory) { $script:CreatorAccessory = 'none' }
  return @{
    Tone = $script:CreatorTone; Hair = $script:CreatorHair; Eyes = $script:CreatorEyes
    Shirt = $script:CreatorShirt; Pants = $script:CreatorPants; Accent = $script:CreatorAccent
    HairStyle = $script:CreatorHairStyle; EyeStyle = $script:CreatorEyeStyle
    ShirtStyle = $script:CreatorShirtStyle; PantsStyle = $script:CreatorPantsStyle
    ShoeStyle = $script:CreatorShoeStyle; Accessory = $script:CreatorAccessory
  }
}

function Update-NorcomCreatorPreview {
  try {
    $c = Get-NorcomCreatorColors
    $bmp = New-NorcomGeneratedSkin -Tone $c.Tone -Hair $c.Hair -Eyes $c.Eyes -Shirt $c.Shirt -Pants $c.Pants -Accent $c.Accent -Slim:([bool]$script:CharacterSlim) -HairStyle $c.HairStyle -EyeStyle $c.EyeStyle -ShirtStyle $c.ShirtStyle -PantsStyle $c.PantsStyle -ShoeStyle $c.ShoeStyle -Accessory $c.Accessory
    $dir = Get-NorcomSkinsLibraryDir
    $out = Join-Path $dir '_creator-preview.png'
    $bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
    $script:CharacterSkinPath = $out
    if ($script:SkinPreview -and $script:SkinPreview.GetType().Name -eq 'SkinPreview3D') {
      $script:SkinPreview.SetSkin($bmp, [bool]$script:CharacterSlim)
      $bmp.Dispose()
    } elseif ($script:SkinPreview) {
      $old = $script:SkinPreview.Image
      $script:SkinPreview.Image = $bmp
      if ($old) { try { $old.Dispose() } catch {} }
    } else { $bmp.Dispose() }
  } catch {}
}

function Save-NorcomCreatorToLibrary {
  try {
    Update-NorcomCreatorPreview
    if (-not $script:CharacterSkinPath -or -not (Test-Path -LiteralPath $script:CharacterSkinPath)) { return $null }
    $lib = Save-NorcomSkinToLibrary -Path $script:CharacterSkinPath
    try { Update-NorcomSavedSkinThumbs } catch {}
    Set-Status 'Skin saved to library'
    return $lib
  } catch { return $null }
}

function Invoke-NorcomCreatorRandomize {
  $rnd = New-Object System.Random
  function RC([int]$a,[int]$b) { return [System.Drawing.Color]::FromArgb(255, $rnd.Next($a,$b), $rnd.Next($a,$b), $rnd.Next($a,$b)) }
  $script:CreatorTone = [System.Drawing.Color]::FromArgb(255, $rnd.Next(90,230), $rnd.Next(70,180), $rnd.Next(50,140))
  $script:CreatorHair = RC 20 90
  $script:CreatorEyes = [System.Drawing.Color]::FromArgb(255, $rnd.Next(20,80), $rnd.Next(40,140), $rnd.Next(80,220))
  $script:CreatorShirt = RC 30 220
  $script:CreatorPants = RC 20 160
  $script:CreatorAccent = RC 20 80
  $hairs = @('short','buzz','long','mohawk')
  $eyes = @('dot','wide','happy','glow')
  $shirts = @('tee','hoodie','jacket')
  $pants = @('pants','shorts')
  $shoes = @('sneakers','boots')
  $accs = @('none','cap','visor','headphones','neon')
  $script:CreatorHairStyle = $hairs[$rnd.Next(0,$hairs.Count)]
  $script:CreatorEyeStyle = $eyes[$rnd.Next(0,$eyes.Count)]
  $script:CreatorShirtStyle = $shirts[$rnd.Next(0,$shirts.Count)]
  $script:CreatorPantsStyle = $pants[$rnd.Next(0,$pants.Count)]
  $script:CreatorShoeStyle = $shoes[$rnd.Next(0,$shoes.Count)]
  $script:CreatorAccessory = $accs[$rnd.Next(0,$accs.Count)]
  Update-NorcomCreatorPreview
}
