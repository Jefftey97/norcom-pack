﻿#Requires -Version 5.1
# NORCOM launcher extras (Verify & Repair, SLP, Join, RAM, news/rules, crash zip, Physics Pro, voice, self-update, REI/IPN one-time migration)
$script:NorcomServerHost = 'shrimp-cub.tun.ply.gg'
$script:NorcomServerPort = 25565
$script:PhysicsProPatreon = 'https://www.patreon.com/Haubna/posts/physics-mod-pro-173645343'
$script:KnownBadMods = @('optifine','optifabric')

function Get-PackRoot {
  $candidates = @(
    (Join-Path (Split-Path $ScriptDir -Parent) 'packwiz'),
    (Join-Path $ScriptDir '..\packwiz'),
    'G:\MinecraftServer\NORCOM-pack\packwiz'
  )
  foreach ($c in $candidates) {
    try {
      $full = [IO.Path]::GetFullPath($c)
      if (Test-Path (Join-Path $full 'pack.toml')) { return $full }
    } catch {}
  }
  return $null
}

function Get-JavaMajor([string]$javaExe) {
  try {
    $errFile = Join-Path $env:TEMP 'norcom-java-ver.txt'
    Start-Process -FilePath $javaExe -ArgumentList '-version' -NoNewWindow -Wait -PassThru -RedirectStandardError $errFile | Out-Null
    $txt = Get-Content $errFile -Raw -ErrorAction SilentlyContinue
    if ($txt -match 'version "(\d+)') { return [int]$Matches[1] }
    if ($txt -match 'version "1\.(\d+)') { return [int]$Matches[1] }
  } catch {}
  return 0
}

function Test-MinecraftRunning {
  $procs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -match 'javaw?\.exe' -and $_.CommandLine -match 'minecraft|net\.minecraft|fabric'
  }
  return [bool]$procs
}

function Get-NorcomSettings {
  $path = Join-Path $NorcomHome 'settings.json'
  $def = [ordered]@{ ramMb = 4096; syncKeybinds = $false; syncPackConfig = $false; lastVerify = $null; windowW = 1100; windowH = 720; animatedBackground = $true; launcherSounds = $false; ramPreset = $null; closeToTray = $true; gpuProfile = 'auto' }
  if (Test-Path $path) {
    try {
      $j = Get-Content $path -Raw | ConvertFrom-Json
      foreach ($k in @($def.Keys)) { if ($null -ne $j.$k) { $def[$k] = $j.$k } }
      # preserve any extra keys already saved
      foreach ($p in $j.PSObject.Properties) { if (-not $def.Contains($p.Name)) { $def[$p.Name] = $p.Value } }
    } catch {}
  }
  return $def
}

function Save-NorcomSettings($s) {
  $path = Join-Path $NorcomHome 'settings.json'
  ($s | ConvertTo-Json -Depth 5) | Set-Content $path -Encoding UTF8
}

function Convert-JavaMemTokenToMb([string]$token) {
  if (-not $token) { return $null }
  if ($token -notmatch '(?i)^-Xm[sx](\d+)([kKmMgGtT])?$') { return $null }
  $n = [int64]$Matches[1]
  switch -Regex ($Matches[2]) {
    '^[kK]$' { return [int][Math]::Floor($n / 1024.0) }
    '^[mM]$' { return [int]$n }
    '^[gG]$' { return [int]($n * 1024) }
    '^[tT]$' { return [int]($n * 1024 * 1024) }
    default  { return [int][Math]::Floor($n / (1024.0 * 1024.0)) } # bare number = bytes
  }
}

function Merge-JavaArgsRam([string]$javaArgs, [int]$ramMb) {
  if ($ramMb -lt 1) { $ramMb = 1 }
  $args = if ($javaArgs) { [string]$javaArgs } else { '' }
  $xmx = "-Xmx${ramMb}M"
  $xms = $null
  $m = [regex]::Match($args, '(?i)-Xms\S+')
  if ($m.Success) {
    $existing = $m.Value
    $mb = Convert-JavaMemTokenToMb $existing
    if ($null -eq $mb) {
      $xms = if ($ramMb -lt 1024) { "-Xms${ramMb}M" } else { '-Xms1024M' }
    } elseif ($mb -gt $ramMb) {
      $xms = "-Xms${ramMb}M"
    } else {
      $xms = $existing
    }
  } else {
    $xms = if ($ramMb -lt 1024) { "-Xms${ramMb}M" } else { '-Xms1024M' }
  }
  $args = [regex]::Replace($args, '(?i)-Xmx\S+', '').Trim()
  $args = [regex]::Replace($args, '(?i)-Xms\S+', '').Trim()
  $args = [regex]::Replace($args, '\s+', ' ').Trim()
  return ("$xms $xmx " + $args).Trim()
}

function Update-ProfileRam([int]$ramMb) {
  $profilesPath = Join-Path $McDir 'launcher_profiles.json'
  if (-not (Test-Path $profilesPath)) { return }
  $json = Get-Content $profilesPath -Raw | ConvertFrom-Json
  if (-not $json.profiles.NORCOM) { return }
  $args = Merge-JavaArgsRam ([string]$json.profiles.NORCOM.javaArgs) $ramMb
  $json.profiles.NORCOM | Add-Member -NotePropertyName javaArgs -NotePropertyValue $args -Force
  $json | ConvertTo-Json -Depth 12 | Set-Content $profilesPath -Encoding UTF8
  Write-LogUi "RAM profile args set: $args"
}

function Invoke-ServerListPing {
  $hostName = $script:NorcomServerHost
  $port = [int]$script:NorcomServerPort
  $result = [ordered]@{ online=$false; players=0; max=0; names=@(); motd=''; latencyMs=-1; error='' }
  try {
    # Real Minecraft Server List Ping over TCP (not HTTP). Latency = ping-packet RTT, not JSON download.
    $client = New-Object System.Net.Sockets.TcpClient
    $iar = $client.BeginConnect($hostName, $port, $null, $null)
    $ok = $iar.AsyncWaitHandle.WaitOne(2500, $false)
    if (-not $ok -or -not $client.Connected) { throw 'connect timeout' }
    $client.EndConnect($iar)
    $stream = $client.GetStream()
    $stream.ReadTimeout = 2500; $stream.WriteTimeout = 2500
    function Write-VarInt([IO.Stream]$s, [int]$v) {
      while ($true) {
        if (($v -band 0xFFFFFF80) -eq 0) { $s.WriteByte([byte]$v); break }
        $s.WriteByte([byte](($v -band 0x7F) -bor 0x80))
        $v = $v -shr 7
      }
    }
    function Write-McString([IO.Stream]$s, [string]$str) {
      $b = [Text.Encoding]::UTF8.GetBytes($str)
      Write-VarInt $s $b.Length
      $s.Write($b, 0, $b.Length)
    }
    function Read-VarInt([IO.Stream]$s) {
      $num=0; $shift=0
      while ($true) {
        $b=$s.ReadByte(); if ($b -lt 0) { throw 'eof' }
        $num = $num -bor (($b -band 0x7F) -shl $shift)
        if (($b -band 0x80) -eq 0) { break }
        $shift += 7
        if ($shift -gt 35) { throw 'varint' }
      }
      return $num
    }
    $ms = New-Object IO.MemoryStream
    Write-VarInt $ms 0x00
    Write-VarInt $ms 770
    Write-McString $ms $hostName
    $portBytes = [BitConverter]::GetBytes([uint16]$port); if ([BitConverter]::IsLittleEndian){ [Array]::Reverse($portBytes) }
    $ms.Write($portBytes,0,2)
    Write-VarInt $ms 1
    $payload = $ms.ToArray()
    Write-VarInt $stream $payload.Length
    $stream.Write($payload,0,$payload.Length)
    Write-VarInt $stream 1
    $stream.WriteByte(0x00)
    $len = Read-VarInt $stream
    $buf = New-Object byte[] $len
    $read=0
    while ($read -lt $len) {
      $n=$stream.Read($buf,$read,$len-$read)
      if ($n -le 0) { break }
      $read += $n
    }
    $ms2 = New-Object IO.MemoryStream(,$buf)
    [void](Read-VarInt $ms2)
    $jsonLen = Read-VarInt $ms2
    $jb = New-Object byte[] $jsonLen
    [void]$ms2.Read($jb,0,$jsonLen)
    $jsonText = [Text.Encoding]::UTF8.GetString($jb)
    # Status JSON can be large over playit; measure true RTT with the protocol ping packet (0x01).
    $pingPayload = [BitConverter]::GetBytes([int64]([DateTime]::UtcNow.Ticks))
    $sw = [Diagnostics.Stopwatch]::StartNew()
    Write-VarInt $stream 9
    $stream.WriteByte(0x01)
    $stream.Write($pingPayload, 0, 8)
    $pingLen = Read-VarInt $stream
    $pingBuf = New-Object byte[] $pingLen
    $pread = 0
    while ($pread -lt $pingLen) {
      $n = $stream.Read($pingBuf, $pread, $pingLen - $pread)
      if ($n -le 0) { break }
      $pread += $n
    }
    $sw.Stop()
    $obj = $jsonText | ConvertFrom-Json
    $motd = ''
    if ($obj.description) {
      if ($obj.description -is [string]) { $motd = $obj.description }
      elseif ($obj.description.text) { $motd = [string]$obj.description.text }
      else { $motd = ($obj.description | ConvertTo-Json -Compress) }
    }
    $result.online = $true
    $result.players = [int]$obj.players.online
    $result.max = [int]$obj.players.max
    try { if ($obj.players.sample) { $result.names = @($obj.players.sample | ForEach-Object { $_.name }) } } catch { $result.names = @() }
    $result.motd = $motd
    $result.latencyMs = [int]$sw.ElapsedMilliseconds
    $client.Close()
  } catch {
    $result.error = $_.Exception.Message
  }
  return $result
}

function Get-DiscordInviteUrl {
  $pack = Get-PackRoot
  if (-not $pack) { return $null }
  $f = Join-Path $pack 'discord-link.txt'
  if (-not (Test-Path $f)) { return $null }
  foreach ($line in Get-Content $f) {
    if ($line -match '^\s*DISCORD_URL\s*=\s*(https?://\S+)') { return $Matches[1].Trim() }
    if ($line -match '^\s*(https://discord\.gg/\S+)') { return $Matches[1].Trim() }
  }
  return $null
}

function Get-LocalInstallerVersion {
  $candidates = @(
    (Join-Path $ScriptDir 'installer-version.txt'),
    (Join-Path $NorcomHome 'Launcher\installer-version.txt')
  )
  foreach ($p in $candidates) {
    if ($p -and (Test-Path -LiteralPath $p)) {
      try { return (Get-Content -LiteralPath $p -Raw).Trim() } catch {}
    }
  }
  return '0.0.0'
}

function Compare-NorcomVersion([string]$a, [string]$b) {
  function To-Ver([string]$s) {
    $clean = ($s -replace '[^0-9.].*','' -replace '^\.+','' -replace '\.+$','')
    if (-not $clean) { $clean = '0' }
    $parts = @($clean.Split('.') | Where-Object { $_ -ne '' })
    while ($parts.Count -lt 3) { $parts += '0' }
    try { return [version](($parts | Select-Object -First 4) -join '.') } catch { return [version]'0.0.0' }
  }
  $va = To-Ver $a; $vb = To-Ver $b
  if ($va -gt $vb) { return 1 }
  if ($va -lt $vb) { return -1 }
  return 0
}

function Get-InstallerRemoteVersion {
  try {
    $mani = Get-NorcomLauncherManifest
    if ($mani -and $mani.version) { return [string]$mani.version }
  } catch {}
  return $null
}

function Get-NorcomLauncherManifest {
  $ua = @{ 'User-Agent' = 'NORCOM-Launcher/1.0.28' }
  try {
    $api = Invoke-RestMethod -Uri 'https://api.github.com/repos/Jefftey97/norcom-pack/contents/launcher/manifest.json?ref=main' -Headers (@{ Accept = 'application/vnd.github+json' } + $ua) -TimeoutSec 8
    if ($api -and $api.content) {
      $text = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String((($api.content -replace '\s',''))))
      if ($text.Length -gt 0 -and [int][char]$text[0] -eq 0xFEFF) { $text = $text.Substring(1) }
      return ($text.TrimStart([char]0xFEFF).Trim() | ConvertFrom-Json)
    }
  } catch {
    Write-LogUi ("Launcher manifest API: " + $_.Exception.Message)
  }
  foreach ($url in @(
    'https://cdn.jsdelivr.net/gh/Jefftey97/norcom-pack@main/launcher/manifest.json',
    'https://raw.githubusercontent.com/Jefftey97/norcom-pack/refs/heads/main/launcher/manifest.json'
  )) {
    try {
      $resp = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 8 -Headers $ua
      $text = $resp.Content
      if ($text.Length -gt 0 -and [int][char]$text[0] -eq 0xFEFF) { $text = $text.Substring(1) }
      $text = $text.TrimStart([char]0xFEFF).Trim()
      return ($text | ConvertFrom-Json)
    } catch {
      Write-LogUi ("Launcher manifest ($url): " + $_.Exception.Message)
    }
  }
  return $null
}

function Invoke-ReiIpnOneTimeMigration {
  # Pack 1.0.17+ ships cleaned REI/IPN configs (preserve=true). Existing friends still have old laggy/clashy files.
  # One-time: back up and delete so packwiz re-seeds. Never touch options.txt / graphics.
  try {
    $st = Load-State
    if ($st.migratedReiIpn1017 -eq $true) { return }
    if (-not $GameDir) {
      Set-StateProp $st 'migratedReiIpn1017' $true
      Save-State $st
      return
    }
    $targets = @(
      (Join-Path $GameDir 'config\roughlyenoughitems\config.json5'),
      (Join-Path $GameDir 'config\inventoryprofilesnext\inventoryprofiles.json')
    )
    $anyExist = $false
    foreach ($p in $targets) { if (Test-Path -LiteralPath $p) { $anyExist = $true; break } }
    if ($anyExist) {
      $bakRoot = Join-Path $GameDir ('config\_norcom_mig_bak_rei_ipn_' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
      $gameFull = [IO.Path]::GetFullPath($GameDir)
      foreach ($p in $targets) {
        if (-not (Test-Path -LiteralPath $p)) { continue }
        $full = [IO.Path]::GetFullPath($p)
        $rel = $full.Substring($gameFull.Length).TrimStart('\','/')
        $dest = Join-Path $bakRoot $rel
        New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
        Copy-Item -LiteralPath $p -Destination $dest -Force
        Remove-Item -LiteralPath $p -Force
        Write-LogUi ("Migration 1.0.17: backed up + removed $rel")
      }
      Write-LogUi 'Migration 1.0.17: REI/IPN configs cleared for packwiz re-seed'
      try { Set-Status 'Updated inventory settings (one-time cleanup)...' } catch {}
    } else {
      Write-LogUi 'Migration 1.0.17: no old REI/IPN configs (fresh or already clean)'
    }
    Set-StateProp $st 'migratedReiIpn1017' $true
    Save-State $st
  } catch {
    Write-LogUi ("Migration 1.0.17 failed (non-fatal): " + $_.Exception.Message)
  }
}

function Invoke-NorcomLauncherSelfUpdate {
  if ($env:NORCOM_SKIP_SELFUPDATE) { Write-LogUi 'Self-update skipped (NORCOM_SKIP_SELFUPDATE)'; return $false }
  if ($TestMode -eq '1' -and -not $env:NORCOM_FORCE_SELFUPDATE) { return $false }
  if ($script:SelfTest -and -not $env:NORCOM_FORCE_SELFUPDATE) { return $false }

  $localVer = Get-LocalInstallerVersion
  $mani = Get-NorcomLauncherManifest
  if (-not $mani -or -not $mani.version -or -not $mani.zipUrl -or -not $mani.sha256) {
    Write-LogUi 'Self-update: no manifest or incomplete; continuing'
    return $false
  }
  if ((Compare-NorcomVersion ([string]$mani.version) $localVer) -le 0) {
    Write-LogUi ("Launcher up to date ($localVer)")
    return $false
  }

  try { Set-Status ("Updating launcher $localVer -> $($mani.version)...") } catch {}
  Write-LogUi ("Self-update available: $localVer -> $($mani.version)")
  $tmp = Join-Path $env:TEMP ('norcom-launcher-upd-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  $zip = Join-Path $tmp 'update.zip'
  try {
    Invoke-WebRequest -Uri ([string]$mani.zipUrl) -OutFile $zip -UseBasicParsing -TimeoutSec 180
    if (-not (Test-Path $zip) -or ((Get-Item $zip).Length -lt 1000)) { throw 'Downloaded update zip missing or too small' }
    $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    $want = ([string]$mani.sha256).Trim().ToLowerInvariant()
    if ($hash -ne $want) { throw "SHA256 mismatch (got $hash want $want)" }

    $extract = Join-Path $tmp 'extract'
    Expand-Archive -LiteralPath $zip -DestinationPath $extract -Force
    $root = $extract
    $kids = @(Get-ChildItem $extract -Force)
    if ($kids.Count -eq 1 -and $kids[0].PSIsContainer) {
      if (Test-Path (Join-Path $kids[0].FullName 'NORCOM-Launcher.ps1')) { $root = $kids[0].FullName }
      elseif (Test-Path (Join-Path $kids[0].FullName 'installer-version.txt')) { $root = $kids[0].FullName }
    }
    if (-not (Test-Path (Join-Path $root 'NORCOM-Launcher.ps1'))) { throw 'Update zip missing NORCOM-Launcher.ps1' }

    $installDir = $ScriptDir
    $backup = Join-Path $NorcomHome ('Launcher.bak-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $stub = Join-Path $installDir 'NORCOM Launcher.exe'
    if (-not (Test-Path $stub)) { $stub = Join-Path $installDir 'NORCOM-Launcher.vbs' }
    $updater = Join-Path $tmp 'apply-update.ps1'
    $log = Join-Path $NorcomHome 'Launcher\self-update.log'
    $ver = [string]$mani.version
    $tpl = @'
$ErrorActionPreference = 'Continue'
$log = '__LOG__'
function L($m){ try { Add-Content -LiteralPath $log -Value ((Get-Date -Format o) + ' ' + $m) } catch {} }
function Copy-FileRetry([string]$from, [string]$to, [int]$tries = 12) {
  $dir = Split-Path $to -Parent
  if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  for ($i = 1; $i -le $tries; $i++) {
    try {
      Copy-Item -LiteralPath $from -Destination $to -Force -ErrorAction Stop
      return $true
    } catch {
      if ($i -eq $tries) { L ('copy fail ' + $to + ' :: ' + $_.Exception.Message); return $false }
      Start-Sleep -Milliseconds (200 * $i)
    }
  }
  return $false
}
L 'apply start ver=__VER__'
$deadline = (Get-Date).AddSeconds(20)
while ((Get-Date) -lt $deadline) {
  $holders = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -and ($_.CommandLine -match 'NORCOM\Launcher\NORCOM-Launcher|NORCOM\Launcher\Launcher.ps1') -and $_.ProcessId -ne $PID
  })
  if ($holders.Count -eq 0) { break }
  Start-Sleep -Milliseconds 400
}
Start-Sleep -Seconds 2
$src = '__SRC__'
$dst = '__DST__'
$bak = '__BAK__'
$failed = New-Object System.Collections.Generic.List[string]
try {
  if (Test-Path -LiteralPath $dst) {
    New-Item -ItemType Directory -Path (Split-Path $bak -Parent) -Force | Out-Null
    Get-ChildItem -LiteralPath $dst -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
      $rel = $_.FullName.Substring(([IO.Path]::GetFullPath($dst)).Length).TrimStart('\')
      $dest = Join-Path $bak $rel
      [void](Copy-FileRetry $_.FullName $dest 6)
    }
    L ('backup ' + $bak)
  }
  Get-ChildItem -LiteralPath $src -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring(([IO.Path]::GetFullPath($src)).Length).TrimStart('\')
    if ($rel -eq 'NORCOM Launcher.exe' -or $rel -eq 'NORCOM-Launcher.exe') {
      if (-not (Copy-FileRetry $_.FullName (Join-Path $dst $rel) 4)) { L ('skip locked stub ' + $rel) }
      return
    }
    $dest = Join-Path $dst $rel
    if (-not (Copy-FileRetry $_.FullName $dest 12)) { [void]$failed.Add($rel) }
  }
  if ($failed.Count -gt 0) {
    L ('partial fail count=' + $failed.Count + ' first=' + $failed[0])
    $core = @(
      (Join-Path $dst 'NORCOM-Launcher.ps1'),
      (Join-Path $dst 'Launcher.ps1'),
      (Join-Path $dst 'installer-version.txt'),
      (Join-Path $dst 'tools\NorcomExtras.ps1')
    )
    foreach ($c in $core) { if (-not (Test-Path -LiteralPath $c)) { throw ('core files missing after apply; failed=' + ($failed -join ',')) } }
  }
  Set-Content -LiteralPath (Join-Path $dst 'self-update-ok.txt') -Value ('updated to __VER__ at ' + (Get-Date -Format o)) -Encoding UTF8
  L 'apply ok'
  $stubPath = '__STUB__'
  if (Test-Path -LiteralPath $stubPath) { Start-Process -FilePath $stubPath -WorkingDirectory $dst }
  else {
    $ps1 = Join-Path $dst 'NORCOM-Launcher.ps1'
    Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-STA','-WindowStyle','Hidden','-File', $ps1) -WorkingDirectory $dst
  }
} catch {
  L ('FAIL ' + $_.Exception.Message)
  try {
    if (Test-Path -LiteralPath $bak) {
      Get-ChildItem -LiteralPath $bak -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring(([IO.Path]::GetFullPath($bak)).Length).TrimStart('\')
        [void](Copy-FileRetry $_.FullName (Join-Path $dst $rel) 6)
      }
      L 'rolled back from backup'
    }
  } catch { L ('rollback failed ' + $_.Exception.Message) }
}
'@
    $body = $tpl.Replace('__LOG__', $log).Replace('__VER__', $ver).Replace('__SRC__', $root).Replace('__DST__', $installDir).Replace('__BAK__', $backup).Replace('__STUB__', $stub)
    [IO.File]::WriteAllText($updater, $body, [Text.UTF8Encoding]::new($true))

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe')
    $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$updater`""
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    [void][Diagnostics.Process]::Start($psi)
    Write-LogUi "Self-update applying $ver; launcher will restart"
    try { Set-Status "Updating to $ver - restarting..." } catch {}
    try { if ($script:BgImage) { $script:BgImage.Dispose(); $script:BgImage = $null } } catch {}
    try {
      if ($script:MainForm -and -not $script:MainForm.IsDisposed) {
        if ($script:MainForm.Icon) { $script:MainForm.Icon.Dispose(); $script:MainForm.Icon = $null }
        $script:MainForm.Hide()
      }
    } catch {}
    try { [System.Windows.Forms.Application]::DoEvents() } catch {}
    Start-Sleep -Milliseconds 200
    Stop-Process -Id $PID -Force
    return $true
  } catch {
    Write-LogUi ("Self-update failed (keeping $localVer): " + $_.Exception.Message)
    try { Set-Status 'Update failed - continuing with current launcher' } catch {}
    return $false
  }
}



function Invoke-VerifyAndRepair {
  $report = New-Object System.Collections.Generic.List[string]
  $script:__vrLevel = 'green'
  function Add-R([string]$sev,[string]$msg) {
    $report.Add("[$sev] $msg") | Out-Null
    if ($sev -eq 'RED') { $script:__vrLevel = 'red' }
    elseif ($sev -eq 'YELLOW' -and $script:__vrLevel -ne 'red') { $script:__vrLevel = 'yellow' }
  }

  if (Test-MinecraftRunning) {
    Add-R 'RED' 'Minecraft appears to be running. Close the game before Verify & Repair.'
    return @{ level='red'; lines=$report.ToArray() }
  }

  $java = Get-JavaExe
  if (-not $java) { $java = Ensure-Java }
  $maj = Get-JavaMajor $java
  if ($maj -ge 25) { Add-R 'GREEN' "Java $maj OK ($java)" }
  elseif ($maj -ge 21) { Add-R 'YELLOW' "Java $maj found; NORCOM targets Java 25+. Will try to continue." }
  else { Add-R 'RED' "Java $maj is too old. Need 25+." }

  try { Ensure-Fabric $java; Add-R 'GREEN' 'Fabric loader profile check OK' }
  catch { Add-R 'RED' "Fabric loader: $($_.Exception.Message)" }

  try {
    Set-Status 'Verify: packwiz refresh...'
    Sync-Packwiz $java | Out-Null
    Add-R 'GREEN' 'packwiz refresh OK'
  } catch { Add-R 'RED' "packwiz: $($_.Exception.Message)" }

  $modsDir = Join-Path $GameDir 'mods'
  $expected = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
  $pack = Get-PackRoot
  if ($pack) {
    Get-ChildItem (Join-Path $pack 'mods') -Filter '*.pw.toml' -EA SilentlyContinue | ForEach-Object {
      $t = Get-Content $_.FullName -Raw
      if ($t -match 'filename\s*=\s*"([^"]+)"') { [void]$expected.Add($Matches[1]) }
    }
  }
  $ts = Get-Date -Format 'yyyyMMdd-HHmmss'
  $qdir = Join-Path $GameDir ("mods_quarantine\$ts")
  $extrasN = 0
  if (Test-Path $modsDir) {
    foreach ($jar in Get-ChildItem $modsDir -Filter '*.jar' -File) {
      $n = $jar.Name
      $bad = $false
      foreach ($kb in $script:KnownBadMods) { if ($n -match [regex]::Escape($kb)) { $bad = $true; break } }
      if ($bad) {
        New-Item -ItemType Directory -Path $qdir -Force | Out-Null
        Move-Item $jar.FullName (Join-Path $qdir $n) -Force
        $extrasN++; Add-R 'YELLOW' "Quarantined known-bad: $n"; continue
      }
      if ($expected.Count -gt 0 -and -not $expected.Contains($n)) {
        if ($n -match '^physics-mod-pro-.*fabric.*26\.3') { Add-R 'GREEN' "Physics Mod Pro present (user-imported): $n"; continue }
        New-Item -ItemType Directory -Path $qdir -Force | Out-Null
        Move-Item $jar.FullName (Join-Path $qdir $n) -Force
        $extrasN++; Add-R 'YELLOW' "Quarantined extra jar: $n"
      }
    }
  }
  if ($extrasN -eq 0) { Add-R 'GREEN' 'No extra/known-bad jars quarantined' }

  try {
    $dep = Test-FabricDependencies -ModsDir $modsDir
    $miss = @($dep.Missing)
    if ($miss.Count -eq 0) { Add-R 'GREEN' ("Dependency check: 0 missing (provided=" + $dep.ProvidedCount + ")") }
    else {
      $need = ($miss | ForEach-Object { $_.Needs }) -join ', '
      Add-R 'RED' ("Missing deps: " + $need)
    }
  } catch { Add-R 'YELLOW' "Dependency auditor error: $($_.Exception.Message)" }

  $opt = Join-Path $GameDir 'options.txt'
  if (Test-Path $opt) {
    $ot = Get-Content $opt -Raw
    if ($ot -match 'resourcePacks:(.+)') {
      $rp = $Matches[1]
      $idxA = $rp.ToLower().IndexOf('addon'); $idxM = $rp.ToLower().IndexOf('models'); $idxB = $rp.ToLower().IndexOf('basic')
      if ($idxA -ge 0 -and $idxM -ge 0 -and $idxB -ge 0 -and $idxA -lt $idxM -and $idxM -lt $idxB) {
        Add-R 'GREEN' 'Resource pack order looks correct (addon > models > basic)'
      } else {
        Add-R 'YELLOW' 'Resource pack order differs from Patrix default (addon > models > basic). Left untouched - change in-game if you want.'
      }
    } else { Add-R 'YELLOW' 'No resourcePacks line yet (Minecraft will create one)' }
  } else { Add-R 'YELLOW' 'options.txt missing (will be created on first play only)' }

  $sp = Join-Path $GameDir 'shaderpacks'
  if ((Test-Path $sp) -and (Get-ChildItem $sp -File -EA SilentlyContinue | Where-Object { $_.Name -match 'Complementary' })) {
    Add-R 'GREEN' 'Complementary shaderpack present'
  } else { Add-R 'YELLOW' 'Complementary shaderpack not found in game dir' }

  if (Test-Path $modsDir) {
    if (Get-ChildItem $modsDir -Filter '*voicechat*' -EA SilentlyContinue) { Add-R 'GREEN' 'Simple Voice Chat jar present' }
    else { Add-R 'YELLOW' 'Voice chat jar missing' }
  }

  return @{ level=$script:__vrLevel; lines=$report.ToArray() }
}

function Invoke-CrashLogZip {
  $logRoots = @(
    (Join-Path $GameDir 'logs'),
    (Join-Path $GameDir 'crash-reports'),
    (Join-Path $McDir 'logs'),
    (Join-Path $McDir 'crash-reports')
  )
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $outDir = Join-Path $NorcomHome 'crash-zips'
  New-Item -ItemType Directory -Path $outDir -Force | Out-Null
  $zip = Join-Path $outDir "norcom-logs-$stamp.zip"
  $stage = Join-Path $env:TEMP "norcom-logs-$stamp"
  if (Test-Path $stage) { Remove-Item $stage -Recurse -Force -EA SilentlyContinue }
  New-Item -ItemType Directory -Path $stage -Force | Out-Null
  foreach ($r in $logRoots) {
    if (Test-Path $r) {
      Copy-Item $r (Join-Path $stage (Split-Path $r -Leaf)) -Recurse -Force -ErrorAction SilentlyContinue
    }
  }
  # Strip credentials / tokens / MSA secrets before packaging
  $secretRx = '(?i)(access[_-]?token|refresh[_-]?token|client[_-]?token|msa[_-]?token|password|rcon\.password|Authorization:\s*Bearer)\s*[=:]\s*\S+'
  Get-ChildItem $stage -Recurse -File -EA SilentlyContinue | ForEach-Object {
    $ext = $_.Extension.ToLowerInvariant()
    if ($ext -notin @('.log','.txt','.json','.yml','.yaml','.properties','.cfg','.toml','.md','.crash')) { return }
    try {
      $raw = [IO.File]::ReadAllText($_.FullName)
      $red = [regex]::Replace($raw, $secretRx, '$1=***REDACTED***')
      $red = [regex]::Replace($red, '(?i)"(accessToken|clientToken|refreshToken)"\s*:\s*"[^"]*"', '"$1":"***REDACTED***"')
      if ($red -ne $raw) { [IO.File]::WriteAllText($_.FullName, $red) }
    } catch {}
  }
  # Never include launcher_accounts.json / secrets
  Get-ChildItem $stage -Recurse -File -EA SilentlyContinue | Where-Object {
    $_.Name -match '(?i)launcher_accounts|launcher_profiles|credentials|secrets|rcon\.pass|\.pem$|\.key$'
  } | Remove-Item -Force -EA SilentlyContinue
  if (Test-Path $zip) { Remove-Item $zip -Force }
  Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -Force
  Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
  if (-not $script:SelfTest) {
    Start-Process explorer.exe -ArgumentList "/select,`"$zip`""
  }
  return $zip
}

function Invoke-PhysicsProHelper {
  Start-Process $script:PhysicsProPatreon
  $dl = Join-Path $env:USERPROFILE 'Downloads'
  $cands = Get-ChildItem $dl -Filter 'physics-mod-pro-*-fabric-mc-26.3.jar' -EA SilentlyContinue | Sort-Object LastWriteTime -Descending
  if (-not $cands) {
    [System.Windows.Forms.MessageBox]::Show("Opened the official Patreon post.`n`nAfter you download physics-mod-pro-*-fabric-mc-26.3.jar into Downloads, click Physics Mod Pro again to import it.`nThe jar is never shipped with NORCOM.", 'Physics Mod Pro', 'OK', 'Information') | Out-Null
    return
  }
  $jar = $cands[0]
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $ok=$false; $modid=''
  try {
    $z = [IO.Compression.ZipFile]::OpenRead($jar.FullName)
    $e = $z.Entries | Where-Object { $_.FullName -eq 'fabric.mod.json' } | Select-Object -First 1
    if ($e) {
      $sr = New-Object IO.StreamReader($e.Open())
      $txt = $sr.ReadToEnd(); $sr.Close()
      if ($txt -match '"id"\s*:\s*"([^"]+)"') { $modid=$Matches[1] }
      if ($txt -match 'physics' -or $modid -match 'physics') { $ok=$true }
    }
    $z.Dispose()
  } catch {}
  if (-not $ok) {
    [System.Windows.Forms.MessageBox]::Show("File $($jar.Name) failed fabric.mod.json / name check. Not imported.", 'Physics Mod Pro', 'OK', 'Warning') | Out-Null
    return
  }
  $destDir = Join-Path $GameDir 'mods'
  New-Item -ItemType Directory -Path $destDir -Force | Out-Null
  Copy-Item $jar.FullName (Join-Path $destDir $jar.Name) -Force
  Write-LogUi "Imported Physics Mod Pro: $($jar.Name) ($modid)"
  [System.Windows.Forms.MessageBox]::Show("Imported $($jar.Name) into NORCOM mods.", 'Physics Mod Pro', 'OK', 'Information') | Out-Null
}

function Invoke-JoinServer {
  # Join Server button removed - Play NORCOM writes servers.dat and opens the Java launcher.
  Write-LogUi 'Invoke-JoinServer is deprecated; use Play NORCOM'
  Set-Status 'Use Play NORCOM - server is in your Multiplayer list'
}

function Read-PackMarkdown([string]$name) {
  # Prefer published packwiz copy when present (Jeffrey's PC); friends fall back to
  # the news.md / rules.md shipped inside the installer / LocalAppData\NORCOM\Launcher.
  $candidates = @()
  $pack = Get-PackRoot
  if ($pack) { $candidates += (Join-Path $pack $name) }
  if ($ScriptDir) { $candidates += (Join-Path $ScriptDir $name) }
  foreach ($p in $candidates) {
    if ($p -and (Test-Path -LiteralPath $p)) {
      return Get-Content -LiteralPath $p -Raw
    }
  }
  return "# $name`n(not found in pack)"
}
