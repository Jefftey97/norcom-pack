using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace NorcomUi {
  public static class Theme {
    // Neon Cyber Sleek (Option C): deep navy + electric cyan + hot pink
    public static Color Bg = Color.FromArgb(6, 10, 28);
    public static Color Panel = Color.FromArgb(14, 20, 42);
    public static Color Card = Color.FromArgb(18, 26, 52);
    public static Color CardAlt = Color.FromArgb(16, 22, 46);
    public static Color Olive = Color.FromArgb(12, 48, 78);          // dark cyan glass button
    public static Color OliveBright = Color.FromArgb(0, 190, 230);   // electric cyan hover
    public static Color Tan = Color.FromArgb(210, 170, 210);         // soft lavender
    public static Color Gold = Color.FromArgb(0, 220, 255);          // cyan wordmark / accents
    public static Color GoldBright = Color.FromArgb(120, 235, 255);  // light cyan
    public static Color GoldDark = Color.FromArgb(255, 45, 180);     // hot pink (gradient end)
    public static Color Text = Color.FromArgb(235, 245, 255);
    public static Color Dim = Color.FromArgb(140, 160, 190);
    public static Color Danger = Color.FromArgb(220, 55, 90);
    public static Color DangerHover = Color.FromArgb(255, 80, 120);
    public static Color Offline = Color.FromArgb(140, 50, 70);
    public static Color Online = Color.FromArgb(40, 220, 140);
    public static Color TrackOff = Color.FromArgb(30, 36, 58);
    public static Color Knob = Color.FromArgb(240, 248, 255);
    public static Color Input = Color.FromArgb(10, 14, 30);
    public static Color InputBorder = Color.FromArgb(90, 0, 200, 230);
    public static Color Cyan = Color.FromArgb(0, 220, 255);
    public static Color Pink = Color.FromArgb(255, 45, 180);
    public static Color Glass = Color.FromArgb(160, 12, 18, 40);
  }

  public static class Draw {
    // Colour actually visible behind a control (walks up past transparent parents; cards report their fill).
    public static Color EffectiveBack(Control p) {
      while (p != null) {
        CardPanel cp = p as CardPanel;
        if (cp != null) return Color.FromArgb(255, cp.Fill.R, cp.Fill.G, cp.Fill.B);
        if (p.BackColor.A == 255) return p.BackColor;
        p = p.Parent;
      }
      return Theme.Bg;
    }
    public static void FillParentBack(Control c, PaintEventArgs e) {
      e.Graphics.Clear(EffectiveBack(c.Parent));
    }


    // 1.0.30l: blit AnimatedCityBg into a child HDC (PrintWindow-safe; no PointToScreen)
    // 1.0.33z: blit SAME cached city frame (no live PaintScene) — kills child/parent tear
    public static void PaintCityBehind(Control c, PaintEventArgs e) {
      if (c == null || e == null) return;
      AnimatedCityBg city = null;
      for (Control p = c.Parent; p != null; p = p.Parent) {
        city = p as AnimatedCityBg;
        if (city != null) break;
      }
      if (city == null) {
        e.Graphics.Clear(EffectiveBack(c.Parent));
        return;
      }
      int ox = 0, oy = 0;
      for (Control x = c; x != null && x != city; x = x.Parent) {
        ox += x.Left;
        oy += x.Top;
      }
      if (city.BlitCachedScene(e.Graphics, -ox, -oy, false)) return;
      System.Drawing.Drawing2D.GraphicsState st = e.Graphics.Save();
      try {
        e.Graphics.TranslateTransform(-ox, -oy);
        city.PaintScene(e.Graphics, false);
      } finally {
        e.Graphics.Restore(st);
      }
    }

    public static GraphicsPath RoundRect(Rectangle r, int radius) {
      int d = Math.Max(2, radius * 2);
      GraphicsPath path = new GraphicsPath();
      path.AddArc(r.X, r.Y, d, d, 180, 90);
      path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
      path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
      path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
      path.CloseFigure();
      return path;
    }
  }

  public enum StatusIconKind {
    Server, People, Clock, Memory, Disk, Globe, Play, Stop, Restart, Save, Backup,
    Link, Skin, Folder, Mods, Discord, Camera, Gear, Console, Rules, Voice, Wrench
  }

  public static class Icons {
    public static void Paint(Graphics g, Rectangle r, StatusIconKind kind, Color accent) {
      g.SmoothingMode = SmoothingMode.AntiAlias;
      g.PixelOffsetMode = PixelOffsetMode.HighQuality;
      using (Pen pen = new Pen(accent, Math.Max(1.6f, r.Width / 18f))) {
        pen.LineJoin = LineJoin.Round;
        pen.StartCap = LineCap.Round;
        pen.EndCap = LineCap.Round;
        switch (kind) {
          case StatusIconKind.Server: DrawServer(g, r, pen); break;
          case StatusIconKind.People: DrawPeople(g, r, pen); break;
          case StatusIconKind.Clock: DrawClock(g, r, pen); break;
          case StatusIconKind.Memory: DrawMemory(g, r, pen); break;
          case StatusIconKind.Disk: DrawDisk(g, r, pen); break;
          case StatusIconKind.Globe: DrawGlobe(g, r, pen); break;
          case StatusIconKind.Play: DrawPlay(g, r, pen, accent); break;
          case StatusIconKind.Stop: DrawStop(g, r, accent); break;
          case StatusIconKind.Restart: DrawRestart(g, r, pen); break;
          case StatusIconKind.Save: DrawSave(g, r, pen); break;
          case StatusIconKind.Backup: DrawBackup(g, r, pen, accent); break;
          case StatusIconKind.Link: DrawLink(g, r, pen); break;
          case StatusIconKind.Skin: DrawSkin(g, r, pen); break;
          case StatusIconKind.Folder: DrawFolder(g, r, pen); break;
          case StatusIconKind.Mods: DrawMods(g, r, pen); break;
          case StatusIconKind.Discord: DrawDiscord(g, r, pen, accent); break;
          case StatusIconKind.Camera: DrawCamera(g, r, pen, accent); break;
          case StatusIconKind.Gear: DrawGear(g, r, pen); break;
          case StatusIconKind.Console: DrawConsole(g, r, pen); break;
          case StatusIconKind.Rules: DrawRules(g, r, pen); break;
          case StatusIconKind.Voice: DrawVoice(g, r, pen, accent); break;
          case StatusIconKind.Wrench: DrawWrench(g, r, pen); break;
        }
      }
    }

    static void DrawServer(Graphics g, Rectangle r, Pen pen) {
      int x = r.X + r.Width / 6, y = r.Y + r.Height / 8, w = r.Width - r.Width / 3, h = r.Height - r.Height / 4;
      int row = Math.Max(4, h / 3 - 1);
      for (int i = 0; i < 3; i++) {
        g.DrawRectangle(pen, x, y + i * (row + 2), w, row);
        using (SolidBrush b = new SolidBrush(pen.Color))
          g.FillEllipse(b, x + 3, y + i * (row + 2) + Math.Max(1, row / 2 - 2), 4, 4);
      }
    }
    static void DrawPeople(Graphics g, Rectangle r, Pen pen) {
      int cx = r.X + r.Width / 2 - 4, cy = r.Y + r.Height / 3;
      g.DrawEllipse(pen, cx - 6, cy - 7, 12, 12);
      g.DrawArc(pen, cx - 12, cy + 7, 24, 18, 200, 140);
      g.DrawEllipse(pen, cx + 10, cy - 3, 9, 9);
      g.DrawArc(pen, cx + 6, cy + 9, 16, 14, 220, 100);
    }
    static void DrawSkin(Graphics g, Rectangle r, Pen pen) {
      int cx = r.X + r.Width / 2, cy = r.Y + r.Height / 3;
      g.DrawEllipse(pen, cx - 7, cy - 8, 14, 14);
      g.DrawArc(pen, cx - 13, cy + 8, 26, 20, 200, 140);
    }
    static void DrawClock(Graphics g, Rectangle r, Pen pen) {
      g.DrawEllipse(pen, r.X + 3, r.Y + 3, r.Width - 6, r.Height - 6);
      int cx = r.X + r.Width / 2, cy = r.Y + r.Height / 2;
      g.DrawLine(pen, cx, cy, cx, cy - r.Height / 4);
      g.DrawLine(pen, cx, cy, cx + r.Width / 5, cy + 3);
    }
    static void DrawMemory(Graphics g, Rectangle r, Pen pen) {
      int x = r.X + r.Width / 6, y = r.Y + r.Height / 4, w = r.Width - r.Width / 3, h = r.Height / 2;
      g.DrawRectangle(pen, x, y, w, h);
      int step = Math.Max(4, w / 4);
      for (int i = 0; i < 4; i++) {
        int px = x + 3 + i * step;
        g.DrawLine(pen, px, y, px, y - 3);
        g.DrawLine(pen, px, y + h, px, y + h + 3);
      }
      g.DrawLine(pen, x + 4, y + h / 2, x + w - 4, y + h / 2);
    }
    static void DrawDisk(Graphics g, Rectangle r, Pen pen) {
      g.DrawEllipse(pen, r.X + 3, r.Y + 3, r.Width - 6, r.Height - 6);
      g.DrawEllipse(pen, r.X + r.Width / 2 - 5, r.Y + r.Height / 2 - 5, 10, 10);
      g.DrawEllipse(pen, r.X + r.Width / 2 - 2, r.Y + r.Height / 2 - 2, 4, 4);
    }
    static void DrawGlobe(Graphics g, Rectangle r, Pen pen) {
      g.DrawEllipse(pen, r.X + 3, r.Y + 3, r.Width - 6, r.Height - 6);
      g.DrawEllipse(pen, r.X + r.Width / 2 - 5, r.Y + 3, 10, r.Height - 6);
      g.DrawLine(pen, r.X + 5, r.Y + r.Height / 2, r.Right - 5, r.Y + r.Height / 2);
    }
    static void DrawPlay(Graphics g, Rectangle r, Pen pen, Color accent) {
      Point[] pts = new Point[] {
        new Point(r.X + r.Width / 4, r.Y + r.Height / 6),
        new Point(r.Right - r.Width / 5, r.Y + r.Height / 2),
        new Point(r.X + r.Width / 4, r.Bottom - r.Height / 6)
      };
      using (SolidBrush b = new SolidBrush(accent)) g.FillPolygon(b, pts);
    }
    static void DrawStop(Graphics g, Rectangle r, Color accent) {
      using (SolidBrush b = new SolidBrush(accent))
        g.FillRectangle(b, r.X + r.Width / 4, r.Y + r.Height / 4, r.Width / 2, r.Height / 2);
    }
    static void DrawRestart(Graphics g, Rectangle r, Pen pen) {
      g.DrawArc(pen, r.X + 4, r.Y + 4, r.Width - 8, r.Height - 8, 35, 280);
      int tipX = r.Right - r.Width / 4, tipY = r.Y + r.Height / 5;
      g.DrawLine(pen, tipX - 7, tipY, tipX, tipY);
      g.DrawLine(pen, tipX, tipY, tipX, tipY + 7);
    }
    static void DrawSave(Graphics g, Rectangle r, Pen pen) {
      int x = r.X + r.Width / 5, y = r.Y + r.Height / 5, w = r.Width - r.Width / 5 * 2, h = r.Height - r.Height / 5 * 2;
      Point[] pts = new Point[] {
        new Point(x, y), new Point(x + w - 6, y), new Point(x + w, y + 6),
        new Point(x + w, y + h), new Point(x, y + h)
      };
      g.DrawPolygon(pen, pts);
      g.DrawRectangle(pen, x + 4, y, w - 12, 8);
      g.DrawRectangle(pen, x + 4, y + h - 10, w - 8, 8);
    }
    static void DrawBackup(Graphics g, Rectangle r, Pen pen, Color accent) {
      int x = r.X + r.Width / 5, y = r.Y + r.Height / 4, w = r.Width - r.Width / 5 * 2, h = r.Height / 2;
      g.DrawRectangle(pen, x, y, w, h);
      g.DrawLine(pen, x, y + 6, x + w, y + 6);
      using (SolidBrush b = new SolidBrush(accent)) g.FillEllipse(b, x + w - 8, y + 2, 4, 4);
    }
    static void DrawLink(Graphics g, Rectangle r, Pen pen) {
      g.DrawArc(pen, r.X + 4, r.Y + r.Height / 3, r.Width / 2 - 2, r.Height / 3, 40, 200);
      g.DrawArc(pen, r.X + r.Width / 2 - 2, r.Y + r.Height / 3, r.Width / 2 - 2, r.Height / 3, 220, 200);
      g.DrawLine(pen, r.X + r.Width / 3, r.Y + r.Height / 2, r.Right - r.Width / 3, r.Y + r.Height / 2);
    }
    static void DrawFolder(Graphics g, Rectangle r, Pen pen) {
      int x = r.X + r.Width / 6, y = r.Y + r.Height / 3, w = r.Width - r.Width / 3, h = r.Height / 2;
      g.DrawRectangle(pen, x, y, w, h);
      g.DrawLine(pen, x, y, x + 6, y - 6);
      g.DrawLine(pen, x + 6, y - 6, x + 16, y - 6);
      g.DrawLine(pen, x + 16, y - 6, x + 20, y);
    }
    static void DrawMods(Graphics g, Rectangle r, Pen pen) {
      int pad = r.Width / 6, gap = 3;
      int cw = (r.Width - pad * 2 - gap) / 2, ch = (r.Height - pad * 2 - gap) / 2;
      g.DrawRectangle(pen, r.X + pad, r.Y + pad, cw, ch);
      g.DrawRectangle(pen, r.X + pad + cw + gap, r.Y + pad, cw, ch);
      g.DrawRectangle(pen, r.X + pad, r.Y + pad + ch + gap, cw, ch);
      g.DrawRectangle(pen, r.X + pad + cw + gap, r.Y + pad + ch + gap, cw, ch);
    }
    static void DrawDiscord(Graphics g, Rectangle r, Pen pen, Color accent) {
      g.DrawEllipse(pen, r.X + 4, r.Y + 6, r.Width - 8, r.Height - 12);
      using (SolidBrush b = new SolidBrush(accent)) {
        g.FillEllipse(b, r.X + r.Width / 3 - 2, r.Y + r.Height / 2 - 2, 5, 5);
        g.FillEllipse(b, r.Right - r.Width / 3 - 3, r.Y + r.Height / 2 - 2, 5, 5);
      }
    }
    static void DrawCamera(Graphics g, Rectangle r, Pen pen, Color accent) {
      int x = r.X + r.Width / 6, y = r.Y + r.Height / 3, w = r.Width - r.Width / 3, h = r.Height / 2;
      g.DrawRectangle(pen, x, y, w, h);
      g.DrawRectangle(pen, x + w / 4, y - 5, w / 2, 5);
      g.DrawEllipse(pen, x + w / 2 - 6, y + h / 2 - 6, 12, 12);
      using (SolidBrush b = new SolidBrush(accent))
        g.FillEllipse(b, x + w - 8, y + 3, 4, 4);
    }
    static void DrawGear(Graphics g, Rectangle r, Pen pen) {
      int cx = r.X + r.Width / 2, cy = r.Y + r.Height / 2, rad = Math.Min(r.Width, r.Height) / 2 - 3;
      g.DrawEllipse(pen, cx - rad / 2, cy - rad / 2, rad, rad);
      for (int i = 0; i < 6; i++) {
        double a = i * Math.PI / 3.0;
        int x1 = cx + (int)((rad / 2) * Math.Cos(a));
        int y1 = cy + (int)((rad / 2) * Math.Sin(a));
        int x2 = cx + (int)(rad * Math.Cos(a));
        int y2 = cy + (int)(rad * Math.Sin(a));
        g.DrawLine(pen, x1, y1, x2, y2);
      }
    }
    static void DrawConsole(Graphics g, Rectangle r, Pen pen) {
      g.DrawRectangle(pen, r.X + 4, r.Y + 5, r.Width - 8, r.Height - 10);
      g.DrawLine(pen, r.X + 8, r.Y + r.Height / 2, r.X + r.Width / 3, r.Bottom - 10);
      g.DrawLine(pen, r.X + 8, r.Y + r.Height / 2, r.X + r.Width / 3, r.Y + 10);
      g.DrawLine(pen, r.X + r.Width / 3 + 2, r.Bottom - 10, r.Right - 8, r.Bottom - 10);
    }
    static void DrawRules(Graphics g, Rectangle r, Pen pen) {
      g.DrawRectangle(pen, r.X + 6, r.Y + 4, r.Width - 12, r.Height - 8);
      g.DrawLine(pen, r.X + 10, r.Y + r.Height / 3, r.Right - 10, r.Y + r.Height / 3);
      g.DrawLine(pen, r.X + 10, r.Y + r.Height / 2, r.Right - 10, r.Y + r.Height / 2);
      g.DrawLine(pen, r.X + 10, r.Y + 2 * r.Height / 3, r.Right - 14, r.Y + 2 * r.Height / 3);
    }
    static void DrawVoice(Graphics g, Rectangle r, Pen pen, Color accent) {
      // Mic body + stand + sound waves
      int cx = r.X + r.Width / 2;
      int cy = r.Y + r.Height / 2;
      int mw = Math.Max(6, r.Width / 4);
      int mh = Math.Max(10, r.Height / 2);
      Rectangle mic = new Rectangle(cx - mw / 2, r.Y + r.Height / 6, mw, mh);
      g.DrawEllipse(pen, mic);
      g.DrawLine(pen, cx, mic.Bottom, cx, r.Bottom - r.Height / 6);
      g.DrawLine(pen, cx - mw, r.Bottom - r.Height / 6, cx + mw, r.Bottom - r.Height / 6);
      using (Pen wave = new Pen(accent, Math.Max(1.4f, pen.Width * 0.85f))) {
        wave.StartCap = LineCap.Round; wave.EndCap = LineCap.Round;
        int ax = mic.Right + 2;
        for (int i = 0; i < 2; i++) {
          int ox = ax + i * Math.Max(3, r.Width / 10);
          g.DrawArc(wave, ox - 2, cy - mh / 3, Math.Max(6, r.Width / 5), mh * 2 / 3, -60, 120);
        }
      }
    }
    static void DrawWrench(Graphics g, Rectangle r, Pen pen) {
      // Simple open-end wrench silhouette
      int cx = r.X + r.Width / 2, cy = r.Y + r.Height / 2;
      using (var path = new GraphicsPath()) {
        // handle
        path.AddLine(cx - r.Width / 10, r.Y + r.Height / 5, cx + r.Width / 10, r.Bottom - r.Height / 5);
        g.DrawPath(pen, path);
      }
      // head circle with gap
      int rad = Math.Max(6, r.Width / 4);
      g.DrawArc(pen, cx - rad, r.Y + r.Height / 8, rad * 2, rad * 2, 40, 280);
      // jaw notch
      g.DrawLine(pen, cx + rad / 2, r.Y + r.Height / 5, cx + rad, r.Y + r.Height / 3);
    }
  }

  public class StatusIcon : Control {
    StatusIconKind _kind = StatusIconKind.Server;
    Color _accent = Theme.Gold;
    Color _badge = Color.Empty;
    public StatusIconKind Kind {
      get { return _kind; }
      set { _kind = value; Invalidate(); }
    }
    public Color Accent {
      get { return _accent; }
      set { _accent = value; Invalidate(); }
    }
    public Color Badge {
      get { return _badge; }
      set { _badge = value; Invalidate(); }
    }
    public StatusIcon() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
      Size = new Size(44, 44);
      BackColor = Theme.Card;
    }
    protected override void OnPaint(PaintEventArgs e) {
      e.Graphics.Clear(Draw.EffectiveBack(Parent));
      e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
      Rectangle r = new Rectangle(2, 2, Width - 5, Height - 5);
      Icons.Paint(e.Graphics, r, _kind, _accent);
      if (_badge.A > 0) {
        int s = Math.Max(10, Width / 4);
        using (SolidBrush b = new SolidBrush(_badge))
          e.Graphics.FillEllipse(b, Width - s - 1, 1, s, s);
        using (Pen p = new Pen(Color.FromArgb(220, 20, 22, 16), 1.5f))
          e.Graphics.DrawEllipse(p, Width - s - 1, 1, s, s);
      }
    }
  }

  public class ActionTile : Control {
    public int CornerRadius = 18;
    public Color HoverBack = Theme.OliveBright;
    public Color PressBack = Theme.Gold;
    public Color BorderColor = Color.FromArgb(160, Theme.Cyan);
    public StatusIconKind IconKind = StatusIconKind.Play;
    public string Title = "Action";
    public string Description = "";
    public Color IconAccent = Theme.Gold;
    bool _hover, _press;
    public ActionTile() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
      Size = new Size(220, 120);
      Cursor = Cursors.Hand;
      ForeColor = Theme.Text;
      BackColor = Theme.Card;
      Font = new Font("Segoe UI Semibold", 13f, FontStyle.Bold);
    }
    protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { _hover = false; _press = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) { _press = true; Invalidate(); } base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { _press = false; Invalidate(); base.OnMouseUp(e); }
    protected override void OnPaintBackground(PaintEventArgs e) { Draw.FillParentBack(this, e); }
    protected override void OnPaint(PaintEventArgs e) {
      Draw.FillParentBack(this, e);
      e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
      e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
      Color fill = BackColor;
      if (_press) fill = PressBack;
      else if (_hover) fill = HoverBack;
      Rectangle r = new Rectangle(1, 1, Width - 3, Height - 3);
      using (GraphicsPath path = Draw.RoundRect(r, CornerRadius)) {
        using (SolidBrush b = new SolidBrush(fill)) e.Graphics.FillPath(b, path);
        using (Pen pen = new Pen(BorderColor, 1.2f)) e.Graphics.DrawPath(pen, path);
      }
      Icons.Paint(e.Graphics, new Rectangle(16, 14, 34, 34), IconKind, IconAccent);
      Color titleColor = (_press && PressBack.GetBrightness() > 0.45f) ? Color.FromArgb(28, 28, 20) : ForeColor;
      TextRenderer.DrawText(e.Graphics, Title, Font, new Rectangle(58, 16, Width - 72, 28), titleColor,
        TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
      if (!string.IsNullOrEmpty(Description)) {
        using (Font df = new Font("Segoe UI", 9.5f))
          TextRenderer.DrawText(e.Graphics, Description, df, new Rectangle(16, 58, Width - 32, Height - 70), Theme.Dim,
            TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
      }
    }
  }

  public class RoundedButton : Button {
    public int CornerRadius = 18;
    public Color HoverBack = Theme.OliveBright;
    public Color PressBack = Theme.Gold;
    public Color BorderColor = Color.FromArgb(160, Theme.Cyan);
    public bool UseGoldGradient = false;
    public bool DrawShadow = false;
    public StatusIconKind? LeadingIcon = null;
    bool _hover, _press;
    public RoundedButton() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
      FlatStyle = FlatStyle.Flat;
      FlatAppearance.BorderSize = 0;
      BackColor = Theme.Olive;
      ForeColor = Theme.Text;
      Font = new Font("Segoe UI Semibold", 11f, FontStyle.Bold);
      Cursor = Cursors.Hand;
    }
    protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { _hover = false; _press = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) { _press = true; Invalidate(); } base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { _press = false; Invalidate(); base.OnMouseUp(e); }
    // 1.0.30e: on TransparentPanel, never Clear(Theme.Bg) — that paints a dark rect behind PLAY
    protected override void OnPaintBackground(PaintEventArgs e) {
      if (Parent is TransparentPanel) return;
      Draw.FillParentBack(this, e);
    }
    protected override void OnPaint(PaintEventArgs e) {
      if (!(Parent is TransparentPanel)) Draw.FillParentBack(this, e);
      e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
      e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
      Rectangle r = new Rectangle(1, 1, Width - 3, Height - 3);
      // 1.0.30h: on TransparentPanel, clip control to pill so corners are not a black box
      if (Parent is TransparentPanel && Width > 4 && Height > 4) {
        using (GraphicsPath clip = Draw.RoundRect(new Rectangle(0, 0, Width - 1, Height - 1), CornerRadius)) {
          Region = new Region(clip);
        }
      }
      if (DrawShadow && !(Parent is TransparentPanel)) {
        using (GraphicsPath sp = Draw.RoundRect(new Rectangle(r.X + 2, r.Y + 3, r.Width, r.Height), CornerRadius))
        using (SolidBrush sb = new SolidBrush(Color.FromArgb(60, 0, 0, 0)))
          e.Graphics.FillPath(sb, sp);
      }
      using (GraphicsPath path = Draw.RoundRect(r, CornerRadius)) {
        if (UseGoldGradient) {
          using (LinearGradientBrush lb = new LinearGradientBrush(r, Theme.GoldBright, Theme.GoldDark, LinearGradientMode.Vertical))
            e.Graphics.FillPath(lb, path);
        } else {
          Color fill = BackColor;
          if (_press) fill = PressBack;
          else if (_hover) fill = HoverBack;
          using (SolidBrush b = new SolidBrush(fill)) e.Graphics.FillPath(b, path);
        }
        using (Pen pen = new Pen(BorderColor, 1.2f)) e.Graphics.DrawPath(pen, path);
      }
      Color tc = ForeColor;
      if (UseGoldGradient) tc = Color.White;
      else if (_press && PressBack.GetBrightness() > 0.45f) tc = Color.FromArgb(10, 14, 30);
      int textLeft = 8;
      if (LeadingIcon.HasValue) {
        int isz = Math.Min(22, Height - 10);
        Icons.Paint(e.Graphics, new Rectangle(12, (Height - isz) / 2, isz, isz), LeadingIcon.Value, tc);
        textLeft = 12 + isz + 6;
      }
      TextRenderer.DrawText(e.Graphics, Text, Font, new Rectangle(textLeft, 0, Width - textLeft - 8, Height), tc,
        TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
    }
  }

  public class PillToggle : Control {
    bool _checked;
    public event EventHandler CheckedChanged;
    public bool Checked {
      get { return _checked; }
      set { if (_checked != value) { _checked = value; Invalidate(); if (CheckedChanged != null) CheckedChanged(this, EventArgs.Empty); } }
    }
    public string OnText = "ON";
    public string OffText = "OFF";
    public PillToggle() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
      Size = new Size(56, 28);
      Cursor = Cursors.Hand;
    }
    protected override void OnMouseClick(MouseEventArgs e) { if (e.Button == MouseButtons.Left) Checked = !Checked; base.OnMouseClick(e); }
    protected override void OnPaintBackground(PaintEventArgs e) { Draw.FillParentBack(this, e); }
    protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }
    protected override void OnPaint(PaintEventArgs e) {
      Draw.FillParentBack(this, e);
      e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
      e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
      Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
      Color track = _checked ? Theme.Online : Theme.TrackOff;
      using (GraphicsPath path = Draw.RoundRect(r, Height / 2))
      using (SolidBrush b = new SolidBrush(track))
        e.Graphics.FillPath(b, path);
      int knob = Height - 6;
      int kx = _checked ? Width - knob - 3 : 3;
      using (SolidBrush b = new SolidBrush(Theme.Knob))
        e.Graphics.FillEllipse(b, kx, 3, knob, knob);
    }
  }

  public class CardPanel : Panel {
    public int CornerRadius = 16;
    Color _fill = Theme.Card;
    public Color Fill {
      get { return _fill; }
      set { _fill = value; BackColor = Color.FromArgb(255, value.R, value.G, value.B); Invalidate(); }
    }
    public Color Border = Color.FromArgb(140, Theme.Cyan);
    public int FillAlpha = 255;
    public CardPanel() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
      BackColor = Theme.Card;
    }
    protected override void OnPaintBackground(PaintEventArgs e) {
      Draw.FillParentBack(this, e);
    }
    protected override void OnPaint(PaintEventArgs e) {
      e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
      Rectangle r = new Rectangle(1, 1, Width - 3, Height - 3);
      e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
      Color fill = Color.FromArgb(Math.Min(255, FillAlpha), Fill);
      using (GraphicsPath path = Draw.RoundRect(r, CornerRadius)) {
        using (SolidBrush b = new SolidBrush(fill)) e.Graphics.FillPath(b, path);
        using (Pen pen = new Pen(Border, 1.2f)) e.Graphics.DrawPath(pen, path);
      }
    }
  }

  public class DarkTextBox : TextBox {
    public DarkTextBox() {
      BorderStyle = BorderStyle.FixedSingle;
      BackColor = Theme.Input;
      ForeColor = Theme.Text;
      Font = new Font("Segoe UI Semibold", 11f);
    }
  }

  // Label that does not fill Theme.Bg behind text (true see-through on TransparentPanel).
  public class GlassLabel : Label {
    public GlassLabel() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
      BackColor = Color.Transparent;
      AutoSize = true;
    }
    protected override void OnPaintBackground(PaintEventArgs e) { Draw.PaintCityBehind(this, e); }
    public override Size GetPreferredSize(Size proposedSize) {
      Size sz = TextRenderer.MeasureText(Text ?? "", Font);
      return new Size(sz.Width + 4, sz.Height + 2);
    }
    protected override void OnPaint(PaintEventArgs e) {
      Draw.PaintCityBehind(this, e);
      e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
      TextRenderer.DrawText(e.Graphics, Text ?? "", Font, ClientRectangle, ForeColor,
        TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
    }
  }

  // 1.0.30n: paint city WITHOUT readability wash (parent UserPaint cannot show through; wash was double-dark strip)
  public class TransparentTableLayoutPanel : TableLayoutPanel {
    public TransparentTableLayoutPanel() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
      BackColor = Color.Transparent;
    }
    protected override void OnPaintBackground(PaintEventArgs e) { Draw.PaintCityBehind(this, e); }
    protected override void OnPaint(PaintEventArgs e) { Draw.PaintCityBehind(this, e); }
  }

  public class TransparentPanel : Panel {
    public TransparentPanel() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
      BackColor = Color.Transparent;
      AutoScroll = false;
    }
    protected override void OnPaintBackground(PaintEventArgs e) { Draw.PaintCityBehind(this, e); }
    protected override void OnPaint(PaintEventArgs e) { Draw.PaintCityBehind(this, e); }
  }

  public class RoundedProgress : Control {
    int _value;
    public int Value {
      get { return _value; }
      set { _value = Math.Max(0, Math.Min(100, value)); Invalidate(); }
    }
    public int CornerRadius = 10;
    public RoundedProgress() {
      Height = 14;
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
      BackColor = Theme.Input;
    }
    protected override void OnPaintBackground(PaintEventArgs e) { Draw.FillParentBack(this, e); }
    protected override void OnPaint(PaintEventArgs e) {
      Draw.FillParentBack(this, e);
      e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
      e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
      Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
      using (GraphicsPath path = Draw.RoundRect(r, CornerRadius)) {
        using (SolidBrush ib = new SolidBrush(Theme.Input)) e.Graphics.FillPath(ib, path);
        using (SolidBrush b = new SolidBrush(Color.FromArgb(80, Theme.Panel))) e.Graphics.FillPath(b, path);
        if (_value > 0) {
          int fw = Math.Max(CornerRadius * 2, (int)((Width - 1) * (_value / 100.0)));
          Rectangle fr = new Rectangle(0, 0, fw, Height - 1);
          using (GraphicsPath fp = Draw.RoundRect(fr, CornerRadius))
          using (LinearGradientBrush lb = new LinearGradientBrush(fr, Theme.GoldBright, Theme.GoldDark, LinearGradientMode.Vertical))
            e.Graphics.FillPath(lb, fp);
        }
      }
    }
  }

  // RichTextBox without stock white scrollbar chrome. Wheel still scrolls via EM_LINESCROLL.
  // ScrollBars.None is reliable for DrawToBitmap; ShowScrollBar alone is overwritten by WinForms.
  public class DarkRichTextBox : RichTextBox {
    const int WM_MOUSEWHEEL = 0x020A;
    const int EM_LINESCROLL = 0x00B6;

    [DllImport("user32.dll")]
    static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

    public DarkRichTextBox() {
      BorderStyle = BorderStyle.None;
      BackColor = Theme.Input;
      ForeColor = Theme.Text;
      ScrollBars = RichTextBoxScrollBars.None;
      DetectUrls = false;
    }

    protected override void WndProc(ref Message m) {
      if (m.Msg == WM_MOUSEWHEEL) {
        int delta = (short)((m.WParam.ToInt64() >> 16) & 0xFFFF);
        int lines = delta > 0 ? -3 : 3;
        SendMessage(Handle, EM_LINESCROLL, IntPtr.Zero, (IntPtr)lines);
        m.Result = IntPtr.Zero;
        return;
      }
      base.WndProc(ref m);
    }
  }

  // Lightweight software-rendered Minecraft skin preview (boxy UV cubes). Drag to yaw, idle spin, double-click reset.
  /// <summary>Shared high-resolution animation clock (~120 Hz multimedia timer).
  /// One coalesced UI marshal per tick; subscribers use time-based interpolation.</summary>
  internal interface IAnimTarget {
    void AnimTick(double nowSec);
    Control AnimControl { get; }
  }

  internal static class AnimClock {
    [DllImport("winmm.dll")] static extern uint timeBeginPeriod(uint uPeriod);
    [DllImport("winmm.dll")] static extern uint timeEndPeriod(uint uPeriod);
    [DllImport("winmm.dll")] static extern uint timeSetEvent(uint uDelay, uint uResolution, TimerProc lpTimeProc, IntPtr dwUser, uint fuEvent);
    [DllImport("winmm.dll")] static extern uint timeKillEvent(uint uTimerID);
    delegate void TimerProc(uint uTimerID, uint uMsg, IntPtr dwUser, IntPtr dw1, IntPtr dw2);
    const uint TIME_PERIODIC = 1;
    static readonly object Gate = new object();
    static readonly System.Collections.Generic.List<WeakReference> Subs = new System.Collections.Generic.List<WeakReference>(8);
    static uint TimerId;
    static TimerProc ProcKeepAlive;
    static bool PeriodOn;
    static System.Threading.Timer Fallback;
    static readonly System.Diagnostics.Stopwatch Sw = System.Diagnostics.Stopwatch.StartNew();
    static int PumpPosted;
    public static int LastFps;
    public static double LastFrameMsAvg;
    public static double LastFrameMsVar;
    static int _fpsCount;
    static double _fpsWindowStart;
    static double _sumDt, _sumDt2;
    static int _dtN;
    static double _lastPump;

    public static double NowSec { get { return Sw.Elapsed.TotalSeconds; } }

    public static void Subscribe(IAnimTarget t) {
      if (t == null) return;
      lock (Gate) {
        for (int i = Subs.Count - 1; i >= 0; i--) {
          object o = Subs[i].Target;
          if (o == null || object.ReferenceEquals(o, t)) Subs.RemoveAt(i);
        }
        Subs.Add(new WeakReference(t));
        EnsureTimer();
      }
    }
    public static void Unsubscribe(IAnimTarget t) {
      lock (Gate) {
        for (int i = Subs.Count - 1; i >= 0; i--) {
          object o = Subs[i].Target;
          if (o == null || object.ReferenceEquals(o, t)) Subs.RemoveAt(i);
        }
        if (Subs.Count == 0) KillTimer();
      }
    }
    static void EnsureTimer() {
      if (TimerId != 0 || Fallback != null) return;
      if (!PeriodOn) { try { timeBeginPeriod(1); PeriodOn = true; } catch { } }
      ProcKeepAlive = OnMmTick;
      try { TimerId = timeSetEvent(8, 1, ProcKeepAlive, IntPtr.Zero, TIME_PERIODIC); } catch { TimerId = 0; }
      if (TimerId == 0) {
        Fallback = new System.Threading.Timer(_ => Pump(), null, 0, 8);
      }
    }
    static void KillTimer() {
      if (TimerId != 0) { try { timeKillEvent(TimerId); } catch { } TimerId = 0; }
      if (Fallback != null) { try { Fallback.Dispose(); } catch { } Fallback = null; }
      if (PeriodOn) { try { timeEndPeriod(1); } catch { } PeriodOn = false; }
      System.Threading.Interlocked.Exchange(ref PumpPosted, 0);
    }
    static void OnMmTick(uint id, uint msg, IntPtr user, IntPtr dw1, IntPtr dw2) { Pump(); }

    static void Pump() {
      double now = NowSec;
      if (_lastPump > 0) {
        double dtMs = (now - _lastPump) * 1000.0;
        if (dtMs > 0 && dtMs < 200) {
          _sumDt += dtMs; _sumDt2 += dtMs * dtMs; _dtN++;
        }
      }
      _lastPump = now;
      _fpsCount++;
      if (_fpsWindowStart <= 0) _fpsWindowStart = now;
      if (now - _fpsWindowStart >= 1.0) {
        LastFps = _fpsCount;
        if (_dtN > 1) {
          LastFrameMsAvg = _sumDt / _dtN;
          double mean = LastFrameMsAvg;
          LastFrameMsVar = Math.Max(0.0, (_sumDt2 / _dtN) - (mean * mean));
        }
        _fpsCount = 0; _fpsWindowStart = now; _sumDt = 0; _sumDt2 = 0; _dtN = 0;
      }

      // Coalesce: at most one UI marshal in flight
      if (System.Threading.Interlocked.CompareExchange(ref PumpPosted, 1, 0) != 0) return;

      Control marshal = null;
      IAnimTarget[] snap;
      lock (Gate) {
        var list = new System.Collections.Generic.List<IAnimTarget>(Subs.Count);
        for (int i = Subs.Count - 1; i >= 0; i--) {
          IAnimTarget t = Subs[i].Target as IAnimTarget;
          if (t == null) { Subs.RemoveAt(i); continue; }
          list.Add(t);
          if (marshal == null) {
            try {
              Control c = t.AnimControl;
              if (c != null && !c.IsDisposed && c.IsHandleCreated) marshal = c;
            } catch { }
          }
        }
        if (Subs.Count == 0) {
          System.Threading.Interlocked.Exchange(ref PumpPosted, 0);
          KillTimer();
          return;
        }
        snap = list.ToArray();
      }
      if (marshal == null) {
        System.Threading.Interlocked.Exchange(ref PumpPosted, 0);
        return;
      }
      try {
        marshal.BeginInvoke(new Action(() => {
          try {
            double n = NowSec;
            for (int i = 0; i < snap.Length; i++) {
              try { snap[i].AnimTick(n); } catch { }
            }
          } finally {
            System.Threading.Interlocked.Exchange(ref PumpPosted, 0);
          }
        }));
      } catch {
        System.Threading.Interlocked.Exchange(ref PumpPosted, 0);
      }
    }
  }

  public class SkinPreview3D : Control, IAnimTarget {
    Bitmap _skin;
    bool _slim;
    float _yaw = 20f;
    bool _dragging;
    int _lastX;
    bool _idle = true;
    bool _tickPending;
    double _lastTickSec;
    double _lastPaintSec;
    public Control AnimControl { get { return this; } }
    public bool IdleSpin {
      get { return _idle; }
      set { _idle = value; }
    }
    public bool Slim { get { return _slim; } set { _slim = value; Invalidate(); } }
    public SkinPreview3D() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
      BackColor = Color.Transparent;
      DoubleBuffered = true;
      _lastTickSec = AnimClock.NowSec;
      AnimClock.Subscribe(this);
    }
    public void AnimTick(double nowSec) {
      if (_tickPending) return;
      if (_dragging) { _lastTickSec = nowSec; return; }
      if (!_idle) { _lastTickSec = nowSec; return; }
      if (!Visible || !IsHandleCreated) return;
      Form f = FindForm();
      if (f != null && (f.WindowState == FormWindowState.Minimized || !f.Visible)) return;
      double dt = nowSec - _lastTickSec;
      if (dt < 0) dt = 0;
      if (dt > 0.05) dt = 0.05;
      _lastTickSec = nowSec;
      _yaw += (float)(63.0 * dt);
      if (_yaw > 360f) _yaw -= 360f;
      if (nowSec - _lastPaintSec < (1.0 / 72.0)) return;
      _lastPaintSec = nowSec;
      _tickPending = true;
      try { Invalidate(false); } finally { _tickPending = false; }
    }

    public void SetSkin(Bitmap skin, bool slim) {
      if (_skin != null) { try { _skin.Dispose(); } catch {} _skin = null; }
      if (skin != null) _skin = (Bitmap)skin.Clone();
      _slim = slim;
      Invalidate();
    }
    public void ResetYaw() { _yaw = 20f; Invalidate(); }
    protected override void Dispose(bool disposing) {
      if (disposing) {
        try { AnimClock.Unsubscribe(this); } catch { }
        if (_skin != null) { _skin.Dispose(); _skin = null; }
      }
      base.Dispose(disposing);
    }
    protected override void OnMouseDown(MouseEventArgs e) {
      base.OnMouseDown(e);
      if (e.Button == MouseButtons.Left) { _dragging = true; _lastX = e.X; _idle = false; }
    }
    protected override void OnMouseMove(MouseEventArgs e) {
      base.OnMouseMove(e);
      if (_dragging) {
        _yaw += (e.X - _lastX) * 0.8f;
        _lastX = e.X;
        Invalidate();
      }
    }
    protected override void OnMouseUp(MouseEventArgs e) {
      base.OnMouseUp(e);
      if (e.Button == MouseButtons.Left) { _dragging = false; _idle = true; }
    }
    protected override void OnDoubleClick(EventArgs e) { base.OnDoubleClick(e); ResetYaw(); _idle = true; }
    protected override void OnPaintBackground(PaintEventArgs e) { /* transparent */ }
    protected override void OnPaint(PaintEventArgs e) {
      Graphics g = e.Graphics;
      g.SmoothingMode = SmoothingMode.AntiAlias;
      g.PixelOffsetMode = PixelOffsetMode.HighQuality;
      g.InterpolationMode = InterpolationMode.NearestNeighbor;
      // Subtle dark gradient backdrop (not pure black)
      Rectangle full = ClientRectangle;
      if (full.Width < 1 || full.Height < 1) return;
      using (LinearGradientBrush bg = new LinearGradientBrush(full,
          Color.FromArgb(255, 5, 8, 18), Color.FromArgb(255, 18, 10, 36), 90f))
        g.FillRectangle(bg, full);
      using (LinearGradientBrush vig = new LinearGradientBrush(
          new Rectangle(0, 0, Math.Max(1, Width), Math.Max(1, Height / 3)),
          Color.FromArgb(90, 0, 180, 220), Color.FromArgb(0, 0, 0, 0), 90f))
        g.FillRectangle(vig, 0, 0, Width, Height / 3);
      int cx = Width / 2;
      // Player is ~32 units tall; fill ~70% of viewport height
      float scale = Math.Max(2.8f, (Height * 0.70f) / 32f);
      if (scale * 18f > Width * 0.92f) scale = Math.Max(2.2f, (Width * 0.92f) / 18f);
      float pedW = Math.Max(72f, 16.5f * scale);
      float pedH = Math.Max(12f, 2.8f * scale);
      // Feet sit on the neon pedestal (not floating far above)
      int footY = (int)(Height * 0.78f);
      int pedTop = footY + (int)(0.4f * scale);
      Rectangle pr = new Rectangle((int)(cx - pedW / 2f), pedTop, (int)pedW, (int)pedH);
      using (GraphicsPath ring = new GraphicsPath()) {
        ring.AddEllipse(pr);
        using (PathGradientBrush glow = new PathGradientBrush(ring)) {
          glow.CenterColor = Color.FromArgb(200, Theme.Cyan);
          glow.SurroundColors = new Color[] { Color.FromArgb(0, Theme.Pink) };
          g.FillEllipse(glow, Rectangle.Inflate(pr, 10, 8));
        }
        using (LinearGradientBrush lb = new LinearGradientBrush(pr, Color.FromArgb(200, Theme.Cyan), Color.FromArgb(200, Theme.Pink), 0f))
          g.FillEllipse(lb, pr);
        using (Pen pen = new Pen(Color.FromArgb(230, Theme.Pink), 2.2f)) g.DrawEllipse(pen, pr);
        using (Pen pen2 = new Pen(Color.FromArgb(180, Theme.Cyan), 1.6f)) g.DrawEllipse(pen2, Rectangle.Inflate(pr, -6, -3));
      }
      if (_skin == null) {
        using (SolidBrush b = new SolidBrush(Theme.Dim))
        using (Font f = new Font("Segoe UI", 10f)) {
          string t = "No skin loaded";
          SizeF sz = g.MeasureString(t, f);
          g.DrawString(t, f, b, cx - sz.Width / 2, footY - 80);
        }
        DrawHint(g);
        return;
      }
      DrawPlayer(g, cx, footY, scale, _yaw, _skin, _slim);
      DrawHint(g);
    }
    void DrawHint(Graphics g) {
      using (Font f = new Font("Segoe UI", 8f))
      using (SolidBrush b = new SolidBrush(Color.FromArgb(160, Theme.Dim))) {
        string t = "drag to rotate · double-click reset";
        SizeF sz = g.MeasureString(t, f);
        g.DrawString(t, f, b, (Width - sz.Width) / 2f, Height - 18);
      }
    }
    static Color Sample(Bitmap skin, int u, int v) {
      int x = ((u % skin.Width) + skin.Width) % skin.Width;
      int y = ((v % skin.Height) + skin.Height) % skin.Height;
      return skin.GetPixel(x, y);
    }
    static void DrawTexturedBox(Graphics g, float cx, float cy, float yawDeg, float w, float h, float d, float scale, Bitmap skin,
        Rectangle front, Rectangle back, Rectangle left, Rectangle right, Rectangle top, Rectangle bottom) {
      double yaw = yawDeg * Math.PI / 180.0;
      float sx = (float)Math.Sin(yaw);
      float cxn = (float)Math.Cos(yaw);
      float fw = Math.Max(1f, w * scale);
      float fh = Math.Max(1f, h * scale + 1f); // +1 closes hairline gaps between stacked parts
      float sideW = Math.Max(1f, d * scale * Math.Abs(sx) * 0.7f);
      float frontX = cx - fw / 2f; // no shear — keeps limbs attached
      if (Math.Abs(cxn) < 0.15f) {
        // nearly profile: prefer side face
        Rectangle side = sx >= 0 ? left : right;
        DrawFace(g, skin, side, cx - sideW / 2f, cy - fh / 2f, sideW, fh);
      } else {
        if (sx >= 0)
          DrawFace(g, skin, left, frontX - sideW, cy - fh / 2f, sideW, fh);
        else
          DrawFace(g, skin, right, frontX + fw, cy - fh / 2f, sideW, fh);
        DrawFace(g, skin, front, frontX, cy - fh / 2f, fw, fh);
      }
    }
    static void DrawFace(Graphics g, Bitmap skin, Rectangle uv, float x, float y, float w, float h) {
      if (w < 0.5f || h < 0.5f) return;
      try {
        using (Bitmap face = skin.Clone(uv, skin.PixelFormat)) {
          // If UV face is empty/transparent, paint a solid sample so limbs never vanish
          bool any = false;
          for (int yy = 0; yy < face.Height && !any; yy++)
            for (int xx = 0; xx < face.Width; xx++)
              if (face.GetPixel(xx, yy).A > 16) { any = true; break; }
          if (!any) {
            using (SolidBrush b = new SolidBrush(Sample(skin, uv.X + uv.Width / 2, uv.Y + uv.Height / 2)))
              g.FillRectangle(b, x, y, (float)w, (float)h);
          } else {
            g.DrawImage(face, new RectangleF(x, y, (float)w, (float)h));
          }
        }
      } catch {
        using (SolidBrush b = new SolidBrush(Sample(skin, uv.X, uv.Y)))
          g.FillRectangle(b, x, y, (float)w, (float)h);
      }
    }
    static void DrawPlayer(Graphics g, int cx, int cy, float scale, float yaw, Bitmap skin, bool slim) {
      // cy = foot / pedestal anchor. Stack parts with 1px overlap so limbs never float.
      int armW = slim ? 3 : 4;
      float s = Math.Max(0.5f, scale);
      int legY = cy - (int)(6 * s);                 // leg center (12 tall)
      int bodyY = legY - (int)(12 * s) + 1;          // body sits on legs (+1 overlap)
      int headY = bodyY - (int)(10 * s) + 1;         // head on body (+1 overlap)
      int armY = bodyY;
      float armOff = (4f + armW / 2f - 1f) * s;      // 1 unit into torso
      float legOff = 2f * s;
      // Legs first (behind), then body, arms, head on top
      DrawPart(g, cx + (int)legOff, legY, yaw, 4, 12, 4, scale, skin,
        new Rectangle(4, 20, 4, 12), new Rectangle(12, 20, 4, 12), new Rectangle(0, 20, 4, 12), new Rectangle(8, 20, 4, 12), new Rectangle(4, 16, 4, 4), new Rectangle(8, 16, 4, 4));
      DrawPart(g, cx - (int)legOff, legY, yaw, 4, 12, 4, scale, skin,
        new Rectangle(20, 52, 4, 12), new Rectangle(28, 52, 4, 12), new Rectangle(16, 52, 4, 12), new Rectangle(24, 52, 4, 12), new Rectangle(20, 48, 4, 4), new Rectangle(24, 48, 4, 4));
      DrawPart(g, cx, bodyY, yaw, 8, 12, 4, scale, skin,
        new Rectangle(20, 20, 8, 12), new Rectangle(32, 20, 8, 12), new Rectangle(16, 20, 4, 12), new Rectangle(28, 20, 4, 12), new Rectangle(20, 16, 8, 4), new Rectangle(28, 16, 8, 4));
      DrawPart(g, cx + (int)armOff, armY, yaw, armW, 12, 4, scale, skin,
        new Rectangle(44, 20, armW, 12), new Rectangle(52, 20, armW, 12), new Rectangle(40, 20, 4, 12), new Rectangle(48, 20, 4, 12), new Rectangle(44, 16, armW, 4), new Rectangle(48, 16, armW, 4));
      DrawPart(g, cx - (int)armOff, armY, yaw, armW, 12, 4, scale, skin,
        new Rectangle(36, 52, armW, 12), new Rectangle(44, 52, armW, 12), new Rectangle(32, 52, 4, 12), new Rectangle(40, 52, 4, 12), new Rectangle(36, 48, armW, 4), new Rectangle(40, 48, armW, 4));
      DrawPart(g, cx, headY, yaw, 8, 8, 8, scale, skin,
        new Rectangle(8, 8, 8, 8), new Rectangle(24, 8, 8, 8), new Rectangle(0, 8, 8, 8), new Rectangle(16, 8, 8, 8), new Rectangle(8, 0, 8, 8), new Rectangle(16, 0, 8, 8));
    }
    static void DrawPart(Graphics g, int cx, int cy, float yaw, float w, float h, float d, float scale, Bitmap skin,
        Rectangle front, Rectangle back, Rectangle left, Rectangle right, Rectangle top, Rectangle bottom) {
      DrawTexturedBox(g, cx, cy, yaw, w, h, d, scale, skin, front, back, left, right, top, bottom);
    }
  }

  // Animated night-city background: twinkling windows, glow pulse, drifting particles, optional grid. Cap ~30fps.
  public class AnimatedCityBg : Panel, IAnimTarget {
    Image _base;
    readonly System.Collections.Generic.List<Particle> _parts = new System.Collections.Generic.List<Particle>();
    readonly System.Collections.Generic.List<WinTwinkle> _wins = new System.Collections.Generic.List<WinTwinkle>();
    readonly Random _rng = new Random(7);
    float _pulse;
    bool _enabled = true;
    bool _paused;
    long _frame;
    double _lastTickSec;
    double _lastPaintSec;
    bool _tickPending;
    SolidBrush _brParticle;
    SolidBrush _brWin;
    Bitmap _sceneBmpWash;
    Bitmap _sceneBmpNoWash;
    int _sceneW, _sceneH;
    readonly object _sceneGate = new object();
    public int MeasuredFps { get { return AnimClock.LastFps; } }
    public double MeasuredFrameMsAvg { get { return AnimClock.LastFrameMsAvg; } }
    public double MeasuredFrameMsVar { get { return AnimClock.LastFrameMsVar; } }
    public Control AnimControl { get { return this; } }
    public bool AnimEnabled {
      get { return _enabled; }
      set { _enabled = value; Invalidate(); }
    }
    public void SetPaused(bool paused) {
      _paused = paused;
    }
    public void SetBaseImage(Image img) {
      _base = img;
      Invalidate();
    }
    struct Particle { public float X,Y,Vx,Vy,Size,Alpha; }
    struct WinTwinkle { public int X,Y; public float Phase; public float Speed; }
    public AnimatedCityBg() {
      SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
      BackColor = Theme.Bg;
      DoubleBuffered = true;
      for (int i = 0; i < 48; i++) {
        _parts.Add(new Particle {
          X = _rng.Next(0, 1200), Y = _rng.Next(0, 800),
          Vx = (float)(_rng.NextDouble() * 0.25 - 0.05),
          Vy = (float)(_rng.NextDouble() * -0.15 - 0.02),
          Size = (float)(_rng.NextDouble() * 2 + 1),
          Alpha = (float)(_rng.NextDouble() * 0.6 + 0.2)
        });
      }
      for (int i = 0; i < 120; i++) {
        _wins.Add(new WinTwinkle {
          X = _rng.Next(40, 1200), Y = _rng.Next(180, 520),
          Phase = (float)_rng.NextDouble() * 6.28f,
          Speed = (float)(_rng.NextDouble() * 0.04 + 0.01)
        });
      }
      _lastTickSec = AnimClock.NowSec;
      AnimClock.Subscribe(this);
    }
    public void AnimTick(double nowSec) {
      if (_tickPending) return;
      if (!_enabled || _paused) { _lastTickSec = nowSec; return; }
      Form f = FindForm();
      if (f != null && (f.WindowState == FormWindowState.Minimized || !f.Visible)) { _lastTickSec = nowSec; return; }
      double dt = nowSec - _lastTickSec;
      if (dt < 0) dt = 0;
      if (dt > 0.05) dt = 0.05;
      _lastTickSec = nowSec;
      float step = (float)(27.5 * dt);
      float winStep = (float)(25.0 * dt);
      _frame++;
      _pulse = 0.5f + 0.5f * (float)Math.Sin(nowSec * 2.2);
      for (int i = 0; i < _parts.Count; i++) {
        Particle p = _parts[i];
        p.X += p.Vx * step; p.Y += p.Vy * step;
        if (p.Y < -5) { p.Y = Height + 5; p.X = _rng.Next(0, Math.Max(1, Width)); }
        if (p.X < -5) p.X = Width + 5;
        if (p.X > Width + 5) p.X = -5;
        _parts[i] = p;
      }
      for (int i = 0; i < _wins.Count; i++) {
        WinTwinkle w = _wins[i];
        w.Phase += w.Speed * winStep;
        _wins[i] = w;
      }
      if (nowSec - _lastPaintSec < (1.0 / 72.0)) return;
      _lastPaintSec = nowSec;
      _tickPending = true;
      try {
        EnsureSceneCache();
        // 1.0.34: invalidate city only. WS_EX_COMPOSITED redraws children together.
        // Per-frame InvalidateCityOverlays caused panels/columns to vanish on some GPUs/DPI moves.
        Invalidate(false);
      } finally { _tickPending = false; }
    }

    void InvalidateCityOverlays() {
      try {
        foreach (Control ch in Controls) InvalidateOverlayTree(ch);
      } catch { }
    }
    void InvalidateOverlayTree(Control c) {
      if (c == null || c.IsDisposed) return;
      if (c.BackColor.A < 255 || c is GlassLabel || c is TransparentPanel) {
        try { c.Invalidate(false); } catch { }
      }
      foreach (Control ch in c.Controls) InvalidateOverlayTree(ch);
    }

    public void WarmSceneCache() { EnsureSceneCache(); Invalidate(false); InvalidateCityOverlays(); }

    void EnsureSceneCache() {
      int cw = Math.Max(1, ClientSize.Width), ch = Math.Max(1, ClientSize.Height);
      lock (_sceneGate) {
        if (_sceneBmpWash == null || _sceneBmpNoWash == null || _sceneW != cw || _sceneH != ch) {
          if (_sceneBmpWash != null) { try { _sceneBmpWash.Dispose(); } catch { } }
          if (_sceneBmpNoWash != null) { try { _sceneBmpNoWash.Dispose(); } catch { } }
          _sceneBmpWash = new Bitmap(cw, ch, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
          _sceneBmpNoWash = new Bitmap(cw, ch, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
          _sceneW = cw; _sceneH = ch;
        }
        using (Graphics g = Graphics.FromImage(_sceneBmpNoWash)) { PaintScene(g, false); }
        using (Graphics g = Graphics.FromImage(_sceneBmpWash)) { PaintScene(g, true); }
      }
    }

    public bool BlitCachedScene(Graphics g, int dx, int dy, bool wantWash) {
      if (g == null) return false;
      lock (_sceneGate) {
        Bitmap src = wantWash ? _sceneBmpWash : _sceneBmpNoWash;
        if (src == null) return false;
        g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
        g.DrawImageUnscaled(src, dx, dy);
        g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
        return true;
      }
    }

    protected override void Dispose(bool disposing) {
      if (disposing) {
        try { AnimClock.Unsubscribe(this); } catch { }
        if (_brParticle != null) { try { _brParticle.Dispose(); } catch { } _brParticle = null; }
        if (_brWin != null) { try { _brWin.Dispose(); } catch { } _brWin = null; }
        if (_sceneBmpWash != null) { try { _sceneBmpWash.Dispose(); } catch { } _sceneBmpWash = null; }
        if (_sceneBmpNoWash != null) { try { _sceneBmpNoWash.Dispose(); } catch { } _sceneBmpNoWash = null; }
      }
      base.Dispose(disposing);
    }
    public void PaintScene(Graphics g, bool includeWash) {
      if (g == null) return;
      g.SmoothingMode = SmoothingMode.AntiAlias;
      g.InterpolationMode = InterpolationMode.HighQualityBicubic;
      g.Clear(Theme.Bg);
      int cw = Math.Max(1, ClientSize.Width), ch = Math.Max(1, ClientSize.Height);
      if (_base != null) {
        float scale = Math.Max(cw / (float)_base.Width, ch / (float)_base.Height);
        int dw = (int)(_base.Width * scale), dh = (int)(_base.Height * scale);
        int dx = (cw - dw) / 2, dy = (ch - dh) / 2;
        g.DrawImage(_base, dx, dy, dw, dh);
      } else {
        // procedural skyline fallback
        using (LinearGradientBrush sky = new LinearGradientBrush(new Rectangle(0, 0, cw, ch), Color.FromArgb(6, 8, 24), Color.FromArgb(40, 12, 48), 90f))
          g.FillRectangle(sky, 0, 0, cw, ch);
        using (SolidBrush bldg = new SolidBrush(Color.FromArgb(12, 10, 28))) {
          int x = 0;
          while (x < cw) {
            int bw = 28 + (x * 17 + 13) % 50;
            int bh = 80 + (x * 37 + 29) % (ch / 2);
            g.FillRectangle(bldg, x, ch - bh - 40, bw, bh);
            x += bw + 4;
          }
        }
      }
      if (_enabled) {
        if (_brWin == null) _brWin = new SolidBrush(Color.FromArgb(200, 255, 220, 160));
        if (_brParticle == null) _brParticle = new SolidBrush(Color.FromArgb(180, Theme.Cyan));
        foreach (WinTwinkle w in _wins) {
          float a = 0.15f + 0.85f * (0.5f + 0.5f * (float)Math.Sin(w.Phase));
          int px = (int)(w.X / 1200f * cw);
          int py = (int)(w.Y / 800f * ch);
          _brWin.Color = Color.FromArgb((int)(a * 200), 255, 220, 160);
          g.FillRectangle(_brWin, px, py, 2, 2);
        }
        foreach (Particle p in _parts) {
          _brParticle.Color = Color.FromArgb((int)(p.Alpha * 180), Theme.Cyan);
          g.FillEllipse(_brParticle, p.X, p.Y, p.Size, p.Size);
        }
        // soft glow pulse wash (low amplitude — avoids whole-window pink flash)
        using (SolidBrush wash = new SolidBrush(Color.FromArgb((int)(10 + 8 * _pulse), Theme.Pink)))
          g.FillRectangle(wash, 0, (int)(ch * 0.55), cw, (int)(ch * 0.45));
        // reflective water strip
        using (LinearGradientBrush water = new LinearGradientBrush(new Rectangle(0, ch - 50, cw, 50), Color.FromArgb(60, 0, 40, 80), Color.FromArgb(120, 0, 10, 30), 90f))
          g.FillRectangle(water, 0, ch - 50, cw, 50);
      }
      // dark glass wash for readability (skipped when blitting into transparent children — 1.0.30n)
      if (includeWash) {
        using (SolidBrush ov = new SolidBrush(Color.FromArgb(110, 4, 8, 22)))
          g.FillRectangle(ov, 0, 0, cw, ch);
      }
      // neon frame
      if (cw > 8 && ch > 8) {
        Rectangle rect = new Rectangle(2, 2, cw - 5, ch - 5);
        using (GraphicsPath path = Draw.RoundRect(rect, 18))
        using (LinearGradientBrush lb = new LinearGradientBrush(rect, Theme.Cyan, Theme.Pink, 0f))
        using (Pen pen = new Pen(lb, 2.2f))
          g.DrawPath(pen, path);
      }
    }
    protected override void OnPaintBackground(PaintEventArgs e) {
      // suppress erase flash
    }
    protected override void OnPaint(PaintEventArgs e) {
      if (!BlitCachedScene(e.Graphics, 0, 0, true)) {
        EnsureSceneCache();
        if (!BlitCachedScene(e.Graphics, 0, 0, true))
          PaintScene(e.Graphics, true);
      }
    }
    protected override CreateParams CreateParams {
      get {
        CreateParams cp = base.CreateParams;
        cp.ExStyle |= 0x02000000; // WS_EX_COMPOSITED
        return cp;
      }
    }
  }
}
