﻿# NORCOM Fabric dependency audit (dot-sourced by NORCOM-Launcher.ps1)
function Test-FabricDependencies {
  param(
    [Parameter(Mandatory)][string]$ModsDir,
    [switch]$AutoFix,
    [scriptblock]$Log = { param($m) Write-Host $m }
  )
  Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
  $provided = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
  $required = New-Object System.Collections.ArrayList
  $builtin = @(
    'minecraft','fabricloader','fabric-loader','java','fabric',
    'fabric-api','fabric_api'  # often declared; usually present as fabric-api jar id
  )
  foreach ($b in $builtin) { [void]$provided.Add([string]$b) }

  function Read-ModJsonText([IO.Compression.ZipArchive]$zip, [string]$entryName) {
    $e = $zip.GetEntry($entryName)
    if ($null -eq $e) { return $null }
    $sr = New-Object IO.StreamReader($e.Open())
    try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
  }

  function Ingest-Jar([string]$jarPath, [int]$depth) {
    if ($depth -gt 4) { return }
    if (-not (Test-Path -LiteralPath $jarPath)) { return }
    $zip = $null
    try { $zip = [IO.Compression.ZipFile]::OpenRead($jarPath) } catch { return }
    try {
      $raw = Read-ModJsonText $zip 'fabric.mod.json'
      if ($raw) {
        $json = $null
        try { $json = $raw | ConvertFrom-Json } catch { $json = $null }
        if ($null -ne $json) {
          $id = [string]$json.id
          if (-not [string]::IsNullOrWhiteSpace($id)) { [void]$provided.Add($id) }
          $provides = $json.provides
          if ($null -ne $provides) {
            foreach ($p in @($provides)) {
              $ps = [string]$p
              if (-not [string]::IsNullOrWhiteSpace($ps)) { [void]$provided.Add($ps) }
            }
          }
          $depends = $json.depends
          if ($null -ne $depends) {
            foreach ($prop in $depends.PSObject.Properties) {
              $depId = [string]$prop.Name
              if ([string]::IsNullOrWhiteSpace($depId)) { continue }
              $low = $depId.ToLowerInvariant()
              if ($builtin -contains $low) { continue }
              [void]$required.Add([pscustomobject]@{
                Mod  = $id
                Needs = $depId
                From = [IO.Path]::GetFileName($jarPath)
              })
            }
          }
          $jars = $json.jars
          if ($null -ne $jars) {
            foreach ($nj in @($jars)) {
              $file = $null
              try { $file = [string]$nj.file } catch { $file = $null }
              if ([string]::IsNullOrWhiteSpace($file)) { continue }
              $nestedEntry = $zip.GetEntry(($file -replace '\\','/'))
              if ($null -eq $nestedEntry) { continue }
              $tmp = Join-Path $env:TEMP ('norcom-nested-' + [Guid]::NewGuid().ToString('N') + '.jar')
              try {
                $fs = [IO.File]::Create($tmp)
                $ns = $nestedEntry.Open()
                try { $ns.CopyTo($fs) } finally { if ($ns) { $ns.Dispose() }; if ($fs) { $fs.Dispose() } }
                Ingest-Jar $tmp ($depth + 1)
              } catch {
              } finally {
                Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
              }
            }
          }
        }
      }
      foreach ($e in $zip.Entries) {
        $name = [string]$e.FullName
        if ($name -match '^META-INF/(jars|jarjar)/[^/]+\.jar$') {
          $tmp = Join-Path $env:TEMP ('norcom-nested-' + [Guid]::NewGuid().ToString('N') + '.jar')
          try {
            $fs = [IO.File]::Create($tmp)
            $ns = $e.Open()
            try { $ns.CopyTo($fs) } finally { if ($ns) { $ns.Dispose() }; if ($fs) { $fs.Dispose() } }
            Ingest-Jar $tmp ($depth + 1)
          } catch {
          } finally {
            Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
          }
        }
      }
    } finally {
      if ($zip) { $zip.Dispose() }
    }
  }

  Get-ChildItem -LiteralPath $ModsDir -Filter '*.jar' -File -ErrorAction SilentlyContinue | ForEach-Object {
    Ingest-Jar $_.FullName 0
  }

  $missingList = New-Object System.Collections.ArrayList
  $seenNeed = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
  foreach ($r in $required) {
    if ($provided.Contains([string]$r.Needs)) { continue }
    if (-not $seenNeed.Add([string]$r.Needs)) { continue }
    [void]$missingList.Add($r)
  }

  $fixedList = New-Object System.Collections.ArrayList
  if ($AutoFix -and $missingList.Count -gt 0) {
    $headers = @{ 'User-Agent'='NORCOM-Installer/1.0.1'; 'Accept'='application/json' }
    foreach ($m in @($missingList)) {
      try {
        $proj = $null
        try { $proj = Invoke-RestMethod -Uri ("https://api.modrinth.com/v2/project/" + [uri]::EscapeDataString($m.Needs)) -Headers $headers -TimeoutSec 12 } catch { $proj = $null }
        if ($null -eq $proj) {
          $q = [uri]::EscapeDataString([string]$m.Needs)
          $facets = [uri]::EscapeDataString('[["project_type:mod"],["versions:26.3"],["categories:fabric"]]')
          $search = Invoke-RestMethod -Uri "https://api.modrinth.com/v2/search?query=$q&limit=8&facets=$facets" -Headers $headers -TimeoutSec 15
          $hit = $null
          foreach ($h in @($search.hits)) {
            $slug = [string]$h.slug
            if ($slug -eq $m.Needs -or [string]$h.project_id -eq $m.Needs) { $hit = $h; break }
            if (($slug -replace '-','') -eq (($m.Needs) -replace '-','')) { $hit = $h; break }
          }
          if ($null -eq $hit) { continue }
          $proj = Invoke-RestMethod -Uri ("https://api.modrinth.com/v2/project/" + $hit.project_id) -Headers $headers -TimeoutSec 12
        }
        $loaders = [uri]::EscapeDataString('["fabric"]')
        $games = [uri]::EscapeDataString('["26.3"]')
        $vers = Invoke-RestMethod -Uri ("https://api.modrinth.com/v2/project/$($proj.id)/version?loaders=$loaders&game_versions=$games") -Headers $headers -TimeoutSec 15
        $ver = @($vers) | Select-Object -First 1
        if ($null -eq $ver) { continue }
        $file = $null
        foreach ($f in @($ver.files)) { if ($f.primary) { $file = $f; break } }
        if ($null -eq $file) { $file = @($ver.files) | Select-Object -First 1 }
        if ($null -eq $file) { continue }
        $dest = Join-Path $ModsDir ([string]$file.filename)
        if (-not (Test-Path -LiteralPath $dest)) {
          Invoke-WebRequest -Uri ([string]$file.url) -OutFile $dest -UseBasicParsing -TimeoutSec 120
          & $Log ("Auto-fixed missing dep '{0}' (needed by {1}): {2}" -f $m.Needs, $m.Mod, $file.filename)
        }
        Ingest-Jar $dest 0
        [void]$fixedList.Add([string]$file.filename)
      } catch {
        & $Log ("Could not auto-fix '{0}': {1}" -f $m.Needs, $_.Exception.Message)
      }
    }
    $missingList = New-Object System.Collections.ArrayList
    $seen2 = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($r in $required) {
      if ($provided.Contains([string]$r.Needs)) { continue }
      if (-not $seen2.Add([string]$r.Needs)) { continue }
      [void]$missingList.Add($r)
    }
  }

  return [pscustomobject]@{
    ProvidedCount = $provided.Count
    Missing = @($missingList)
    Fixed = @($fixedList)
  }
}
