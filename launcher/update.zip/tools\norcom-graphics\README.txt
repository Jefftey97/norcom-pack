NORCOM Graphics Profiles
========================

Double-click:
  Enable NORCOM Ultra Graphics.lnk  - high-end visuals + Patrix sand waves
  Enable NORCOM Normal Graphics.lnk - Faithful default look

Ultra uses:
  - Complementary Unbound ULTRA profile
  - RP Support = labPBR
  - POM (parallax) depth/quality high for sand waves
  - Patrix 32x basic + addon ON TOP of Faithful (models OFF)
  - Strong shadows, SSAO, water, clouds, bloom, TAA, DH HIGH

If Minecraft is open: restart it, or press R to reload shaders.

Persistence:
  Marker at %APPDATA%\.norcom\norcom-graphics\profile.marker
  Local packwiz hashes are updated so sync does not instantly wipe the profile.
  Launcher should also run reapply-after-sync.ps1 after packwiz sync.
