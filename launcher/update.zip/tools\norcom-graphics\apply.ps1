param(
  [Parameter(Mandatory=$true)][ValidateSet('ULTRA','NORMAL','LOW','MEDIUM','MEDIUM_HIGH','HIGH')][string]$Profile,
  [switch]$Quiet,
  [switch]$NoMessage
)

$ErrorActionPreference = 'Stop'
$norcom = if ($env:NORCOM_GAMEDIR -and $env:NORCOM_GAMEDIR.Trim()) { $env:NORCOM_GAMEDIR.Trim() } else { Join-Path $env:APPDATA '.norcom' }
$gfx = Join-Path $norcom 'norcom-graphics'
$src = Join-Path $gfx $Profile.ToLowerInvariant()
if (-not (Test-Path $src)) { throw "Missing profile folder: $src" }

function Write-Utf8NoBom([string]$Path, [string]$Content) {
  $utf8 = New-Object System.Text.UTF8Encoding $false
  [System.IO.File]::WriteAllText($Path, $Content, $utf8)
}

function Backup-Current([string]$Tag) {
  $ts = Get-Date -Format 'yyyyMMdd-HHmmss'
  $dest = Join-Path $norcom ("norcom-backups\{0}-{1}" -f $Tag.ToLowerInvariant(), $ts)
  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  $files = @(
    'options.txt',
    'options.norcom.txt',
    'config\iris.properties',
    'config\sodium-options.json',
    'config\DistantHorizons.toml',
    'shaderpacks\ComplementaryUnbound_r5.9.3.zip.txt',
    'shaderpacks\ComplementaryUnbound_r5.9.3.txt',
    'packwiz.json'
  )
  foreach ($rel in $files) {
    $p = Join-Path $norcom $rel
    if (Test-Path $p) {
      $target = Join-Path $dest $rel
      $dir = Split-Path $target -Parent
      if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
      Copy-Item $p $target -Force
    }
  }
  return $dest
}

function Set-OptionsKey([string]$OptionsPath, [hashtable]$Patches) {
  if (-not (Test-Path $OptionsPath)) { throw "Missing $OptionsPath" }
  $lines = Get-Content $OptionsPath
  $keys = @{}
  foreach ($k in $Patches.Keys) { $keys[$k] = [string]$Patches[$k] }
  $out = foreach ($line in $lines) {
    if ($line -match '^([^:]+):(.*)$') {
      $key = $Matches[1]
      if ($keys.ContainsKey($key)) {
        $val = $keys[$key]
        $keys.Remove($key)
        "${key}:${val}"
      } else { $line }
    } else { $line }
  }
  foreach ($k in @($keys.Keys)) { $out += "${k}:$($keys[$k])" }
  Write-Utf8NoBom $OptionsPath (($out -join "`n") + "`n")
}

function Set-ResourcePacks([string]$OptionsPath, [string]$PacksJson) {
  $lines = Get-Content $OptionsPath
  $found = $false
  $out = foreach ($line in $lines) {
    if ($line -like 'resourcePacks:*') {
      $found = $true
      "resourcePacks:$PacksJson"
    } else { $line }
  }
  if (-not $found) { $out += "resourcePacks:$PacksJson" }
  Write-Utf8NoBom $OptionsPath (($out -join "`n") + "`n")
}

function Set-TomlKeys([string]$Path, [hashtable]$Patches) {
  if (-not (Test-Path $Path)) { throw "Missing $Path" }
  $lines = Get-Content $Path -Encoding UTF8
  $left = @{}
  foreach ($k in $Patches.Keys) { $left[$k] = $true }
  $out = foreach ($line in $lines) {
    $matched = $false
    foreach ($k in @($Patches.Keys)) {
      if ($line -match ('^[ \t]*' + [regex]::Escape($k) + '[ \t]*=')) {
        $v = [string]$Patches[$k]
        $indent = ''
        if ($line -match '^([ \t]*)') { $indent = $Matches[1] }
        [void]$left.Remove($k)
        $matched = $true
        if ($v -match '^(true|false|\d+)$') {
          '{0}{1} = {2}' -f $indent, $k, $v
        } else {
          '{0}{1} = "{2}"' -f $indent, $k, $v
        }
        break
      }
    }
    if (-not $matched) { $line }
  }
  if ($left.Count -gt 0) { throw ('DH keys missing: ' + (($left.Keys | Sort-Object) -join ', ')) }
  Write-Utf8NoBom $Path (($out -join "`n") + "`n")
}


function Set-SodiumPatches([string]$Path, [hashtable]$Patches) {
  $json = Get-Content $Path -Raw | ConvertFrom-Json
  foreach ($k in $Patches.Keys) {
    $parts = $k -split '\.'
    if ($parts.Count -ne 2) { throw "Bad sodium patch key $k" }
    $sec = $parts[0]; $name = $parts[1]
    if (-not $json.$sec) { throw "Missing sodium section $sec" }
    $json.$sec | Add-Member -NotePropertyName $name -NotePropertyValue $Patches[$k] -Force
  }
  ($json | ConvertTo-Json -Depth 12) | Set-Content $Path -Encoding utf8
}

function Update-PackwizHashes([string[]]$RelativePaths) {
  $pwPath = Join-Path $norcom 'packwiz.json'
  if (-not (Test-Path $pwPath)) { return }
  $raw = Get-Content $pwPath -Raw
  $pw = $raw | ConvertFrom-Json
  $sha = [System.Security.Cryptography.SHA256]::Create()
  foreach ($rel in $RelativePaths) {
    $full = Join-Path $norcom ($rel -replace '/','\')
    if (-not (Test-Path $full)) { continue }
    $key = ($rel -replace '\\','/')
    $bytes = [System.IO.File]::ReadAllBytes($full)
    $hash = ($sha.ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') }) -join ''
    $props = @($pw.cachedFiles.PSObject.Properties | ForEach-Object { $_.Name })
    if ($props -contains $key) {
      $entry = $pw.cachedFiles.$key
      if ($null -eq $entry.hash) {
        $entry | Add-Member -NotePropertyName hash -NotePropertyValue ([pscustomobject]@{ type='sha256'; value=$hash }) -Force
      } else {
        $entry.hash | Add-Member -NotePropertyName type -NotePropertyValue 'sha256' -Force
        $entry.hash | Add-Member -NotePropertyName value -NotePropertyValue $hash -Force
      }
      $entry | Add-Member -NotePropertyName cachedLocation -NotePropertyValue $key -Force
      $entry | Add-Member -NotePropertyName optionValue -NotePropertyValue $true -Force
    }
  }
  $sha.Dispose()
  $pw | ConvertTo-Json -Depth 30 -Compress | Set-Content $pwPath -Encoding utf8
}

$backup = Backup-Current -Tag $Profile
$packs = (Get-Content (Join-Path $src 'resourcePacks.txt') -Raw).Trim()
$optPatches = Get-Content (Join-Path $src 'options-patches.json') -Raw | ConvertFrom-Json
$optHash = @{}
$optPatches.PSObject.Properties | ForEach-Object { $optHash[$_.Name] = $_.Value }

Copy-Item (Join-Path $src 'ComplementaryUnbound_r5.9.3.zip.txt') (Join-Path $norcom 'shaderpacks\ComplementaryUnbound_r5.9.3.zip.txt') -Force
Copy-Item (Join-Path $src 'ComplementaryUnbound_r5.9.3.txt') (Join-Path $norcom 'shaderpacks\ComplementaryUnbound_r5.9.3.txt') -Force
Copy-Item (Join-Path $src 'iris.properties') (Join-Path $norcom 'config\iris.properties') -Force
Copy-Item (Join-Path $src 'options.norcom.txt') (Join-Path $norcom 'options.norcom.txt') -Force

Set-OptionsKey (Join-Path $norcom 'options.txt') $optHash
Set-ResourcePacks (Join-Path $norcom 'options.txt') $packs

$dh = Get-Content (Join-Path $src 'dh-patches.json') -Raw | ConvertFrom-Json
$dhHash = @{}
$dh.PSObject.Properties | ForEach-Object { $dhHash[$_.Name] = $_.Value }
Set-TomlKeys (Join-Path $norcom 'config\DistantHorizons.toml') $dhHash

$na = Get-Content (Join-Path $src 'sodium-patches.json') -Raw | ConvertFrom-Json
$naHash = @{}
$na.PSObject.Properties | ForEach-Object { $naHash[$_.Name] = $_.Value }
Set-SodiumPatches (Join-Path $norcom 'config\sodium-options.json') $naHash

Set-Content (Join-Path $gfx 'profile.marker') $Profile -Encoding ascii

Update-PackwizHashes @(
  'config/iris.properties',
  'options.norcom.txt',
  'shaderpacks/ComplementaryUnbound_r5.9.3.txt',
  'shaderpacks/ComplementaryUnbound_r5.9.3.zip.txt',
  'options.txt',
  'config/DistantHorizons.toml',
  'config/sodium-options.json'
)

$reapply = @'
# NORCOM graphics persistence helper. Launcher should run this after packwiz sync.
$marker = Join-Path $env:APPDATA '.norcom\norcom-graphics\profile.marker'
$apply = Join-Path $env:APPDATA '.norcom\norcom-graphics\apply.ps1'
if ((Test-Path $marker) -and (Test-Path $apply)) {
  $p = (Get-Content $marker -Raw).Trim()
  if ($p -eq 'ULTRA' -or $p -eq 'NORMAL' -or $p -eq 'LOW' -or $p -eq 'MEDIUM' -or $p -eq 'MEDIUM_HIGH' -or $p -eq 'HIGH') {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $apply -Profile $p -Quiet -NoMessage
  }
}
'@
Set-Content (Join-Path $gfx 'reapply-after-sync.ps1') $reapply -Encoding ascii

$gameRunning = $false
Get-CimInstance Win32_Process -Filter "Name = 'javaw.exe' OR Name = 'java.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
  if ($_.CommandLine -and ($_.CommandLine -match '\.norcom|fabric-loader|net\.minecraft\.client')) { $script:gameRunning = $true }
}

if ($Profile -eq 'ULTRA') {
  $msg = "NORCOM Ultra graphics enabled.`r`n`r`nPatrix labPBR + Complementary POM sand waves on.`r`nBackup: $backup"
} elseif ($Profile -eq 'MEDIUM_HIGH') {
  $msg = "NORCOM Medium High graphics enabled.`r`n`r`nBetween Medium and High - Patrix POM + balanced shadows.`r`nBackup: $backup"
} elseif ($Profile -eq 'HIGH') {
  $msg = "NORCOM High graphics enabled.`r`n`r`nPatrix POM sand waves, lighter than Ultra.`r`nBackup: $backup"
} elseif ($Profile -eq 'MEDIUM') {
  $msg = "NORCOM Medium graphics enabled.`r`n`r`nBalanced Patrix POM + medium shadows.`r`nBackup: $backup"
} elseif ($Profile -eq 'LOW') {
  $msg = "NORCOM Low graphics enabled.`r`n`r`nLight shaders for weaker PCs.`r`nBackup: $backup"
} else {
  $msg = "NORCOM Normal graphics restored.`r`n`r`nFaithful default look.`r`nBackup: $backup"
}
if ($gameRunning) {
  $msg += "`r`n`r`nGame looks running - restart Minecraft, or press R in-game to reload shaders."
} else {
  $msg += "`r`n`r`nOpen NORCOM / press Play to see it."
}

if (-not $Quiet) { Write-Host $msg }
if (-not $NoMessage) {
  Add-Type -AssemblyName System.Windows.Forms | Out-Null
  [System.Windows.Forms.MessageBox]::Show($msg, 'NORCOM Graphics', 'OK', 'Information') | Out-Null
}
